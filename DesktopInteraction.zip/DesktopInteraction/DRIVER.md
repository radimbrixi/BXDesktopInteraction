# Extedo virtual mouse driver (internal QA)

> For device input on a normal PC without test mode or driver signing, prefer the default `--device usbip` ([USBIP.md](USBIP.md)).
> This own driver remains the fallback for test VMs where usbip-win2 is not wanted. Limitation found while testing
> the USB/IP backend: Windows maps an absolute mouse to the primary monitor only, so this absolute-only driver cannot
> reach other monitors (the USB/IP device adds a relative collection for that).

`Driver\ExtedoVirtualMouse` is a KMDF driver using Microsoft's **Virtual HID Framework (VHF)**. It creates one
virtual **absolute** pointing device (5 buttons, wheel, horizontal pan). With `--device driver` the device mouse tools send
every pointer step to this device instead of calling `SendInput`, so Windows receives the input from a mouse device:

| | `_injected` tools (SendInput) | device tools with `--device driver` |
| --- | --- | --- |
| Input origin seen by apps/hooks | injected (`LLMHF_INJECTED`) | mouse device (not injected) |
| Raw Input / DirectInput consumers | may ignore it | receive it |
| Elevated windows (UIPI) | blocked unless elevated | work |
| Exact pixel landing | yes | yes (absolute device + automatic calibration) |
| Installation | none | admin + signed driver |

Keyboard text (`desktop_type_text`) uses SendInput with this driver (it has no keyboard); the default `usbip` device has a virtual keyboard. Human-like motion (`--motion human`, the default) applies to both backends.
Scope: internal test VMs and tester machines only. Not for customers, not for production systems.

## Architecture

```
LM Studio / MCP client ──stdio──> Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --device driver
                                     │  DeviceIoControl(IOCTL 0x22A000, 8-byte report) on \\.\ExtedoVirtualMouse
                                     ▼
                                 ExtedoVirtualMouse.sys (Root\ExtedoVirtualMouse) ── VhfReadReportSubmit
                                     ▼
                                 vhf.sys → HID child device → hidclass/mouhid → mouclass → Windows input
```

Report layout and IOCTL are defined once in `Driver\ExtedoVirtualMouse\Public.h` and mirrored in `Desktop\DriverBackend.cs`
(`--motion-self-test` checks the encoding). Device access: SYSTEM/Administrators full, interactive users read/write,
so a non-elevated LM Studio can use it. When a client handle closes (also on crash) the driver releases held buttons.

Windows may map an absolute device to the whole virtual desktop or to the primary monitor; the backend starts with
the virtual desktop and learns the real mapping from the observed pointer position, re-sending the final point until
it lands exactly.

Safety: input is refused while the secure desktop is active (UAC prompt, lock screen, Ctrl+Alt+Del) - a device could
otherwise reach it blind. Only the opt-in `--secure-desktop-input device` (test machines, MANUAL.md 6.4) allows device
input there. Ctrl+Alt+F12 emergency stop and the multi-instance baton work exactly as with SendInput.

## 1. Build the driver (build machine with WDK, once per change)

Testers do not need this; they get the built package. Requirements on the build machine:

- Visual Studio 2022/2026 with *Desktop development with C++* and the *Windows Driver Kit* component
- Windows SDK + WDK of the same version (https://learn.microsoft.com/windows-hardware/drivers/download-the-wdk)

```powershell
msbuild Research\DesktopInteraction\Driver\ExtedoVirtualMouse\ExtedoVirtualMouse.vcxproj /p:Configuration=Release /p:Platform=x64
```

Output package: `Driver\ExtedoVirtualMouse\x64\Release\ExtedoVirtualMouse\` (`.sys`, `.inf`, `.cat`), test-signed with an
auto-generated `WDKTestCert`. Export that certificate once (`certmgr` → *Current User → Private Certificate Store* or
`x64\Release\ExtedoVirtualMouse.cer`) and keep the `.cer` with the package. Store package + `.cer` in the internal
artifact share; do not commit build output.

The driver project is intentionally **not** in `Extedo.Test.sln`, so machines without WDK still build the test framework.

## 2. Test VM setup (test-signed driver)

Once per VM (Hyper-V shown; VMware/VirtualBox have equivalent Secure Boot switches):

```powershell
# On the host, VM switched off:
Set-VMFirmware -VMName <vm> -EnableSecureBoot Off
# Inside the VM, elevated, then reboot:
bcdedit /set testsigning on
```

Then, inside the VM (elevated), with the built MCP server and driver package:

```powershell
dotnet build Research\DesktopInteraction -c Release
Research\DesktopInteraction\Scripts\Install-Driver.ps1 -Package <path to package> -TrustTestCertificate
Research\DesktopInteraction\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --self-test --device driver --input device
```

The self-test must print `PASS (ExtedoVirtualMouse, ...) ... injected=0`. Remove with `Install-Driver.ps1 -Uninstall`.
Take a VM checkpoint before the first install; run Driver Verifier (`verifier /standard /driver ExtedoVirtualMouse.sys`)
on a dedicated VM during driver development.

## 3. Tester machines (physical, Secure Boot on)

Test signing requires Secure Boot off and is not acceptable on company laptops. Options:

1. **Run driver-backed tests inside test VMs** (recommended start): no signing work.
2. **Attestation signing** for physical machines: Extedo signs the `.cab` with its EV code-signing certificate, submits it
   to the Microsoft Partner Center (Hardware Dev Center), and gets back a Microsoft-signed package that loads with
   Secure Boot and Memory Integrity (HVCI) on. Needs: company EV certificate, Partner Center account (IT/legal), ~1 day
   per submission once set up. Attestation-signed drivers are valid for internal distribution; Windows Update/customer
   distribution is not intended. Then testers run only `Install-Driver.ps1` (no `-TrustTestCertificate`, no test mode).

Check with IT/endpoint security before installing on any managed machine: EDR products may flag a new kernel driver.

## Status / troubleshooting

- `desktop_status` shows `inputs.device.name` (`ExtedoVirtualMouse`), `inputs.device.available` and, in
  `inputs.device.details`, the learned axis mapping or the error.
- `available: false` + error: driver not installed, disabled, or blocked by signing (Device Manager → *Extedo Virtual
  Mouse* → Code 52 = signature not trusted).
- Scroll with the driver backend accepts whole notches only (multiples of 120).
- The server never falls back silently: with `--device driver` the device tools fail until the driver is available.
