using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.SelfTests;

// Route planning on real and synthetic exotic monitor layouts. Pure computation, no input.
internal static class LayoutSelfTest
{
    internal static int Run()
    {
        try
        {
            var layouts = new Dictionary<string, (string, Rectangle)[]>
            {
                // Seven monitors as measured on the development PC (rotated, offset, stacked).
                ["seven-monitor desk"] =
                [
                    ("D1", new(0, 0, 1920, 1080)), ("D2", new(-2160, -2119, 2160, 3840)), ("D3", new(-8160, -1060, 3840, 2160)),
                    ("D4", new(-4320, -2119, 2160, 3840)), ("D9", new(1920, -11, 1920, 1080)), ("D10", new(1920, -1091, 1920, 1080)),
                    ("D11", new(0, -1080, 1920, 1080)),
                ],
                ["staircase"] = [("A", new(0, 0, 1920, 1080)), ("B", new(1920, 500, 1920, 1080)), ("C", new(3840, 1000, 1920, 1080))],
                ["U shape (gap in the middle)"] = [("A", new(0, 0, 1000, 1000)), ("B", new(0, 1000, 3000, 500)), ("C", new(2000, 0, 1000, 1000))],
                ["narrow 80 px overlap"] = [("A", new(0, 0, 1920, 1080)), ("B", new(1920, 1000, 1000, 1000))],
                ["portrait between landscapes"] = [("A", new(-1920, 600, 1920, 1080)), ("P", new(0, 0, 1080, 1920)), ("B", new(1080, 200, 2560, 1440))],
                ["corner only (no shared edge)"] = [("A", new(0, 0, 1000, 1000)), ("B", new(1000, 1000, 1000, 1000))],
            };

            var random = new Random(4242);
            int routes = 0, multi = 0;
            foreach (var (name, monitors) in layouts)
            {
                var layout = new MonitorLayout(monitors.Select(m => (m.Item1, m.Item2, m.Item1 is "D1" or "A")));
                bool connected = layout.Edges.Count > 0;
                for (int i = 0; i < 400; i++)
                {
                    var start = RandomPoint(layout, random);
                    var end = RandomPoint(layout, random);
                    var legs = layout.Route(start, end);
                    routes++;
                    Require(legs.Count > 0 && legs[0].From == start && legs[^1].To == end, name, "route does not start/end at the requested points");
                    int a = layout.MonitorAt(start), b = layout.MonitorAt(end);
                    if (a != b && connected) Require(legs.Count > 1, name, $"no route between monitors {a} and {b}");
                    if (legs.Count > 1)
                    {
                        multi++;
                        for (int l = 0; l < legs.Count; l++)
                        {
                            var leg = legs[l];
                            Require(layout.Monitors.Any(m => m.Bounds == leg.Area), name, "leg area is not a monitor");
                            Require(leg.Area.Contains(leg.From) && leg.Area.Contains(leg.To), name, $"leg {l} leaves its monitor");
                            if (l == 0) continue;
                            var exit = legs[l - 1].To; var entry = leg.From;
                            Require(Math.Abs(exit.X - entry.X) + Math.Abs(exit.Y - entry.Y) == 1, name, "crossing is not across a shared edge");
                            var edge = layout.Edges.Single(e => e.Vertical ? Math.Max(exit.X, entry.X) == e.Line && exit.Y == entry.Y && exit.Y >= e.Start && exit.Y < e.End
                                                                           : Math.Max(exit.Y, entry.Y) == e.Line && exit.X == entry.X && exit.X >= e.Start && exit.X < e.End);
                            int along = edge.Vertical ? exit.Y : exit.X;
                            Require(along >= edge.Start + edge.Inset && along <= edge.End - 1 - edge.Inset, name, $"crossing {along} too close to a corner of edge {edge.Start}..{edge.End - 1}");
                        }
                    }

                    int duration = HumanMotion.DefaultDuration(MonitorLayout.Length(legs), random);
                    var human = legs.Count > 1 ? HumanMotion.HumanRoute(legs, duration, random) : HumanMotion.Human(start, end, duration, legs[0].Area, random, legs[0].Area);
                    var linear = legs.Count > 1 ? HumanMotion.LinearRoute(legs, duration) : HumanMotion.Linear(start, end, duration);
                    foreach (var (kind, path) in new[] { ("human", human), ("linear", linear) })
                    {
                        Require(path[^1].X == end.X && path[^1].Y == end.Y, name, $"{kind} path does not end on the target");
                        if (connected || a == b)
                            Require(path.All(s => layout.MonitorAt(new Point(s.X, s.Y)) >= 0), name, $"{kind} path enters a gap between monitors");
                    }
                    if (MonitorLayout.Length(legs) > 50)
                    {
                        int total = human.Sum(s => s.DelayMs);
                        Require(total >= duration * 0.75 && total <= duration * 1.35, name, $"human route timing {total} ms far from {duration} ms");
                    }
                }
            }

            var u = new MonitorLayout(layouts["U shape (gap in the middle)"].Select(m => (m.Item1, m.Item2, false)));
            Require(u.Route(new Point(500, 500), new Point(2500, 500)).Count == 3, "U shape", "left to right must go down, across and up (3 legs)");
            var corner = new MonitorLayout(layouts["corner only (no shared edge)"].Select(m => (m.Item1, m.Item2, false)));
            Require(corner.Edges.Count == 0 && corner.Route(new Point(500, 500), new Point(1500, 1500)).Count == 1, "corner only", "corner contact must not count as a shared edge");

            Console.WriteLine($"PASS: {routes} routes on {layouts.Count} layouts ({multi} across monitors): legs stay on monitors, crossings on shared edges away from corners, human and linear paths never enter gaps, exact end, timing. No input injected.");
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 1; }
    }

    private static Point RandomPoint(MonitorLayout layout, Random random)
    {
        var m = layout.Monitors[random.Next(layout.Monitors.Count)].Bounds;
        return new Point(random.Next(m.Left, m.Right), random.Next(m.Top, m.Bottom));
    }

    private static void Require(bool condition, string layout, string what)
    {
        if (!condition) throw new Exception($"Layout self-test failed ({layout}): {what}");
    }
}
