using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.SelfTests;

/// <summary>Shared device host protocol over a private pipe with a recording fake device. No desktop input.</summary>
internal static class DeviceHostSelfTest
{
    private sealed class Fake : IPointerBackend
    {
        internal readonly List<string> Log = [];
        public string Name => "Fake";
        public bool Available => true;
        public bool IsDevice => true;
        public void MoveTo(int x, int y) { lock (Log) Log.Add($"move {x},{y}"); }
        public void Button(int mask, bool down) { lock (Log) Log.Add($"button {mask} {(down ? "down" : "up")}"); }
        public void Scroll(int delta, bool horizontal) { lock (Log) Log.Add($"scroll {delta}"); }
        public void ForgetButtons() { lock (Log) Log.Add("release"); }
        public bool Recalibrate(int rx, int ry, int ax, int ay) => rx != ax;
        public object Diagnostics() => new { fake = true };
        public void Dispose() { }
    }

    internal static int Run()
    {
        try
        {
            void Require(bool value, string message) { if (!value) throw new Exception(message); }
            string pipe = "Extedo.DesktopInteraction.DeviceHostTest." + Guid.NewGuid().ToString("N");
            var fake = new Fake();
            var server = new DeviceHost.Server(fake, TimeSpan.FromMinutes(1), pipe);
            var serving = Task.Run(server.Serve);
            long genA = 1, genB = 0;
            using (var a = new RemoteDeviceBackend("Fake", "--never-launched", () => genA, pipe))
            using (var b = new RemoteDeviceBackend("Fake", "--never-launched", () => genB, pipe))
            {
                Require(a.Available, "Host not available to the first instance.");
                a.MoveTo(10, 20);
                a.Button(1, true);
                Require(a.Recalibrate(5, 0, 4, 0) && !a.Recalibrate(5, 0, 5, 0), "Recalibrate result not forwarded.");
                genB = 2; // B takes the baton
                b.MoveTo(30, 40);
                Require(fake.Log.Count(l => l == "release") == 2, "Takeover did not release the previous owner's buttons.");
                try { a.MoveTo(1, 1); throw new Exception("Superseded instance could still move the shared device."); }
                catch (OperationCanceledException) { }
                b.Scroll(120, false);
                Require(fake.Log.SequenceEqual(["release", "move 10,20", "button 1 down", "release", "move 30,40", "scroll 120"]), "Unexpected device log: " + string.Join("; ", fake.Log));
                Require(System.Text.Json.JsonSerializer.Serialize(b.Diagnostics()).Contains("\"instances\":2"), "Host does not count both instances.");
            }
            Thread.Sleep(300);
            genA = 1; // all instances closed: a fresh set starts at generation 1 again
            using (var fresh = new RemoteDeviceBackend("Fake", "--never-launched", () => genA, pipe))
                fresh.MoveTo(7, 7);
            Require(fake.Log[^1] == "move 7,7", "Host refused a fresh instance set after all instances closed.");
            server.Stop();
            serving.Wait(5000);
            Console.WriteLine("PASS: shared device host: forwarding, recalibration, takeover releases buttons, superseded instance refused, instance count, generation reset after all instances closed. No desktop input.");
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 1; }
    }
}
