using System.Buffers.Binary;
using System.Net;
using System.Net.Sockets;
using System.Text;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.SelfTests;

// Plays the USB/IP client (usbip-win2's role) against UsbIpMouseServer on a free loopback port.
// Checks the wire format and device behaviour without usbip-win2 and without any input reaching Windows.
internal static class UsbIpSelfTest
{
    internal static int Run()
    {
        try
        {
            using var server = new UsbIpMouseServer(0);

            // Device list
            using (var list = Connect(server.Port))
            {
                list.Write(Op(0x8005));
                var reply = Read(list, 8 + 4 + 312 + 4);
                Require(U16(reply, 2) == 0x0005 && U32(reply, 4) == 0 && U32(reply, 8) == 1, "OP_REP_DEVLIST header");
                Require(Ascii(reply, 12 + 256, 32) == UsbIpMouseServer.BusId, "devlist busid");
                Require(U16(reply, 12 + 300) == UsbIpMouseDevice.VendorId && U16(reply, 12 + 302) == UsbIpMouseDevice.ProductId, "devlist VID/PID");
                Require(reply[12 + 312] == 3, "devlist interface class HID");
            }

            // Unknown bus id is refused
            using (var wrong = Connect(server.Port))
            {
                wrong.Write([.. Op(0x8003), .. BusId("9-9")]);
                var reply = Read(wrong, 8);
                Require(U16(reply, 2) == 0x0003 && U32(reply, 4) != 0, "import of unknown busid must fail");
            }

            using var client = Connect(server.Port);
            client.Write([.. Op(0x8003), .. BusId(UsbIpMouseServer.BusId)]);
            var import = Read(client, 8 + 312);
            Require(U32(import, 4) == 0 && Ascii(import, 8 + 256, 32) == UsbIpMouseServer.BusId && U32(import, 8 + 296) == 2, "OP_REP_IMPORT");
            Require(server.WaitReady(TimeSpan.Zero) == false, "ready before SET_CONFIGURATION");

            // Second importer is refused while the first one is attached
            using (var second = Connect(server.Port))
            {
                second.Write([.. Op(0x8003), .. BusId(UsbIpMouseServer.BusId)]);
                Require(U32(Read(second, 8), 4) != 0, "second import must fail");
            }

            uint seq = 1;
            var device = Control(client, seq++, 0x80, 6, 0x0100, 0, 64);
            Require(device.Status == 0 && device.Data.SequenceEqual(UsbIpMouseDevice.DeviceDescriptor), "device descriptor");
            var config9 = Control(client, seq++, 0x80, 6, 0x0200, 0, 9);
            Require(config9.Data.Length == 9 && config9.Data[2] == 34, "configuration header");
            var config = Control(client, seq++, 0x80, 6, 0x0200, 0, 255);
            Require(config.Data.Length == 34 && config.Data[18 + 1] == 0x21 && config.Data[27 + 2] == 0x81, "configuration descriptor");
            var language = Control(client, seq++, 0x80, 6, 0x0300, 0, 255);
            Require(language.Data.SequenceEqual(new byte[] { 4, 3, 0x09, 0x04 }), "language string");
            var product = Control(client, seq++, 0x80, 6, 0x0302, 0x0409, 255);
            Require(Encoding.Unicode.GetString(product.Data, 2, product.Data.Length - 2).Contains("Extedo"), "product string");
            Require(Control(client, seq++, 0x80, 6, 0x0600, 0, 10).Status == UsbIpMouseDevice.StatusStall, "device qualifier must stall");
            Require(Control(client, seq++, 0x80, 6, 0x03EE, 0, 18).Status == UsbIpMouseDevice.StatusStall, "OS string must stall");

            Require(Control(client, seq++, 0x00, 9, 1, 0, 0).Status == 0, "SET_CONFIGURATION");
            Require(server.WaitReady(TimeSpan.FromSeconds(2)), "ready after SET_CONFIGURATION");
            Require(Control(client, seq++, 0x21, 0x0A, 0, 0, 0).Status == 0, "SET_IDLE");
            var report = Control(client, seq++, 0x81, 6, 0x2200, 0, 255);
            Require(report.Data.SequenceEqual(UsbIpMouseDevice.ReportDescriptor), "report descriptor");
            Require(report.Data.Length == UsbIpMouseDevice.HidDescriptor[7], "HID descriptor length");

            // SET_REPORT (OUT data stage) is accepted and acknowledged with the OUT length
            var setReport = Submit(client, seq++, 0, 0, 2, Setup(0x21, 9, 0x0201, 0, 2), [1, 0]);
            Require(setReport.Status == 0 && setReport.ActualLength == 2, "SET_REPORT");

            // Interrupt IN: pending URB, unlink, then delivery in order
            uint cancelled = seq++;
            client.Write(SubmitHeader(cancelled, 1, 1, 8, default));
            client.Write(UnlinkHeader(seq++, cancelled));
            var unlink = Read(client, 48);
            Require(U32(unlink, 0) == 4 && BinaryPrimitives.ReadInt32BigEndian(unlink.AsSpan(20)) == -104, "RET_UNLINK of pending URB");

            var first = AbsoluteHidBackend.Encode(100, 200, 1, 0, 0);
            var second2 = AbsoluteHidBackend.Encode(300, 400, 0, -1, 0);
            server.Send(first);
            server.Send(second2);
            uint inA = seq++, inB = seq++;
            client.Write(SubmitHeader(inA, 1, 1, 8, default));
            client.Write(SubmitHeader(inB, 1, 1, 8, default));
            var a = ReadRet(client); var b = ReadRet(client);
            Require(a.Seq == inA && a.Status == 0 && a.Data.SequenceEqual(first), "first interrupt report");
            Require(b.Seq == inB && b.Data.SequenceEqual(second2), "second interrupt report in order");

            uint waiting = seq++;
            client.Write(SubmitHeader(waiting, 1, 1, 8, default));
            Thread.Sleep(50);
            server.Send(first);
            var c = ReadRet(client);
            Require(c.Seq == waiting && c.Data.SequenceEqual(first), "report delivered to waiting URB");
            Require(Control(client, seq++, 0xA1, 1, 0x0101, 0, 8).Data.SequenceEqual(first), "GET_REPORT returns current report");
            Require(Submit(client, seq++, 1, 2, 8, default, []).Status == UsbIpMouseDevice.StatusStall, "unknown endpoint must stall");
            Require(server.DeliveredReports == 3, "delivered report count");

            client.Close();
            for (int i = 0; i < 100 && server.Imported; i++) Thread.Sleep(10);
            Require(!server.Imported && !server.Ready, "detach on disconnect");
            Require(Throws(() => server.Send(first)), "send after detach must fail");

            Console.WriteLine("PASS: USB/IP device server - devlist, import (wrong/duplicate refused), descriptors, SET_CONFIGURATION, HID requests, interrupt reports in order, unlink, stall, detach. No input injected.");
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 1; }
    }

    private record struct Ret(uint Seq, int Status, int ActualLength, byte[] Data);

    private static (int Status, byte[] Data) Control(NetworkStream s, uint seq, byte type, byte request, ushort value, ushort index, ushort length)
    {
        var ret = Submit(s, seq, (type & 0x80) != 0 ? 1u : 0u, 0, length, Setup(type, request, value, index, length), []);
        return (ret.Status, ret.Data);
    }

    private static Ret Submit(NetworkStream s, uint seq, uint direction, uint endpoint, int length, byte[]? setup, byte[] outData)
    {
        s.Write([.. SubmitHeader(seq, direction, endpoint, length, setup), .. outData]);
        var ret = ReadRet(s, expectIn: direction == 1);
        Require(ret.Seq == seq, $"RET_SUBMIT seq {ret.Seq} != {seq}");
        return ret;
    }

    private static Ret ReadRet(NetworkStream s, bool expectIn = true)
    {
        var h = Read(s, 48);
        Require(U32(h, 0) == 3 && U32(h, 8) == 0 && U32(h, 12) == 0 && U32(h, 16) == 0, "RET_SUBMIT header");
        int status = BinaryPrimitives.ReadInt32BigEndian(h.AsSpan(20)), actual = BinaryPrimitives.ReadInt32BigEndian(h.AsSpan(24));
        // Data follows the header only for successful IN transfers
        return new(U32(h, 4), status, actual, expectIn && status == 0 && actual > 0 ? Read(s, actual) : []);
    }

    private static byte[] SubmitHeader(uint seq, uint direction, uint endpoint, int length, byte[]? setup)
    {
        var h = new byte[48];
        BinaryPrimitives.WriteUInt32BigEndian(h, 1);
        BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(4), seq);
        BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(8), 0x00010001);
        BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(12), direction);
        BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(16), endpoint);
        BinaryPrimitives.WriteInt32BigEndian(h.AsSpan(24), length);
        BinaryPrimitives.WriteInt32BigEndian(h.AsSpan(32), -1); // number_of_packets: not ISO
        setup?.CopyTo(h, 40);
        return h;
    }

    private static byte[] UnlinkHeader(uint seq, uint target)
    {
        var h = new byte[48];
        BinaryPrimitives.WriteUInt32BigEndian(h, 2);
        BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(4), seq);
        BinaryPrimitives.WriteUInt32BigEndian(h.AsSpan(20), target);
        return h;
    }

    private static byte[] Setup(byte type, byte request, ushort value, ushort index, ushort length)
    {
        var s = new byte[8];
        s[0] = type; s[1] = request;
        BinaryPrimitives.WriteUInt16LittleEndian(s.AsSpan(2), value);
        BinaryPrimitives.WriteUInt16LittleEndian(s.AsSpan(4), index);
        BinaryPrimitives.WriteUInt16LittleEndian(s.AsSpan(6), length);
        return s;
    }

    private static byte[] Op(ushort code)
    {
        var h = new byte[8];
        BinaryPrimitives.WriteUInt16BigEndian(h, 0x0111);
        BinaryPrimitives.WriteUInt16BigEndian(h.AsSpan(2), code);
        return h;
    }

    private static byte[] BusId(string id) { var b = new byte[32]; Encoding.ASCII.GetBytes(id).CopyTo(b, 0); return b; }

    private static NetworkStream Connect(int port)
    {
        var tcp = new TcpClient();
        tcp.Connect(IPAddress.Loopback, port);
        return new NetworkStream(tcp.Client, ownsSocket: true) { ReadTimeout = 3000 };
    }

    private static byte[] Read(NetworkStream s, int count) { var b = new byte[count]; s.ReadExactly(b); return b; }

    private static ushort U16(byte[] b, int offset) => BinaryPrimitives.ReadUInt16BigEndian(b.AsSpan(offset));

    private static uint U32(byte[] b, int offset) => BinaryPrimitives.ReadUInt32BigEndian(b.AsSpan(offset));

    private static string Ascii(byte[] b, int offset, int length) => Encoding.ASCII.GetString(b, offset, length).TrimEnd('\0');

    private static void Require(bool condition, string what) { if (!condition) throw new Exception("USB/IP self-test failed: " + what); }

    private static bool Throws(Action action) { try { action(); return false; } catch (InvalidOperationException) { return true; } }
}
