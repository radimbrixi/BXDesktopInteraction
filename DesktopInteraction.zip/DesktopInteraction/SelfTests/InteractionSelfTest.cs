using System.Runtime.InteropServices;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.SelfTests;

// A deliberate foreground integration test. It injects only into its own test surface.
// A low-level mouse hook counts events flagged as injected: with --input device none may be injected.
internal static class InteractionSelfTest
{
    internal static int Run(DesktopOptions options)
    {
        using var form = new Form { Text = "Desktop Interaction mouse test - do not move the mouse", Width = 600, Height = 400, StartPosition = FormStartPosition.CenterScreen, BackColor = Color.LightCyan };
        using var overlay = new CursorOverlay();
        using var deviceBackend = options.CreateDevice(() => overlay.Control.Lease);
        using var injectedBackend = new SendInputBackend();
        var kind = options.SelfTestInput;
        IPointerBackend backend = kind == InputKind.Device ? deviceBackend ?? throw new InvalidOperationException("--self-test --input device needs a device (--device usbip or driver).") : injectedBackend;
        var mouse = new MouseController(overlay, deviceBackend, injectedBackend, options.HumanMotion);
        overlay.EmergencyStop = mouse.ReleaseAll;
        int downs = 0, ups = 0, doubles = 0, wheels = 0, injected = 0, device = 0, result = 1;
        form.MouseDown += (_, _) => Interlocked.Increment(ref downs);
        form.MouseUp += (_, _) => Interlocked.Increment(ref ups);
        form.MouseDoubleClick += (_, _) => Interlocked.Increment(ref doubles);
        form.MouseWheel += (_, _) => Interlocked.Increment(ref wheels);

        HookProc hook = (code, wParam, lParam) =>
        {
            if (code >= 0)
            {
                int flags = Marshal.ReadInt32(lParam, 12); // MSLLHOOKSTRUCT.flags
                if ((flags & 0x1) != 0) Interlocked.Increment(ref injected); else Interlocked.Increment(ref device);
            }
            return CallNextHookEx(0, code, wParam, lParam);
        };
        nint hookHandle = SetWindowsHookEx(14 /* WH_MOUSE_LL */, hook, GetModuleHandle(null), 0);

        form.Shown += (_, _) =>
        {
            overlay.Show();
            form.Activate();
            var point = form.PointToScreen(new Point(180, 140));
            var expected = form.Handle;
            Native.GetCursorPos(out var original);
            _ = Task.Run(async () =>
            {
                try
                {
                    await Task.Delay(300);
                    mouse.TakeControl();
                    void OwnForeground() { if (Native.GetForegroundWindow() != expected) throw new InvalidOperationException("Test window lost foreground; refusing input."); }
                    OwnForeground();
                    await mouse.Move(kind, point.X, point.Y);
                    OwnForeground(); await mouse.Click(kind, "left", 1);
                    await Task.Delay((int)Native.GetDoubleClickTime() + 100);
                    OwnForeground(); await mouse.Click(kind, "left", 2);
                    OwnForeground(); await mouse.Drag(kind, point.X, point.Y, point.X + 80, point.Y + 40, null, "left");
                    OwnForeground(); mouse.Scroll(kind, 120, false);
                    await Task.Delay(200);
                    Native.GetCursorPos(out var actual);
                    if (Math.Abs(actual.X - point.X - 80) > 1 || Math.Abs(actual.Y - point.Y - 40) > 1) throw new InvalidOperationException("Final mouse position mismatch.");
                    if (Volatile.Read(ref downs) < 4 || Volatile.Read(ref ups) < 4 || Volatile.Read(ref doubles) < 1 || Volatile.Read(ref wheels) < 1)
                        throw new InvalidOperationException($"Mouse events incomplete: down={downs},up={ups},double={doubles},wheel={wheels}");
                    string origin = hookHandle == 0 ? "origin not checked (hook unavailable)" : $"injected={injected},device={device}";
                    if (backend.IsDevice && hookHandle != 0 && Volatile.Read(ref injected) > 0)
                        throw new InvalidOperationException($"Driver backend produced injected input: {origin}");
                    Console.WriteLine($"PASS ({backend.Name}, {(options.HumanMotion ? "human" : "linear")} motion): move, single/double click, drag and vertical wheel on the test window. down={downs},up={ups},double={doubles},wheel={wheels},{origin}");
                    result = 0;
                }
                catch (Exception e) { Console.Error.WriteLine(e); }
                finally
                {
                    mouse.ReleaseAll();
                    try { await mouse.Move(kind, original.X, original.Y, 0); } catch { }
                    form.BeginInvoke(form.Close);
                }
            });
        };
        Application.Run(form);
        if (hookHandle != 0) UnhookWindowsHookEx(hookHandle);
        GC.KeepAlive(hook);
        return result;
    }

    private delegate nint HookProc(int code, nint wParam, nint lParam);
    [DllImport("user32.dll", SetLastError = true)] private static extern nint SetWindowsHookEx(int id, HookProc proc, nint module, uint thread);
    [DllImport("user32.dll")] private static extern bool UnhookWindowsHookEx(nint hook);
    [DllImport("user32.dll")] private static extern nint CallNextHookEx(nint hook, int code, nint wParam, nint lParam);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern nint GetModuleHandle(string? name);
}
