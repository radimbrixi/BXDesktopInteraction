using System.Text.Json;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Tools;
using ModelContextProtocol.Protocol;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.SelfTests;

// Live check of the forced visual feedback through the real tool code paths, on this process's own test window
// (a long multi-line text box). Every action must produce a change the feedback reports and crops correctly.
// Before any input the window must be visible, in the foreground and be the window found at the planned points;
// otherwise the test stops without sending input.
internal static class FeedbackLiveTest
{
    /// <summary>The SDK keeps image data base64-encoded (UTF-8); accept raw bytes too.</summary>
    private static byte[] Png(ImageContentBlock image)
    {
        var bytes = image.Data.ToArray();
        if (bytes.Length > 4 && bytes[0] == 0x89 && bytes[1] == (byte)'P') return bytes;
        return Convert.FromBase64String(System.Text.Encoding.ASCII.GetString(bytes));
    }

    internal static int Run(DesktopOptions options, string? saveDirectory)
    {
        using var form = new Form
        {
            Text = "Desktop Interaction feedback test - do not touch the mouse", StartPosition = FormStartPosition.Manual,
            Location = Screen.PrimaryScreen!.WorkingArea.Location + new Size(120, 120), Size = new Size(760, 520), TopMost = true,
        };
        var box = new TextBox
        {
            Multiline = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill, Font = new Font("Consolas", 12),
            Text = string.Join("\r\n", Enumerable.Range(1, 300).Select(i => $"Line {i:000}  the quick brown fox jumps over the lazy dog {i * 7 % 97}")),
        };
        form.Controls.Add(box);
        // Reacts 350 ms after a click, like an app that renders late: the feedback must still report it.
        var late = new Panel { Dock = DockStyle.Bottom, Height = 70, BackColor = Color.LightSteelBlue };
        var lateLabel = new Label { Dock = DockStyle.Fill, Text = "Late reaction panel", Font = new Font("Segoe UI", 14), TextAlign = ContentAlignment.MiddleCenter };
        late.Controls.Add(lateLabel);
        var delay = new System.Windows.Forms.Timer { Interval = 350 };
        delay.Tick += (_, _) => { delay.Stop(); late.BackColor = Color.Orange; lateLabel.Text = "Reacted 350 ms after the click"; };
        lateLabel.Click += (_, _) => delay.Start();
        form.Controls.Add(late);
        // Lazy load: reacts 2 s after a click, after the click's own feedback has given up waiting.
        var lazy = new Panel { Dock = DockStyle.Bottom, Height = 70, BackColor = Color.Gainsboro };
        var lazyLabel = new Label { Dock = DockStyle.Fill, Text = "Lazy load panel (2 s)", Font = new Font("Segoe UI", 14), TextAlign = ContentAlignment.MiddleCenter };
        lazy.Controls.Add(lazyLabel);
        var lazyDelay = new System.Windows.Forms.Timer { Interval = 2000 };
        int loads = 0;
        lazyDelay.Tick += (_, _) => { lazyDelay.Stop(); loads++; lazy.BackColor = loads % 2 == 1 ? Color.MediumSeaGreen : Color.Gold; lazyLabel.Text = $"Lazy content #{loads} loaded after 2 s"; };
        lazyLabel.Click += (_, _) => lazyDelay.Start();
        form.Controls.Add(lazy);
        box.BringToFront();
        using var overlay = new CursorOverlay();
        using var device = options.CreateDevice(() => overlay.Control.Lease);
        using var injected = new SendInputBackend();
        var mouse = new MouseController(overlay, device, injected, options.HumanMotion);
        overlay.EmergencyStop = mouse.ReleaseAll;
        int result = 1;

        form.Shown += (_, _) =>
        {
            overlay.Show();
            form.Activate();
            var client = box.RectangleToScreen(box.ClientRectangle);
            var panel = late.RectangleToScreen(late.ClientRectangle);
            var lazyRect = lazy.RectangleToScreen(lazy.ClientRectangle);
            nint handle = form.Handle;
            Native.GetCursorPos(out var original);
            _ = Task.Run(async () =>
            {
                var report = new List<string>();
                try
                {
                    await Task.Delay(500);
                    var inside = new Point(client.X + client.Width / 2, client.Y + client.Height / 2);
                    var text = new Point(client.X + 60, client.Y + 40);
                    // Safety: only send input when the test window is really the target.
                    if (!Native.IsWindowVisible(handle) || Native.GetForegroundWindow() != handle)
                        throw new InvalidOperationException("Test window is not visible and in the foreground; no input sent.");
                    foreach (var p in new[] { inside, text })
                        if (VisualFeedback.RegionAt(p).Handle != handle) throw new InvalidOperationException($"Another window covers {p}; no input sent.");

                    var kind = options.SelfTestInput;
                    string k = kind == InputKind.Device ? "" : "_injected";
                    async Task<JsonElement> Step(string name, Func<Task<CallToolResult>> call, bool expectChange, Rectangle? mustContain = null, double minHeightShare = 0)
                    {
                        if (Native.GetForegroundWindow() != handle) throw new InvalidOperationException($"{name}: test window lost the foreground; stopped.");
                        var r = await call();
                        var meta = JsonDocument.Parse(((TextContentBlock)r.Content[0]).Text).RootElement;
                        var fb = meta.GetProperty("feedback");
                        if (r.IsError == true) throw new InvalidOperationException($"{name} failed: {meta.GetProperty("result")}");
                        if (r.Content.Count < 2 || r.Content[1] is not ImageContentBlock image) throw new InvalidOperationException($"{name}: no feedback image");
                        if (saveDirectory is not null) File.WriteAllBytes(Path.Combine(saveDirectory, $"{name}.png"), Png(image));
                        var g = fb.GetProperty("region");
                        var region = new Rectangle(g.GetProperty("x").GetInt32(), g.GetProperty("y").GetInt32(), g.GetProperty("width").GetInt32(), g.GetProperty("height").GetInt32());
                        bool changed = fb.GetProperty("changed").GetBoolean();
                        report.Add($"{name,-24} changed={changed,-5} region={region.X},{region.Y} {region.Width}x{region.Height} anchor={fb.GetProperty("anchor").GetProperty("kind").GetString()} settled={fb.GetProperty("settledMs").GetInt32()}ms | {fb.GetProperty("basis").GetString()}");
                        if (fb.GetProperty("window").GetString() != form.Text) throw new InvalidOperationException($"{name}: feedback window is '{fb.GetProperty("window")}', not the test window");
                        if (expectChange && !changed) throw new InvalidOperationException($"{name}: a visible change was not detected");
                        if (!expectChange && changed) throw new InvalidOperationException($"{name}: reported a change although nothing visible changed (false positive)");
                        if (mustContain is { } m && !region.Contains(m)) throw new InvalidOperationException($"{name}: crop {region} does not contain the changed area {m}");
                        if (region.Height < client.Height * minHeightShare) throw new InvalidOperationException($"{name}: crop height {region.Height} below {minHeightShare:P0} of the text box ({client.Height})");
                        return fb;
                    }

                    await Step("move", () => MouseActions.Move(mouse, kind, text.X, text.Y, null, default), expectChange: false);
                    await Step("click", () => MouseActions.Click(mouse, kind, "left", 1, default), expectChange: true); // caret appears
                    var typed = await Step("type_text", () => ToolGuard.Act("desktop_type_text", FeedbackFocus.Keyboard, null, () => { mouse.TakeControl(); mouse.TypeText(" TYPED-BY-FEEDBACK-TEST"); return new { typed = true }; }),
                        expectChange: true);
                    if (typed.GetProperty("anchor").GetProperty("kind").GetString() != "caret") throw new InvalidOperationException("type_text: anchor is not the text caret");
                    await Step("move inside", () => MouseActions.Move(mouse, kind, inside.X, inside.Y, null, default), expectChange: false);
                    await Step("scroll down", () => MouseActions.Scroll(mouse, kind, -360, "vertical"), expectChange: true, minHeightShare: 0.6);
                    await Step("scroll up", () => MouseActions.Scroll(mouse, kind, 360, "vertical"), expectChange: true, minHeightShare: 0.6);
                    var lineY = client.Y + 120;
                    await Step("drag select", () => MouseActions.Drag(mouse, kind, client.X + 20, lineY, client.X + 400, lineY, null, "left", default), expectChange: true,
                        mustContain: new Rectangle(client.X + 60, lineY - 4, 300, 8));
                    var lateTarget = new Point(panel.X + panel.Width / 2, panel.Y + panel.Height / 2);
                    await Step("move to late panel", () => MouseActions.Move(mouse, kind, lateTarget.X, lateTarget.Y, null, default), expectChange: false);
                    await Step("late reaction click", () => MouseActions.Click(mouse, kind, "left", 1, default), expectChange: true,
                        mustContain: Rectangle.Inflate(panel, -2, -2));
                    // Lazy load: the click itself sees nothing; the next tool call must report it, the one after must not.
                    var lazyTarget = new Point(lazyRect.X + lazyRect.Width / 2, lazyRect.Y + lazyRect.Height / 2);
                    await Step("move to lazy panel", () => MouseActions.Move(mouse, kind, lazyTarget.X, lazyTarget.Y, null, default), expectChange: false);
                    await Step("lazy click", () => MouseActions.Click(mouse, kind, "left", 1, default), expectChange: false);
                    await Task.Delay(2600);
                    JsonElement LateOf(CallToolResult r, string name)
                    {
                        var block = r.Content.OfType<TextContentBlock>().Select(t => JsonDocument.Parse(t.Text).RootElement).FirstOrDefault(e => e.ValueKind == JsonValueKind.Object && e.TryGetProperty("lateChange", out _));
                        if (block.ValueKind == JsonValueKind.Undefined) throw new InvalidOperationException($"{name}: no lateChange section");
                        return block.GetProperty("lateChange");
                    }
                    var status = ToolGuard.Read(() => mouse.Status());
                    var lateReport = LateOf(status, "status after lazy load");
                    if (!lateReport.GetProperty("changed").GetBoolean()) throw new InvalidOperationException("status after lazy load: late change not reported");
                    if (lateReport.GetProperty("since").GetString() != MouseActions.NameOf("click", kind)) throw new InvalidOperationException($"late change attributed to {lateReport.GetProperty("since")}");
                    var lr = lateReport.GetProperty("region");
                    var lateRegion = new Rectangle(lr.GetProperty("x").GetInt32(), lr.GetProperty("y").GetInt32(), lr.GetProperty("width").GetInt32(), lr.GetProperty("height").GetInt32());
                    if (!status.Content.OfType<ImageContentBlock>().Any()) throw new InvalidOperationException("late change without image");
                    if (saveDirectory is not null) File.WriteAllBytes(Path.Combine(saveDirectory, "late change.png"), Png(status.Content.OfType<ImageContentBlock>().Last()));
                    report.Add($"{"late change (status)",-24} changed=True  region={lateRegion.X},{lateRegion.Y} {lateRegion.Width}x{lateRegion.Height} since={lateReport.GetProperty("since")} {lateReport.GetProperty("secondsAgo")}s settled={lateReport.GetProperty("settled")}");
                    if (!lateRegion.IntersectsWith(lazyRect) || lateRegion.Height < lazyRect.Height - 4) throw new InvalidOperationException($"late change region {lateRegion} does not cover the lazy panel {lazyRect}");
                    var again = LateOf(ToolGuard.Read(MouseController.Position), "position after report");
                    if (again.GetProperty("changed").GetBoolean()) throw new InvalidOperationException("the same late change was reported twice");
                    report.Add($"{"late change (position)",-24} changed=False (already reported)");
                    // Lazy click: the same 2 s reaction must be in the click's own feedback.
                    var lazyFb = await Step("lazy click (wait)", () => MouseActions.ClickLazy(mouse, kind, "left", 1, 9000, default), expectChange: true,
                        mustContain: Rectangle.Inflate(lazyRect, -2, -2));
                    if (lazyFb.GetProperty("settledMs").GetInt32() < 2000) throw new InvalidOperationException("lazy click returned before the 2 s reaction");
                    // Quick click: no feedback image, returns at once.
                    var quickClock = System.Diagnostics.Stopwatch.StartNew();
                    var quick = await MouseActions.ClickQuick(mouse, kind, "left", 1, default);
                    if (quick.IsError == true || quick.Content.Count != 1 || quick.Content[0] is not TextContentBlock) throw new InvalidOperationException("quick click must return exactly one text block (no feedback, no late-change section)");
                    report.Add($"{"quick click",-24} no image, returned in {quickClock.ElapsedMilliseconds} ms");
                    if (quickClock.ElapsedMilliseconds > 1500) throw new InvalidOperationException("quick click was not quick");
                    await Task.Delay(2600); // let the quick click's lazy reaction happen before releasing
                    await Step("release", () => ToolGuard.Act("desktop_release_buttons", FeedbackFocus.Pointer, null, () => { mouse.ReleaseAll(); return new { released = true }; }), expectChange: false);

                    foreach (var line in report) Console.WriteLine("  " + line);
                    Console.WriteLine($"PASS ({(kind == InputKind.Device ? device?.Name : "SendInput")}): feedback detected and cropped every visible change (click caret, typing at the caret, scroll down/up over 60 % of the box, drag selection, a reaction 350 ms after the click, a lazy load 2 s later reported once on the next call, the lazy click waiting for it, the quick click without image) and reported no change for moves without a visible effect on the verified test window.");
                    result = 0;
                }
                catch (Exception e)
                {
                    foreach (var line in report) Console.WriteLine("  " + line);
                    Console.Error.WriteLine("FAIL: " + e.Message);
                }
                finally
                {
                    mouse.ReleaseAll();
                    try { await mouse.Move(InputKind.Injected, original.X, original.Y, 0); } catch { }
                    form.BeginInvoke(form.Close);
                }
            });
        };
        Application.Run(form);
        return result;
    }
}
