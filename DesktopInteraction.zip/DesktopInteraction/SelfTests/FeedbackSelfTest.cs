using System.Text.Json;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using ModelContextProtocol.Protocol;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.SelfTests;

// Visual feedback without input: change detection on synthetic images, anchor box placement,
// and one real before/after capture at the current pointer (reads the screen only).
internal static class FeedbackSelfTest
{
    internal static int Run()
    {
        try
        {
            void Require(bool value, string message) { if (!value) throw new Exception("Feedback self-test failed: " + message); }

            using var a = Filled(300, 200, Color.White);
            using var b = Filled(300, 200, Color.White);
            Require(VisualFeedback.ChangedBounds(a, b, []) is null, "identical images reported as changed");
            b.SetPixel(10, 20, Color.FromArgb(255, 250, 250, 250));
            Require(VisualFeedback.ChangedBounds(a, b, []) is null, "noise below threshold reported as changed");
            using (var g = Graphics.FromImage(b)) g.FillRectangle(Brushes.Black, 120, 50, 30, 10);
            Require(VisualFeedback.ChangedBounds(a, b, []) == new Rectangle(120, 50, 30, 10), "changed bounds wrong");
            Require(VisualFeedback.ChangedBounds(a, b, [new Rectangle(100, 40, 60, 30)]) is null, "ignored (cursor marker) area not ignored");
            using (var g = Graphics.FromImage(b)) g.FillRectangle(Brushes.Red, 280, 190, 5, 5);
            Require(VisualFeedback.ChangedBounds(a, b, [new Rectangle(100, 40, 60, 30)]) == new Rectangle(280, 190, 5, 5), "change outside ignored area lost");
            Require(VisualFeedback.Expand(new Rectangle(5, 5, 10, 10), 16, new Size(300, 200)) == new Rectangle(0, 0, 31, 31), "margin not clipped to image");

            var area = new Rectangle(0, 0, 1920, 1080);
            Require(VisualFeedback.Box(new Point(500, 500), area) == new Rectangle(450, 450, 100, 100), "anchor box not centred");
            Require(VisualFeedback.Box(new Point(3, 1078), area) == new Rectangle(0, 980, 100, 100), "anchor box not kept inside the monitor");

            // Real capture at the current pointer, no input
            using var before = VisualFeedback.Begin(FeedbackFocus.Pointer, null);
            var blocks = VisualFeedback.Complete(before, FeedbackFocus.Pointer, new { probe = true });
            var text = ((TextContentBlock)blocks[0]).Text;
            Require(blocks.Count == 2 && blocks[1] is ImageContentBlock { MimeType: "image/png" }, "no PNG feedback: " + text);
            var feedback = JsonDocument.Parse(text).RootElement.GetProperty("feedback");
            var region = feedback.GetProperty("region");
            int width = region.GetProperty("width").GetInt32(), height = region.GetProperty("height").GetInt32();
            Require(width is > 0 and <= 40000 && height > 0, "feedback region empty");
            Console.WriteLine($"PASS: change detection (threshold, ignored marker areas, margins), anchor box placement, real capture at the pointer: {width}x{height} from {feedback.GetProperty("source").GetString()} ({feedback.GetProperty("basis").GetString()}). No input injected.");
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 1; }
    }

    private static Bitmap Filled(int w, int h, Color color)
    {
        var bitmap = new Bitmap(w, h, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bitmap);
        g.Clear(color);
        return bitmap;
    }
}
