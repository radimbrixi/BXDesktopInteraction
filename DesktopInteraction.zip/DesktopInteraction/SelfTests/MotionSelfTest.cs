using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.SelfTests;

// Pure computation: human-like paths, driver report encoding and absolute-axis calibration. No input injected.
internal static class MotionSelfTest
{
    internal static int Run()
    {
        try
        {
            void Require(bool value, string message) { if (!value) throw new Exception(message); }
            var random = new Random(12345);
            var bounds = new Rectangle(-1920, -200, 1920 + 2560, 1440 + 200);

            for (int i = 0; i < 3000; i++)
            {
                var start = new Point(random.Next(bounds.Left, bounds.Right), random.Next(bounds.Top, bounds.Bottom));
                var end = new Point(random.Next(bounds.Left, bounds.Right), random.Next(bounds.Top, bounds.Bottom));
                double distance = Math.Sqrt(Math.Pow(end.X - start.X, 2) + Math.Pow(end.Y - start.Y, 2));
                int duration = HumanMotion.DefaultDuration(distance, random);
                var path = HumanMotion.Human(start, end, duration, bounds, random);
                Require(path.Count > 0 && path[^1].X == end.X && path[^1].Y == end.Y, "Path does not end on the target.");
                Require(path.All(s => bounds.Contains(s.X, s.Y)), "Path leaves the desktop.");
                Require(path.All(s => s.DelayMs >= 0), "Negative step delay.");
                if (distance > 50)
                {
                    int total = path.Sum(s => s.DelayMs);
                    Require(total >= duration * 0.75 && total <= duration * 1.35, $"Path timing {total} ms far from {duration} ms.");
                    Require(path.Count >= duration / HumanMotion.IntervalMs / 2, "Path sampled too coarsely.");
                    int straight = path.Count(s => DistanceToLine(start, end, s) < 0.5);
                    Require(straight < path.Count, "Path is a straight line.");
                }
            }

            var report = AbsoluteHidBackend.Encode(0x1234, 0x7FFF, 0b10101, -3, 127);
            Require(report.SequenceEqual(new byte[] { 1, 0x15, 0x34, 0x12, 0xFF, 0x7F, 0xFD, 0x7F }), "Report encoding mismatch with Public.h layout.");
            Require(Throws(() => AbsoluteHidBackend.Encode(32768, 0, 0, 0, 0)) && Throws(() => AbsoluteHidBackend.Encode(0, 0, 32, 0, 0)) && Throws(() => AbsoluteHidBackend.Encode(0, 0, 0, -128, 0)), "Out-of-range report accepted.");
            var move = AbsoluteHidBackend.EncodeRelative(-2, 300, 0b00011, 1, -1);
            Require(move.SequenceEqual(new byte[] { 2, 0x03, 0xFE, 0xFF, 0x2C, 0x01, 0x01, 0xFF }), "Relative report encoding mismatch with the USB/IP descriptor.");
            Require(Throws(() => AbsoluteHidBackend.EncodeRelative(-32768, 0, 0, 0, 0)) && Throws(() => AbsoluteHidBackend.EncodeRelative(0, 32768, 0, 0, 0)), "Out-of-range relative report accepted.");

            // Windows maps the device to the primary monitor (0..1919) while we assumed the virtual desktop (-1920..2559).
            var axis = AxisMap.FromRange(-1920, 4480);
            int Device(ushort value) => (int)Math.Round(value * 1919 / 32767.0);
            foreach (int target in new[] { 100, 1500, 640, 1919, 0, 1234 })
            {
                for (int attempt = 0; attempt < 4; attempt++)
                {
                    ushort sent = axis.ToDevice(target);
                    int actual = Device(sent);
                    if (actual == target) break;
                    axis.Learn(sent, actual, target);
                }
                Require(Device(axis.ToDevice(target)) == target, $"Axis calibration did not converge for {target} ({axis}).");
            }

            // Keyboard report and SendKeys syntax.
            Require(AbsoluteHidBackend.EncodeKeyboard(0x02, 0x28).SequenceEqual(new byte[] { 3, 0x02, 0x28, 0, 0, 0, 0, 0 }), "Keyboard report encoding mismatch with the USB/IP descriptor.");
            string Keys(string s) => string.Join(" ", KeySequence.Parse(s));
            Require(Keys("~{ENTER}{esc}") == "Enter Enter Escape", "Enter/Escape parsing.");
            Require(Keys("^c%{F4}+{TAB}#r") == "Ctrl+c Alt+F4 Shift+Tab Win+r", "Modifier parsing.");
            Require(Keys("^+(ab)c") == "Ctrl+Shift+a Ctrl+Shift+b c", "Group parsing.");
            Require(Keys("{LEFT 3}") == "Left Left Left", "Repeat parsing.");
            Require(Keys("{+}{^}{%}{~}{(}{)}{{}{}}{#}") == "+ ^ % ~ ( ) { } #", "Literal parsing.");
            Require(Keys("{BS}{BKSP}{DEL}{INS}{HOME}{END}{PGUP}{PGDN}{UP}{DOWN}{RIGHT}{F1}{F16}{F24}{CAPSLOCK}{NUMLOCK}{SCROLLLOCK}{PRTSC}{BREAK}{HELP}{ADD}{SUBTRACT}{MULTIPLY}{DIVIDE}{APPS}{WIN}{SPACE}")
                .Split(' ').Length == 27, "Named keys.");
            foreach (var bad in new[] { "^%{DEL}", "#l", "^%{F12}", "(a", "a)", "{NOPE}", "^", "{LEFT 0}", "{ENTER" })
                Require(ThrowsArgument(() => KeySequence.Parse(bad)), $"Key sequence '{bad}' was accepted.");

            Console.WriteLine("PASS: 3000 human-like paths (exact end, in bounds, timing, curvature), driver/keyboard report encoding/limits, absolute-axis calibration, SendKeys parsing and refused shortcuts. No input injected.");
            return 0;
        }
        catch (Exception e) { Console.Error.WriteLine(e); return 1; }
    }

    private static bool Throws(Action action) { try { action(); return false; } catch (ArgumentOutOfRangeException) { return true; } }

    private static bool ThrowsArgument(Action action) { try { action(); return false; } catch (ArgumentException) { return true; } }

    private static double DistanceToLine(Point a, Point b, HumanMotion.Step p)
    {
        double dx = b.X - a.X, dy = b.Y - a.Y, length = Math.Sqrt(dx * dx + dy * dy);
        return Math.Abs(dy * p.X - dx * p.Y + b.X * a.Y - b.Y * a.X) / length;
    }
}
