<#
.SYNOPSIS
  Renders the graphical manual Docs\Manual.html to Docs\Extedo.AutoTest.Ai.Mcp.DesktopInteraction-Manual.pdf
  with headless Microsoft Edge (or Chrome). No other tools needed.

.PARAMETER Browser
  Path to msedge.exe or chrome.exe. Default: Edge, then Chrome, from their standard install folders.

.EXAMPLE
  .\Scripts\Build-ManualPdf.ps1
#>
param([string]$Browser)
$ErrorActionPreference = 'Stop'
$docs = Join-Path $PSScriptRoot '..\Docs' | Resolve-Path
$html = Join-Path $docs 'Manual.html'
$pdf = Join-Path $docs 'Extedo.AutoTest.Ai.Mcp.DesktopInteraction-Manual.pdf'
if (-not $Browser) {
    $Browser = @(
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe"
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1
}
if (-not $Browser) { throw 'Neither Edge nor Chrome found; pass -Browser <path>.' }
$profileDir = Join-Path ([IO.Path]::GetTempPath()) "manual-pdf-$PID"
try {
    $uri = ([Uri]$html).AbsoluteUri
    & $Browser --headless=new --disable-gpu --no-first-run "--user-data-dir=$profileDir" --no-pdf-header-footer "--print-to-pdf=$pdf" $uri 2>$null | Out-Null
    $deadline = (Get-Date).AddSeconds(60)
    while (-not (Test-Path $pdf) -and (Get-Date) -lt $deadline) { Start-Sleep -Milliseconds 300 }
    if (-not (Test-Path $pdf)) { throw "PDF was not created: $pdf" }
    Write-Output "Created $pdf ($([math]::Round((Get-Item $pdf).Length / 1KB)) KB)"
}
finally { Remove-Item $profileDir -Recurse -Force -ErrorAction SilentlyContinue }
