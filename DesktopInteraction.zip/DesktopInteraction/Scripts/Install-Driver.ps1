#Requires -RunAsAdministrator
<#
.SYNOPSIS
  Installs or removes the Extedo virtual mouse driver (Root\ExtedoVirtualMouse) on a test VM / tester machine.

.DESCRIPTION
  Uses the MCP server executable (--driver-install / --driver-uninstall), so no WDK is needed on the target.
  -TrustTestCertificate imports the WDK test certificate into LocalMachine Root and TrustedPublisher.
  Use that ONLY on test VMs with test signing enabled; never on a machine that is not a disposable test system.

.EXAMPLE
  .\Install-Driver.ps1 -Package ..\Driver\Package -TrustTestCertificate
  .\Install-Driver.ps1 -Uninstall
#>
param(
    [string]$Package = "$PSScriptRoot\..\Driver\ExtedoVirtualMouse\x64\Release\ExtedoVirtualMouse",
    [string]$Executable = "$PSScriptRoot\..\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe",
    [switch]$TrustTestCertificate,
    [switch]$Uninstall
)
$ErrorActionPreference = 'Stop'
$exe = (Resolve-Path $Executable).Path

if ($Uninstall) {
    & $exe --driver-uninstall
    if ($LASTEXITCODE -ne 0) { throw "Uninstall failed ($LASTEXITCODE)." }
    return
}

$packagePath = (Resolve-Path $Package).Path
$inf = Join-Path $packagePath 'ExtedoVirtualMouse.inf'
foreach ($file in 'ExtedoVirtualMouse.inf', 'ExtedoVirtualMouse.sys', 'ExtedoVirtualMouse.cat') {
    if (-not (Test-Path (Join-Path $packagePath $file))) { throw "Driver package incomplete: $file missing in $packagePath" }
}

$catalog = Get-AuthenticodeSignature (Join-Path $packagePath 'ExtedoVirtualMouse.cat')
Write-Output "Catalog signer: $($catalog.SignerCertificate.Subject) [$($catalog.Status)]"

if ($TrustTestCertificate) {
    $cer = Get-ChildItem $packagePath, (Split-Path $packagePath) -Filter *.cer -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $cer) { throw "No .cer test certificate found next to the package. Export it from the build machine (DRIVER.md)." }
    Import-Certificate -FilePath $cer.FullName -CertStoreLocation Cert:\LocalMachine\Root | Out-Null
    Import-Certificate -FilePath $cer.FullName -CertStoreLocation Cert:\LocalMachine\TrustedPublisher | Out-Null
    Write-Output "Trusted test certificate $($cer.Name) (Root + TrustedPublisher)."
}

$boot = bcdedit /enum '{current}' | Out-String
$testSigning = $boot -match 'testsigning\s+Yes'
$attested = $catalog.SignerCertificate.Subject -match 'Microsoft Windows Hardware Compatibility Publisher'
if (-not $attested -and -not $testSigning) {
    Write-Warning "Package is not Microsoft-signed and test signing is OFF. Windows will refuse to load the driver. See DRIVER.md (test VM setup)."
}

& $exe --driver-install $inf
if ($LASTEXITCODE -ne 0) { throw "Install failed ($LASTEXITCODE)." }

Start-Sleep -Seconds 2
if (Test-Path '\\.\ExtedoVirtualMouse') { Write-Output 'Device \\.\ExtedoVirtualMouse is available.' }
Get-PnpDevice -FriendlyName 'Extedo Virtual Mouse*' -ErrorAction SilentlyContinue | Format-Table Status, Class, FriendlyName, InstanceId -AutoSize
Write-Output "Verify: $exe --self-test --device driver --input device"
