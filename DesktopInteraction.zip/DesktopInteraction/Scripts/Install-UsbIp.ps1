#Requires -RunAsAdministrator
<#
.SYNOPSIS
  Silently installs or removes the usbip-win2 client used by --device usbip (the default) (see USBIP.md).

.DESCRIPTION
  Calls the MCP server executable (--usbip-install / --usbip-uninstall). Only installers whose SHA-256 is pinned in
  Desktop\UsbIpInstaller.cs are run, unless -Sha256 confirms another one. A reboot is needed afterwards.

.EXAMPLE
  .\Install-UsbIp.ps1
  .\Install-UsbIp.ps1 -Uninstall
#>
param(
    [string]$Installer = "$PSScriptRoot\..\ThirdParty\usbip-win2\USBip-0.9.8.1-x64.exe",
    [string]$Executable = "$PSScriptRoot\..\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe",
    [string]$Sha256,
    [switch]$Uninstall
)
$ErrorActionPreference = 'Stop'
$exe = (Resolve-Path $Executable).Path

if ($Uninstall) { & $exe --usbip-uninstall }
elseif ($Sha256) { & $exe --usbip-install (Resolve-Path $Installer).Path --usbip-sha256 $Sha256 }
else { & $exe --usbip-install (Resolve-Path $Installer).Path }
if ($LASTEXITCODE -ne 0) { throw "usbip-win2 $(if ($Uninstall) { 'uninstall' } else { 'install' }) failed ($LASTEXITCODE)." }
Write-Output 'Reboot, then verify: <exe> --self-test --device usbip --input device'
