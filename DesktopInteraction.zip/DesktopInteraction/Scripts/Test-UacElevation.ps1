<#
.SYNOPSIS
  QA test: the virtual device mouse clicks the UAC "Yes" button to let an elevated PowerShell run, with the secure
  desktop (UAC) kept ON. The UAC prompt is on the secure desktop, which no normal program can see or capture, so the
  click is BLIND at a position measured once while the secure desktop is temporarily off (-Mode calibrate).

  This drives a real UAC consent prompt. It is for the developer's own test machine / VM, run and supervised by the
  user, and needs the server option --secure-desktop-input device (off by default). During -Mode run the user must
  NOT touch the mouse or keyboard: if the elevation succeeds without a human click, the device did it.

.PARAMETER Mode
  probe      - print the current secure-desktop state, monitor geometry and the server's inputDesktop field.
  calibrate  - (secure desktop must be OFF) trigger a UAC prompt on the normal desktop, screenshot it and try to
               locate the "Yes" button, so its screen position can be recorded for -Mode run.
  run        - (secure desktop ON) launch an elevated PowerShell and click the UAC "Yes" blindly with the device
               mouse at the measured position, then verify the elevated process really started.

.PARAMETER YesX  .PARAMETER YesY
  Screen pixel of the UAC "Yes" button (from calibrate). Also read from / written to the calibration file.

.PARAMETER CalibrationFile
  Where the measured position is stored (default: beside this script, uac-calibration.json).

.EXAMPLE
  # 1. Measure the Yes button once (secure desktop temporarily off - the user runs the elevated toggle commands the
  #    script prints, answering those UAC prompts themselves):
  .\Test-UacElevation.ps1 -Mode calibrate
  # 2. Turn the secure desktop back on, then run the real test (user does not touch mouse/keyboard):
  .\Test-UacElevation.ps1 -Mode run
#>
[CmdletBinding()]
param(
    [ValidateSet('probe', 'calibrate', 'run')] [string]$Mode = 'probe',
    [int]$YesX = -1,
    [int]$YesY = -1,
    [string]$CalibrationFile,
    [string]$Exe,
    [int]$UserIdleMs = 1500,
    [int]$SecureWaitMs = 10000
)

$ErrorActionPreference = 'Stop'
$root = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
if (-not $CalibrationFile) { $CalibrationFile = Join-Path $root 'uac-calibration.json' }
if (-not $Exe) { $Exe = Join-Path $root '..\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe' }
Add-Type -AssemblyName System.Drawing, System.Windows.Forms

# ---- Windows helpers (screen capture incl. layered windows, secure-desktop state) ----
Add-Type @'
using System; using System.Runtime.InteropServices;
public static class Uac {
    [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr h);
    [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr h, IntPtr dc);
    [DllImport("gdi32.dll")]  static extern bool BitBlt(IntPtr d, int x, int y, int w, int h, IntPtr s, int sx, int sy, int op);
    [DllImport("user32.dll", SetLastError = true)] static extern IntPtr OpenInputDesktop(uint flags, bool inherit, uint access);
    [DllImport("user32.dll")] static extern bool CloseDesktop(IntPtr d);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern bool GetUserObjectInformation(IntPtr h, int i, System.Text.StringBuilder p, int n, out int needed);
    public static void Blt(IntPtr dc, int x, int y, int w, int h) { var s = GetDC(IntPtr.Zero); BitBlt(dc, 0, 0, w, h, s, x, y, 0x00CC0020 | 0x40000000); ReleaseDC(IntPtr.Zero, s); }
    public static string InputDesktop() {
        IntPtr d = OpenInputDesktop(0, false, 0x0001);
        if (d == IntPtr.Zero) return "<secure/unreadable>";
        try { var n = new System.Text.StringBuilder(256); int need; return GetUserObjectInformation(d, 2, n, n.Capacity * 2, out need) ? n.ToString() : "<unknown>"; }
        finally { CloseDesktop(d); }
    }
}
'@

function Shot($x, $y, $w, $h, $path) {
    $b = [Drawing.Bitmap]::new($w, $h); $g = [Drawing.Graphics]::FromImage($b)
    $dc = $g.GetHdc(); [Uac]::Blt($dc, $x, $y, $w, $h); $g.ReleaseHdc($dc); $g.Dispose()
    $b.Save($path, [Drawing.Imaging.ImageFormat]::Png); $b.Dispose()
}

function Secure-State {
    $v = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System').PromptOnSecureDesktop
    [pscustomobject]@{ PromptOnSecureDesktop = $v; InputDesktop = [Uac]::InputDesktop() }
}

$togglePrint = {
    param($value, $label)
    Write-Host "Run this in an ELEVATED PowerShell (you answer its UAC prompt), to $label the secure desktop:" -ForegroundColor Yellow
    Write-Host "  Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' PromptOnSecureDesktop $value" -ForegroundColor Cyan
}

# ---- minimal MCP stdio client ----
function New-Mcp([string[]]$ServerArgs) {
    $psi = [Diagnostics.ProcessStartInfo]::new((Resolve-Path $Exe))
    $ServerArgs | ForEach-Object { $psi.ArgumentList.Add($_) }
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $p = [Diagnostics.Process]::Start($psi)
    $script:McpId = 0
    $init = Mcp-Raw $p 'initialize' @{ protocolVersion = '2025-06-18'; capabilities = @{}; clientInfo = @{ name = 'uac-test'; version = '1' } }
    $null = $init
    $p.StandardInput.WriteLine('{"jsonrpc":"2.0","method":"notifications/initialized"}')
    return $p
}
function Mcp-Raw($p, $method, $params) {
    $p.StandardInput.WriteLine((@{ jsonrpc = '2.0'; id = ++$script:McpId; method = $method; params = $params } | ConvertTo-Json -Depth 10 -Compress))
    $t = $p.StandardOutput.ReadLineAsync()
    if (-not $t.Wait(60000)) { throw 'MCP timeout' }
    $r = $t.Result | ConvertFrom-Json
    if ($r.error) { throw ($r.error | ConvertTo-Json -Compress) }
    return $r.result
}
function Tool($p, $name, $args2) {
    $r = Mcp-Raw $p 'tools/call' @{ name = $name; arguments = $args2 }
    $text = ($r.content | Where-Object type -eq 'text' | Select-Object -First 1).text
    [pscustomobject]@{ IsError = [bool]$r.isError; Json = ($text | ConvertFrom-Json); Text = $text }
}
function Status($p) { (Tool $p 'desktop_status' @{}).Json }

function Load-Calibration {
    if ($YesX -ge 0 -and $YesY -ge 0) { return @{ x = $YesX; y = $YesY } }
    if (Test-Path $CalibrationFile) { $c = Get-Content $CalibrationFile -Raw | ConvertFrom-Json; return @{ x = [int]$c.x; y = [int]$c.y } }
    throw "No calibration. Run -Mode calibrate first, or pass -YesX -YesY."
}

# ================================ MODES ================================
switch ($Mode) {

'probe' {
    Secure-State | Format-List
    $pri = [Windows.Forms.Screen]::PrimaryScreen.Bounds
    "primary: $pri"
    if (Test-Path $CalibrationFile) { "calibration: " + (Get-Content $CalibrationFile -Raw) } else { "calibration: none ($CalibrationFile)" }
    "exe: $((Resolve-Path $Exe -ErrorAction SilentlyContinue))"
}

'calibrate' {
    $s = Secure-State
    if ($s.PromptOnSecureDesktop -ne 0) {
        Write-Host "Secure desktop is ON - the UAC prompt cannot be seen to measure it." -ForegroundColor Red
        & $togglePrint 0 'temporarily DISABLE'
        Write-Host "Then re-run: .\Test-UacElevation.ps1 -Mode calibrate"
        return
    }
    $pri = [Windows.Forms.Screen]::PrimaryScreen.Bounds
    $outDir = Split-Path $CalibrationFile
    $png = Join-Path $outDir 'uac-calibration.png'
    Write-Host "Triggering a UAC prompt on the normal desktop (it will be cancelled after the screenshot)..." -ForegroundColor Yellow
    # A harmless elevation request: if ever accepted it just exits. We only need the prompt to appear.
    $proc = Start-Process -FilePath powershell -Verb RunAs -ArgumentList '-NoProfile', '-Command', 'exit' -PassThru -ErrorAction SilentlyContinue
    Start-Sleep -Milliseconds 1600
    Shot $pri.X $pri.Y $pri.Width $pri.Height $png
    Write-Host "Saved $png - open it and read the centre of the 'Yes' button." -ForegroundColor Green
    # Best-effort auto-detect via UI Automation (often blocked for the elevated consent UI).
    $auto = $null
    try {
        Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
        $root = [Windows.Automation.AutomationElement]::RootElement
        $cond = [Windows.Automation.PropertyCondition]::new([Windows.Automation.AutomationElement]::NameProperty, 'Yes')
        $el = $root.FindFirst([Windows.Automation.TreeScope]::Descendants, $cond)
        if ($el) { $r = $el.Current.BoundingRectangle; $auto = @{ x = [int]($r.X + $r.Width / 2); y = [int]($r.Y + $r.Height / 2) } }
    } catch {}
    Write-Host "Dismiss the UAC prompt now (click No, or press Esc) if it is still up." -ForegroundColor Yellow
    if ($auto) {
        @{ x = $auto.x; y = $auto.y; measuredAt = (Get-Date).ToString('o'); method = 'uia' } | ConvertTo-Json | Set-Content $CalibrationFile
        Write-Host "Auto-detected Yes at ($($auto.x),$($auto.y)); saved to $CalibrationFile." -ForegroundColor Green
    } else {
        Write-Host "Could not auto-detect (expected for the elevated consent UI). After reading the PNG, save it with:" -ForegroundColor Yellow
        Write-Host "  @{x=<X>;y=<Y>;measuredAt=(Get-Date).ToString('o');method='manual'} | ConvertTo-Json | Set-Content '$CalibrationFile'" -ForegroundColor Cyan
    }
}

'run' {
    $cal = Load-Calibration
    $s = Secure-State
    Write-Host "Secure desktop PromptOnSecureDesktop=$($s.PromptOnSecureDesktop); clicking Yes blindly at ($($cal.x),$($cal.y))." -ForegroundColor Yellow
    if ($s.PromptOnSecureDesktop -ne 1) { Write-Host "Note: secure desktop is OFF - this run does not exercise the blind/secure path." -ForegroundColor Yellow }
    Write-Host "Do NOT touch the mouse or keyboard until it finishes." -ForegroundColor Red

    $marker = Join-Path ([IO.Path]::GetTempPath()) ("uac-elev-" + [guid]::NewGuid().ToString('N') + '.txt')
    $inner = "`$hi=[bool]((whoami /groups)|Select-String 'S-1-16-12288'); Set-Content -LiteralPath '$marker' -Value (`"pid=`$PID elevated=`$hi user=`$env:USERNAME`") -Encoding UTF8"
    $enc = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($inner))

    $mcp = New-Mcp @('--device', 'usbip', '--secure-desktop-input', 'device', '--user-idle-ms', "$UserIdleMs", '--frame', 'on')
    try {
        $st = Status $mcp
        "device available: $($st.inputs.device.available); secureDesktopDeviceInput: $($st.secureDesktopDeviceInput); remote: $($st.remoteDesktopSession)"
        if (-not $st.inputs.device.available) { throw "Device mouse not available: $($st.inputs.device.details | ConvertTo-Json -Compress -Depth 6)" }
        if (-not $st.secureDesktopDeviceInput) { throw "Server did not enable --secure-desktop-input device." }

        # 1. Pre-position on the normal desktop so the absolute mapping is calibrated to the exact pixel.
        $pre = Tool $mcp 'desktop_mouse_move' @{ x = $cal.x; y = $cal.y; durationMs = 500 }
        "pre-position: isError=$($pre.IsError) cursor=$($pre.Json.result.cursor | ConvertTo-Json -Compress)"

        # 2. Request elevation -> UAC appears on the secure desktop.
        Write-Host "Launching elevated PowerShell (UAC prompt should appear)..." -ForegroundColor Yellow
        $elev = Start-Process -FilePath powershell -Verb RunAs -ArgumentList '-NoProfile', '-WindowStyle', 'Hidden', '-EncodedCommand', $enc -PassThru -ErrorAction SilentlyContinue

        # 3. Wait until the secure desktop is active.
        $sw = [Diagnostics.Stopwatch]::StartNew(); $sawSecure = $false
        while ($sw.ElapsedMilliseconds -lt $SecureWaitMs) {
            if ([Uac]::InputDesktop() -ne 'Default') { $sawSecure = $true; break }
            Start-Sleep -Milliseconds 150
        }
        "secure desktop active: $sawSecure after $($sw.ElapsedMilliseconds) ms (inputDesktop=$([Uac]::InputDesktop()))"
        Start-Sleep -Milliseconds 400   # let the dialog finish drawing

        # 4. Blind click Yes with the device mouse (move skips cursor read-back on the secure desktop).
        $mv = Tool $mcp 'desktop_mouse_move' @{ x = $cal.x; y = $cal.y; durationMs = 250 }
        "blind move: isError=$($mv.IsError)" ; if ($mv.IsError) { "  -> $($mv.Json.result.error)" }
        $clk = Tool $mcp 'desktop_mouse_click' @{ button = 'left'; count = 1 }
        "blind click: isError=$($clk.IsError)" ; if ($clk.IsError) { "  -> $($clk.Json.result.error)" }

        # 5. Wait for the secure desktop to clear and the elevated marker to appear.
        $sw2 = [Diagnostics.Stopwatch]::StartNew()
        while ($sw2.ElapsedMilliseconds -lt 8000 -and -not (Test-Path $marker)) { Start-Sleep -Milliseconds 150 }

        if (Test-Path $marker) {
            $line = Get-Content $marker -Raw
            if ($line -match 'elevated=True') {
                Write-Host "PASS: the device clicked UAC Yes; an elevated process ran. [$($line.Trim())]" -ForegroundColor Green
            } else {
                Write-Host "PARTIAL: a process ran but was not elevated. [$($line.Trim())]" -ForegroundColor Yellow
            }
        } else {
            Write-Host "FAIL: no elevated process within the timeout. The click likely missed; re-run -Mode calibrate." -ForegroundColor Red
            # Cancel a still-open prompt with the device Escape key (also allowed on the secure desktop).
            if ([Uac]::InputDesktop() -ne 'Default') { $null = Tool $mcp 'desktop_press_keys' @{ keys = '{ESC}' } }
        }
    }
    finally {
        $mcp.StandardInput.Close(); if (-not $mcp.WaitForExit(5000)) { $mcp.Kill() }
        if (Test-Path $marker) { Remove-Item $marker -ErrorAction SilentlyContinue }
    }
}

}
