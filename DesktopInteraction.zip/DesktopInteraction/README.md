# Extedo.AutoTest.Ai.Mcp.DesktopInteraction

Local stdio MCP server that lets an AI client (LM Studio, Claude, VS Code, ...) control the Windows desktop:
mouse, printable text entry, keys and shortcuts, screenshots and window focus. **Start with [MANUAL.md](MANUAL.md)** (setup, every
scenario incl. UAC, admin windows, VMs and Remote Desktop, troubleshooting). Built on the official C# MCP SDK
(`ModelContextProtocol` NuGet package), .NET 10, WinForms (cursor marker overlay, tray icon, emergency hotkey).

## Build and connect

```powershell
dotnet build Research\DesktopInteraction -c Release
```

Add the entry from `mcp.example.json` to the client configuration (LM Studio: *Program → Install → Edit mcp.json*),
pointing `command` to the built `.exe`. Do not use `dotnet run` as the MCP command: build output on stdout corrupts the protocol.

`--demo` shows only the cursor marker without serving MCP (Visual Studio launch profile "Cursor marker preview").

Options (put them in `args` of the MCP entry). `--help` (also `-help`, `-h`, `-?`, `/?`, `/h`) prints all options and modes (self-tests, installers, device
host); unknown options or missing values exit with code 2. Full reference: [MANUAL.md](MANUAL.md#8-command-line-reference).

| Option | Default | Meaning |
| --- | --- | --- |
| `--device usbip\|driver\|none` | `usbip` | What backs the device mouse tools. `usbip`: virtual USB mouse attached by the Microsoft-signed usbip-win2 client, no own driver ([USBIP.md](USBIP.md)). `driver`: own Extedo virtual mouse driver, test-signed ([DRIVER.md](DRIVER.md)). `none`: device tools report an error. The injected tools are always available. |
| `--usbip-attach auto\|manual`, `--usbip-exe <path>` | `auto` | usbip device: run `usbip attach` automatically, and where `usbip.exe` is. |
| `--frame on\|off\|captured` | `on` | Blue glowing frame around every monitor while an AI drives (hidden from all screen capture). `captured`: also visible in screenshots and recordings (demo videos). |
| `--device-sharing on\|off` | `on` | `on`: all instances (AI clients) share one device host process that owns the virtual mouse. `off`: each instance owns its own device. |
| `--device-host-idle-s <s>` | `600` | Device host lifetime after the last instance closed. |
| `--user-idle-ms <0-60000>` | `7000` | The user has priority: input waits until the user's own mouse and keyboard have been idle this long (0 = off). |
| `--user-wait-ms <0-600000>` | `30000` | Longest wait for that idle time; then the tool returns an error without sending input. |
| `--motion human\|linear` | `human` | `human`: curved, variably paced paths (~125 Hz), overshoot on long moves (kept on the target monitor), natural click/drag pauses, distance-based durations. |
| `--secure-desktop-input off\|device` | `off` | `device`: the virtual device may operate the secure desktop (UAC prompt) with a blind click at a position measured beforehand (it cannot be captured); injected input stays refused. Test machines only (MANUAL.md 6.4, `Scripts\Test-UacElevation.ps1`). |

## Tools

Every tool is a separate MCP tool (one C# method each, in `Tools\`), so clients such as LM Studio show an individual
checkbox per tool and you can allow only what you need. The mouse exists twice: **device input** (virtual USB mouse,
real device input like a hand on a mouse) and **injected input** (`_injected`, Windows SendInput, no driver). Untick
one set to forbid it. `desktop_status` tells the model which set to use (device input does not reach a Remote
Desktop session, so the device tools refuse there).

| Tool | Kind | Arguments |
| --- | --- | --- |
| `desktop_status` | read-only | none - input methods (device attached, Remote Desktop session, recommended mouse tools), monitor `layout` (monitors, orientation, shared edges), pointer, emergency-stop and ownership state |
| `desktop_mouse_position` | read-only | none |
| `desktop_capture` | read-only | `scope` = `primary` (default) / `monitor` (+`monitorIndex`) / `desktop`; returns PNG + bounds |
| `desktop_list_windows` | read-only | none |
| `desktop_take_control` | control | none - claims the interaction baton |
| `desktop_focus_window` | input + feedback | `titlePart` |
| `desktop_type_text` | input + feedback | `text` (1-1000 printable chars, no Enter/control keys). Device keyboard when available (real key presses with the window's keyboard layout; reaches elevated windows), else SendInput; result `input` says which, and lists characters the layout cannot type (sent with SendInput) |
| `desktop_type_text_injected` | input + feedback | `text` - always SendInput (any Unicode character; blocked by elevated windows) |
| `desktop_press_keys` / `desktop_press_keys_injected` | input + feedback | `keys` in Windows Forms SendKeys syntax (`{ENTER}`, `{ESC}`, `^c`, `%{F4}`, `{LEFT 5}`, ...) plus `#` = Win; device keyboard when available. Refuses Ctrl+Alt+Del, Win+L, Ctrl+Alt+F12. Syntax: MANUAL.md 6.1 |
| `desktop_mouse_move` / `desktop_mouse_move_injected` | input + feedback | `x`, `y`, `durationMs` (0-10000; -1 = human-like, default) |
| `desktop_mouse_click` / `desktop_mouse_click_injected` | input + feedback | `button` (left/right/middle/x1/x2), `count` (1-2); waits up to 0.5 s for a reaction |
| `desktop_mouse_click_quick` / `desktop_mouse_click_quick_injected` | input, no feedback | `button`, `count`; returns at once (about 0.15 s): no screen capture at all, no feedback and no late-change section |
| `desktop_mouse_click_lazy` / `desktop_mouse_click_lazy_injected` | input + feedback | `button`, `count`, `waitMs` (500-60000, default 9000): waits up to `waitMs` for a reaction, then until the area is quiet for 1 s (at most 9 s after the first change); for lazy loading, progress bars, slow dialogs |
| `desktop_mouse_button` / `desktop_mouse_button_injected` | input + feedback | `action` (down/up), `button` |
| `desktop_mouse_drag` / `desktop_mouse_drag_injected` | input + feedback | `fromX`, `fromY`, `toX`, `toY`, `durationMs` (-1 = human-like, default), `button` |
| `desktop_mouse_scroll` / `desktop_mouse_scroll_injected` | input + feedback | `delta` (120 per notch; device: multiples of 120), `axis` (vertical/horizontal) |
| `desktop_release_buttons` | input + feedback | none - releases buttons held by either input method |

Tool schemas use only plain JSON types (no `["integer","null"]` unions), which some local-model clients cannot convert.

Tools also carry MCP annotations (`readOnlyHint`, `destructiveHint`, ...) that clients can use for approval prompts.

### Visual feedback (forced on every input tool)

Every input tool returns its JSON result followed by a PNG, also when the action fails (`isError`), so the model
always sees the effect like a user would:

- **Anchor**: mouse tools use the pointer; `desktop_type_text` and `desktop_focus_window` use the text caret (the
  pointer when the application has no Win32 caret, for example many browsers and WPF apps).
- **Limit**: the top-level window under the anchor (the foreground window for keyboard tools). Outside a known
  window - desktop, or a VM / Remote Desktop viewer (vmconnect, VMware, VirtualBox, mstsc, msrdc) whose content has no
  window information - the limit is the 100x100 px box around the anchor.
- **Timing**: no fixed delay. After the action the window is captured every 80 ms until it has changed and two captures in a row are equal (late rendering, animated scrolling); with no change it waits 500 ms, never longer than 9 s (a screen that keeps changing, such as a loading page or video, is captured after 9 s). `settledMs` reports the wait.
- **Crop**: the area that changed between the capture before the action and the settled capture, joined with the 100x100
  box around the anchor, inside the limit. If a different window appears at the anchor (menu, dialog), the whole
  new window is returned. The blinking text caret is ignored, so it never counts as a change. The cursor marker is drawn into the image (screen captures do not contain it).
- Crops larger than 1280 px on the longest side are scaled down. The metadata gives `region`, `scale`
  (desktop = region.x + u / scale), `changed`, `basis`, window title and process.

### Monitor layout and routing

`desktop_status` → `layout` lists every monitor (index, position, size, last pixel, portrait/landscape) and every
**shared edge**: where two monitors touch and over which range, for example
`DISPLAY3 right | DISPLAY4 left at x=-4321|-4320, y -1060..1099`. The pointer can only pass between monitors there.

Mouse moves and drags between monitors follow a **planned route**: a shortest path across shared edges (Dijkstra
over crossings), each crossing slid along its edge toward the straight line but kept at least 50 px (or a quarter
of the edge) from the corners, so routes never enter gaps between monitors or Windows' sticky corners. The motion is
one continuous human-like (or linear) sweep along the route, each stretch held inside its monitor, with the
overshoot only at the end on the target monitor. Within one monitor the path stays on that monitor. Targets in a
gap between monitors are rejected. Monitors touching only at a corner have no shared edge (direct move as fallback).

### Late changes (lazy loading) on the next call

Every tool result - read-only tools included, except the quick clicks - ends with a `lateChange` section about the previous action: the
server keeps the settled capture it showed for that action and, on the next call, compares the same area with the
screen now. Content that appeared after the action's result was returned (lazy loading, data rendered after a
progress bar, a dialog that came later) is reported with a text block and a crop of the changed part:

```json
{"lateChange":{"since":"desktop_mouse_click","secondsAgo":2.6,"changed":true,"settled":true,
  "note":"The area shown in the feedback of desktop_mouse_click changed after that result was returned ...",
  "region":{"x":127,"y":546,"width":746,"height":87},"scale":1,"window":"...","source":"window"}}
```

Without a change it is one line, `{"lateChange":{"since":"desktop_mouse_click","secondsAgo":4.1,"changed":false}}`.
`settled:false` means the area was still changing at that moment (call `desktop_status` again to see the result).
Each change is reported once; there is no background polling between calls. MCP clients do not put server-initiated
messages into the model's context, so the next tool result is where late changes reach the model.
Coordinates are physical pixels of the whole virtual desktop (monitors left/above the primary have negative origins).
Screenshot pixel `(u,v)` is desktop `(bounds.x+u, bounds.y+v)`.

## Safety and multiple instances

- **Ctrl+Alt+F12** latches an emergency stop for all running instances and releases held buttons. Only closing all
  instances resets it. Holding **Escape** cancels the running input operation.
- **The user has priority.** Before any input the server waits until the user's own mouse and keyboard have been idle
  for 7 s (`--user-idle-ms`, at most `--user-wait-ms`), and a running action stops as soon as the user touches them.
  User input is detected with Raw Input (also while other windows have the focus); the virtual mouse (found by its
  device ancestry: `VID_1209&PID_0001` or `ExtedoVirtualMouse`) and the instances' own SendInput are ignored.
  Limitation: injected input of other software (or Remote Desktop input without a device handle) counts as the user
  only while no instance is injecting. `desktop_status` → `user` shows the state.
- One shared Windows pointer, any number of AI clients (Copilot, Claude, LM Studio, ...), one server instance each.
  **Starting an instance does not take control**: whichever instance sends input takes the baton (input tools do so
  automatically, `desktop_take_control` explicitly); read-only tools never do. The superseded instance's in-flight
  input is cancelled. Coordination uses a session-local named mutex and shared memory.
- The cyan cursor marker is shown only while an instance is driving the pointer (and for 1.5 s after its last input),
  with a label naming the driving AI client (MCP `clientInfo`) more than 100 px below and right of the pointer (flipped
  at monitor edges), so it stays clear of what is being clicked. Idle and paused instances show nothing.
- **Blue frame** (modelled on OpenAI Codex computer use on Windows, which shows a capture border on every captured
  display plus a "ChatGPT is using your computer. Esc to cancel" overlay, none of it in its own screenshots): while an
  instance drives the desktop (and 6 s after its last input, so it stays during a multi-step task) every monitor gets a
  blue rim with a soft inset glow that pulses every 2 s and fades in/out in 300 ms, plus a top-centre banner
  "`<client>` is using your computer - Move the mouse or press a key to take over - Ctrl+Alt+F12 stops all". It is
  click-through, non-activating, topmost layered windows per monitor, rebuilt on display changes, and excluded from
  screen capture (`WDA_EXCLUDEFROMCAPTURE`), so neither this server's nor other AI tools' screenshots contain it.
  `--frame captured` keeps it in recordings, `--frame off` disables it.
- Input fails closed when no instance holds the emergency hotkey. Input is refused on the secure desktop (UAC, lock
  screen): it cannot be captured from the user session. See MANUAL.md, "UAC prompts".
- `desktop_capture` and the visual feedback expose what is visible on screen to the connected client. Connect only trusted local clients.
- SendInput is subject to Windows integrity rules (UIPI); the server never elevates itself.
- **Shared device:** the virtual mouse is owned by one *device host* process per Windows session
  (`--device-host`, started automatically and detached by the first instance that needs it; it inherits no handles,
  so it never keeps an AI client's stdio open). Every instance forwards its device input to it over the current-user
  pipe `\\.\pipe\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Device.<session>`, so device tools work in all AI
  clients at once. The host keeps calibration and button state, refuses requests from superseded instances (baton
  generation) and releases buttons held for the previous owner on takeover. It exits 10 minutes after the last
  instance closed (`--device-host-idle-s`), so restarting a client does not re-plug the device. While it runs it
  keeps its `.exe` open (stop it before rebuilding into the same folder). `desktop_status` → `inputs.device.details.host`
  shows its pid and connected instances. `--device-sharing off` restores a device per instance (first instance wins port 3240).

## Checks

```powershell
.\Scripts\Smoke-Test.ps1 -Capture       # stdio protocol, 25 tools, invalid-input rejection with feedback PNG, capture
.\Scripts\Test-MultiInstance.ps1        # two live clients: takeover, pause, hotkey recovery (no input injected)
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --coordination-self-test
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --device-host-self-test  # shared device host protocol with a fake device (no input)
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --motion-self-test     # paths, report encoding, calibration (no input)
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --usbip-self-test      # USB/IP protocol and USB mouse emulation over loopback (no input)
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --feedback-self-test   # change detection, anchor box, real capture at the pointer (no input)
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --layout-self-test     # routes on real and exotic synthetic monitor layouts (no input)
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --self-test --input device     # moves the real mouse on its own test window; hands off
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --self-test --input injected
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --feedback-live-test --input device   # own test window: feedback must catch typing, scrolling, selection, a 350 ms reaction, a 2 s lazy load on the next call, and report no change for plain moves; hands off
.\Scripts\Invoke-DesktopTool.ps1 -Tool desktop_status   # call one tool ad hoc (-ServerArguments '--device','none' to skip the USB device)
```
