# Extedo Desktop Interaction - user manual

Version 0.7.0. This manual explains how to install, configure and use the Extedo Desktop Interaction MCP server,
what exactly it does on your PC, and what works (and what does not) in special situations: elevated windows such as
an administrator PowerShell, UAC prompts, the lock screen, virtual machines in a window, Remote Desktop and several AI
clients at the same time. It also is the reference for every tool, every command-line option and every field of
`desktop_status`.

Developer background is in [README.md](README.md) (architecture, feedback algorithm, routing),
[USBIP.md](USBIP.md) (the virtual USB device) and [DRIVER.md](DRIVER.md) (the optional own driver).

Contents

1. [What it is](#1-what-it-is)
2. [Quick start](#2-quick-start)
3. [Setup](#3-setup)
4. [How it behaves on your desktop](#4-how-it-behaves-on-your-desktop)
5. [Device input and injected input](#5-device-input-and-injected-input)
6. [Scenarios](#6-scenarios)
7. [Tool reference](#7-tool-reference)
8. [Command-line reference](#8-command-line-reference)
9. [desktop_status reference](#9-desktop_status-reference)
10. [Several AI clients and the shared device host](#10-several-ai-clients-and-the-shared-device-host)
11. [Troubleshooting](#11-troubleshooting)
12. [Safety and privacy](#12-safety-and-privacy)
13. [Checks after an update](#13-checks-after-an-update)
14. [Files and glossary](#14-files-and-glossary)

---

## 1. What it is

An **MCP server**: a small local program that an AI client (Claude Code, Claude Desktop, GitHub Copilot in VS Code,
LM Studio, any other MCP client) starts and talks to over its standard input/output. Through it the AI can see and
use the Windows desktop like a person sitting in front of it:

- take screenshots of one monitor, the primary monitor or the whole desktop,
- move the mouse, click, double click, drag, scroll, press and release buttons,
- type text,
- press keys and shortcuts - Enter, Escape, Tab, arrows, F-keys, Ctrl+C, Alt+F4, Win+R, ... - written in the
  Windows Forms `SendKeys` syntax,
- list windows and bring one to the foreground.

It drives the **real Windows pointer and keyboard focus** - the same ones you use. There is no hidden second
desktop. That is why it waits for you, stops when you touch the mouse or keyboard, and shows clearly when an AI is
working (section 4).

How the parts fit together:

```text
 AI client (Claude Code, Copilot, LM Studio, ...)
     │  stdio (MCP JSON-RPC)                 one server process per AI client window/session
     ▼
 Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe        ── tray icon, cursor marker, blue frame, Ctrl+Alt+F12
     │                         │
     │ injected input          │ device input (named pipe, current user only)
     │ (Windows SendInput)     ▼
     │                   shared device host  (same .exe, --device-host, one per Windows session)
     │                         │ USB/IP over 127.0.0.1:3240
     │                         ▼
     │                   usbip-win2 (Microsoft-signed)  →  "Extedo Virtual Mouse and Keyboard (USB/IP)"
     ▼                         ▼
 Windows input  ◄──────────────┘   real HID device input: reaches admin windows, VM windows, games
```

By default the server uses a **virtual USB mouse and keyboard** ("device input"). Windows treats it like a real
device plugged into the PC, so it also works where simulated input is blocked or ignored: administrator windows,
virtual machine windows, games and applications that read Raw Input. Every input tool also exists as an
`_injected` variant that uses ordinary Windows `SendInput` and needs nothing installed.

## 2. Quick start

1. Build: `dotnet build Research\DesktopInteraction -c Release` (section 3.3).
2. Optional but recommended: install usbip-win2 once as administrator and reboot (section 3.2). Without it,
   everything works with injected input, except in administrator windows.
3. Register the server in your AI client (section 3.4), for Claude Code:

   ```powershell
   claude mcp add --scope user extedo-desktop-interaction -- "C:\_\Testing\Research\DesktopInteraction\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe"
   ```

4. Ask the AI: *"Call desktop_status and tell me which input methods are available."*
5. Ask for a task: *"Open Notepad and type Hello."* Do not touch mouse and keyboard while it works; move the
   mouse to take over at any time, press **Ctrl+Alt+F12** to stop all AI input.

All command-line options are listed by:

```powershell
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --help
```

## 3. Setup

### 3.1 Requirements

| Need | For | Notes |
| --- | --- | --- |
| Windows 10 or 11, x64 | everything | Desktop session (console or Remote Desktop). Not as a service. |
| .NET 10 SDK | building | Or a ready built `bin\Release\net10.0-windows` folder plus the .NET 10 Desktop Runtime. |
| usbip-win2 0.9.8.1 (Microsoft-signed) | device input (default `--device usbip`) | Installed once by you, as administrator, plus a reboot. The MCP server itself never installs anything. |
| An MCP client | using it | Claude Code, Claude Desktop, VS Code Copilot, LM Studio, ... |

Without usbip-win2 the server still starts and works: `desktop_status` reports the device as unavailable,
`desktop_type_text` / `desktop_press_keys` fall back to `SendInput`, and the AI uses the `_injected` mouse tools.
Only administrator windows, UAC prompts and some VM windows are then out of reach (section 5).

### 3.2 Install usbip-win2 (once per PC)

1. On a company PC ask IT / endpoint security first: usbip-win2 contains a (Microsoft-signed) kernel driver.
2. Create a restore point. The installation briefly resets all USB hubs: USB devices disconnect and reconnect.
3. Put the tested installer `USBip-0.9.8.1-x64.exe` into `ThirdParty\usbip-win2\` (download link and SHA-256 in
   [USBIP.md](USBIP.md)). The installer is only run when its SHA-256 matches the pinned value
   (`38cad6d4...518a`), or the value you confirm with `-Sha256` / `--usbip-sha256`.
4. In an **elevated** PowerShell (Run as administrator), from the repository root:

   ```powershell
   dotnet build Research\DesktopInteraction -c Release
   Research\DesktopInteraction\Scripts\Install-UsbIp.ps1
   ```

   The script calls `Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --usbip-install <installer>`, which runs the Inno
   Setup installer silently (`/VERYSILENT /SUPPRESSMSGBOXES /NORESTART`) and writes a log to
   `%TEMP%\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.usbip-install.log`.
5. **Reboot.** Check that `C:\Program Files\USBip\usbip.exe` exists.

Uninstall: `Scripts\Install-UsbIp.ps1 -Uninstall` (elevated), then reboot.

The alternative device, the Extedo test-signed driver (`--device driver`, mouse only, test VMs), is described in
[DRIVER.md](DRIVER.md) and installed with `Scripts\Install-Driver.ps1`.

### 3.3 Build

```powershell
dotnet build Research\DesktopInteraction -c Release
```

The program is
`Research\DesktopInteraction\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe`.
Check it with `--version` and `--help` (section 8).

**Rebuilding while it runs.** Every AI client keeps its own server process running, and the shared device host keeps
running up to 10 minutes after the last one closed. All of them keep the `.exe` open, so a build into the same folder
fails with *"file is being used by another process"*. Close the AI clients, or stop the processes:

```powershell
Get-Process Extedo.AutoTest.Ai.Mcp.DesktopInteraction -ErrorAction SilentlyContinue | Stop-Process
```

The AI clients start their server again on the next tool call or restart (Claude Code: `/mcp` → reconnect;
LM Studio: toggle the server off and on). To only check that the code compiles without stopping anything, build into
another folder: `dotnet build -c Release -o <some other folder>`.

### 3.4 Connect your AI clients

Every client starts its own copy of the server (one per client window or session). They coordinate automatically
(section 10). Use the built `.exe` as the command. Never use `dotnet run` as the MCP command: build messages on
standard output would corrupt the protocol.

**Claude Code** (one command, for all your projects):

```powershell
claude mcp add --scope user extedo-desktop-interaction -- "C:\_\Testing\Research\DesktopInteraction\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe"
```

With options, put them after the `.exe`:
`claude mcp add --scope user extedo-desktop-interaction -- "...\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe" --frame captured`.

**LM Studio** (*Program → Install → Edit mcp.json*) and **Claude Desktop** (*Settings → Developer → Edit Config*):

```json
{
  "mcpServers": {
    "extedo-desktop-interaction": {
      "command": "C:\\_\\Testing\\Research\\DesktopInteraction\\bin\\Release\\net10.0-windows\\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe",
      "args": []
    }
  }
}
```

**GitHub Copilot in VS Code**: `.vscode/mcp.json` (workspace) or the user `mcp.json`:

```json
{
  "servers": {
    "extedo-desktop-interaction": {
      "type": "stdio",
      "command": "C:\\_\\Testing\\Research\\DesktopInteraction\\bin\\Release\\net10.0-windows\\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe",
      "args": []
    }
  }
}
```

Other clients: the same command. Options (section 8) go into `args`, one array element per word:

```json
"args": ["--frame", "captured", "--user-idle-ms", "3000"]
```

A wrong option makes the server exit immediately with exit code 2 and a message on standard error (for example
`Unknown option '--frame-off'. Run with --help for the list of options.`); the AI client then shows the server as
failed. Check its log, or run the same command line yourself in a console.

**Choosing tools.** Every tool is a separate MCP tool, so clients with a checkbox per tool (LM Studio, VS Code) let
you allow only what you want - for example untick all `_injected` tools to force device input, or all input tools
for a "look only" assistant. Tools carry MCP annotations (`readOnlyHint`, `destructiveHint`, `idempotentHint`) that
clients use for their approval prompts.

### 3.5 First check

Ask the AI to call `desktop_status`, or run it yourself:

```powershell
.\Scripts\Invoke-DesktopTool.ps1 -Tool desktop_status
```

Look for:

- `inputs.device.available: true` and `inputs.device.keyboard: true`,
- `typing: "desktop_type_text uses the device keyboard ..."`,
- `recommendedMouseTools: "desktop_mouse_* (device input)"`,
- `control.hotkeyReady: true` (the emergency stop hotkey is registered).

The first device action after a fresh start can take up to 20 s while Windows sets up the virtual device (you may
hear the USB connect sound once). In Device Manager it appears as *Extedo Virtual Mouse and Keyboard (USB/IP)*, with
two *HID-compliant mouse* entries and one *HID Keyboard Device*. It disappears when the device host ends.

## 4. How it behaves on your desktop

### 4.1 You always have priority

- **Before every input** (move, click, scroll, type, press keys, focus a window) the server waits until **you have
  not used your mouse or keyboard for 7 seconds** (`--user-idle-ms`). While you work, the AI's request waits; after
  **30 s** (`--user-wait-ms`) of waiting it gives up without sending anything and tells the AI:
  *"The user is using the mouse or keyboard (last input ... ms ago); waited 30 s ... Try again later or ask the user."*
  Nothing is clicked or typed while you are active.
- **During an action**, the moment you move the mouse or press a key, the AI's input **stops** before its next step
  and the AI is told *"The user moved the mouse or used the keyboard: input stopped to let the user work."* Held
  buttons are released. The next request waits for 7 s of quiet again.
- Your input is recognised through Windows **Raw Input**, also while other windows have the focus. The virtual
  device (recognised by its hardware IDs `VID_1209&PID_0001` or `ExtedoVirtualMouse`) and the servers' own
  `SendInput` are not mistaken for you. Limitation: injected input of *other* software (an auto-clicker, a mouse
  jiggler, remote-control tools) counts as you.
- `--user-idle-ms 0` disables both the wait and the stop - for unattended test machines only.

### 4.2 You always see when an AI is working

- **Blue frame on every monitor**: a blue rim with a soft inner glow that pulses every 2 s and fades in and out in
  0.3 s. It appears with the first input of an AI and stays until **6 s after its last input**, so it does not
  flicker between the steps of a task.
- **Banner** at the top centre of every monitor: **`claude-code is using your computer`** -
  *Move the mouse or press a key to take over · Ctrl+Alt+F12 stops all*. The name is the working AI client, taken
  from what the client reports about itself (Claude Code, Copilot, LM Studio, ...).
- **Cyan pointer marker** around the pointer while the AI moves it, with a small label naming the AI client about
  112 px below and right of the pointer (it flips to the other side near screen edges), so it never covers what is
  being clicked. It disappears 1.5 s after the last input.
- **Tray icon** *"Extedo Desktop Interaction - Ctrl+Alt+F12 stops"*, one per running server. Its menu:
  *Show/hide cursor marker* (this server only) and *Stop all Desktop Interaction instances and exit* (latches the
  emergency stop for all servers, like Ctrl+Alt+F12, and closes this one).
- Frame, banner and marker are **not in screenshots**: they are excluded from screen capture
  (`WDA_EXCLUDEFROMCAPTURE`), so neither this server, nor other AI tools, nor your own screenshots and screen
  sharing contain them (`--frame captured` keeps them for demo videos, section 6.9). The screenshots of this server
  draw the cyan marker in at the pointer position instead, so the AI sees where the pointer is. All overlays are
  click-through and never take the focus.
- An AI client that only has the server loaded but does nothing shows nothing except the tray icon.

### 4.3 Stopping

| What you do | Effect |
| --- | --- |
| Move the mouse or press any key | The running action stops at its next step; held buttons are released; the AI waits for 7 s of quiet before trying again. |
| Hold **Escape** | Cancels the running input operation (mouse moves, clicks, typing) of every server at its next step. |
| **Ctrl+Alt+F12** | **Emergency stop for all AI clients**: held buttons are released and all further input is refused by every server ("Emergency stop is latched"). It stays latched until **every** server process has been closed - restart the AI clients. Taking control (`desktop_take_control`) never clears it. |
| Tray icon → *Stop all Desktop Interaction instances and exit* | Same latch as Ctrl+Alt+F12, and this server exits. |
| Close the AI client | Its server ends; buttons it held are released. |

Read-only tools (screenshot, status, window list) keep working after an emergency stop, so the AI can still look
and report.

## 5. Device input and injected input

Every input tool exists twice. The default tools use the virtual device; the `_injected` tools use `SendInput`.

| | Device input (default) | Injected input |
| --- | --- | --- |
| Tools | `desktop_mouse_*`, `desktop_type_text`, `desktop_press_keys` | `desktop_mouse_*_injected`, `desktop_type_text_injected`, `desktop_press_keys_injected` |
| How | virtual USB mouse + keyboard (usbip-win2) | Windows `SendInput` |
| Windows sees | a real hardware device | simulated input, flagged as injected |
| Administrator windows (admin PowerShell, regedit, installers, Task Manager) | **work** | silently blocked by Windows (UIPI) |
| UAC prompt on the normal desktop (section 6.3) | **works** | blocked |
| UAC prompt on the secure desktop (default Windows setting) | refused; opt-in blind click with `--secure-desktop-input device` (6.4) | never |
| VM windows, games, Raw Input apps | **work** | often ignored |
| Inside a Remote Desktop session | not possible (would reach the PC's physical console) | **works** |
| Text | characters of the target window's keyboard layout, one key press each | any Unicode character |
| Needs | usbip-win2 (or the Extedo driver, mouse only) | nothing |

**Automatic choice for text and keys.** `desktop_type_text` and `desktop_press_keys` use the device keyboard when it
is available and the session is not a Remote Desktop session, otherwise `SendInput`; their result says which
(`"input": "device"` or `"injected"`). On the first use after a start they wait up to 20 s for the device to
attach; if it does not, they type with `SendInput` and do not wait again for 5 minutes. The `_injected` variants
always use `SendInput`.

**How device typing works.** For every character the server asks Windows which key (plus Shift / AltGr) produces it
in the **keyboard layout of the foreground window** (for example Czech, German, US), takes the current Caps Lock state
into account, and presses exactly that key on the virtual keyboard with human-like timing - like a person typing.
Characters that need a dead key (for example `^` or `ü` on the Czech layout) or are not on the layout at all (emoji,
other scripts) are sent with `SendInput` instead; the result then lists them in `injectedCharacters`. In a normal
window that makes no difference; in an administrator window those characters do not arrive.

**Text and keys are separate tools.** `desktop_type_text` accepts printable text only (no Enter, Tab or other control
characters), so typed text can never submit a form or run a command by accident. Enter, Escape, Tab, arrows,
F-keys and shortcuts are pressed deliberately with `desktop_press_keys` (section 7.3), for example `{ENTER}` after
typing a command.

## 6. Scenarios

### 6.1 Normal applications

Everything works with the default tools. A typical loop: `desktop_capture` to look, `desktop_mouse_move` to the target,
`desktop_mouse_click`, `desktop_type_text`, `desktop_press_keys {ENTER}`. Every input tool returns a picture of what
changed (section 7.6), so the AI usually does not need a new full screenshot after each step.

### 6.2 Elevated windows (for example PowerShell "Run as administrator")

Windows protects windows that run with administrator rights from simulated input of normal programs (User Interface
Privilege Isolation, UIPI). The server runs without administrator rights - on purpose, it never elevates itself.

- **Device mouse and device keyboard work** in elevated windows, because Windows treats them as real devices.
  Typing a command into an administrator PowerShell and pressing `{ENTER}` works.
- `_injected` tools do not work there: Windows silently drops the click or the text. The tool cannot detect that.
- Screenshots of elevated windows work.

Typical flow "open PowerShell as administrator":

1. `desktop_press_keys` `#r` opens the Run dialog, `desktop_type_text` `powershell`, then `desktop_press_keys`
   `^+{ENTER}` (Ctrl+Shift+Enter = run as administrator). Alternatively the AI right-clicks the PowerShell entry and
   clicks *Run as administrator* (device mouse).
2. Windows shows the UAC prompt - see 6.3 and 6.4 for who answers it.
3. In the window *Administrator: Windows PowerShell* the AI types the command with `desktop_type_text` and runs it
   with `desktop_press_keys` `{ENTER}`.

### 6.3 UAC prompts - default: you answer them

**With the default Windows setting the UAC prompt ("Do you want to allow this app to make changes to your device?")
appears on the *secure desktop*** (the screen dims and everything else is frozen). The secure desktop is a separate,
protected desktop: no normal program - including this server - can see it or take screenshots of it.

By default the server therefore **refuses all input while the secure desktop is shown** and tells the AI
*"The secure desktop is active (UAC prompt, lock screen or Ctrl+Alt+Del screen) ... Ask the user to answer it."*
`desktop_status` → `inputDesktop` shows `secure (input refused)`. **You answer the UAC prompt yourself** (one
click); then the AI continues.

**Option for test machines: show UAC on the normal desktop.** If the AI should answer UAC prompts itself *and see
them*, you can let Windows show the prompt on the normal desktop. This is a Windows security setting; it is your
decision and the server never changes it:

- *Local Security Policy* (`secpol.msc`) → *Local Policies* → *Security Options* →
  **User Account Control: Switch to the secure desktop when prompting for elevation** → *Disabled*,
  or the registry value `HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\PromptOnSecureDesktop` = `0`.
- Trade-off: the prompt is then on the normal desktop, where other software running as you could imitate it or
  watch it. Use this only on test machines and VMs, not on your daily work PC. Revert with *Enabled* / `1`.

With that setting the UAC prompt is an ordinary (protected) window: the AI sees it in screenshots and clicks **Yes**
with the **device mouse**. Injected clicks are blocked there (the prompt runs with system rights).

**Credential prompts** ("enter an administrator user name and password", shown to standard users): the AI must not
type passwords. You enter credentials yourself.

### 6.4 UAC prompts on the secure desktop - opt-in blind click (`--secure-desktop-input device`)

Only a real hardware device can operate the secure desktop, and the virtual device is one. With the server option
**`--secure-desktop-input device`** (default `off`) device input is allowed while the secure desktop is shown:

- The AI **cannot see** the prompt (screenshots of the secure desktop are impossible), so it clicks **blind** at a
  position measured beforehand. Windows centres the UAC dialog at the same screen position each time, so the
  position of *Yes* can be measured once on the normal desktop (with the secure desktop briefly switched off, 6.3)
  and reused.
- During such a move the server does not read back and correct the pointer position (it cannot, from the normal
  desktop); the device's coordinate mapping must already be calibrated by an earlier move on the normal desktop.
- Injected input stays refused there; the error message says to use the device tools.
- `desktop_status` → `secureDesktopDeviceInput: true`, and while the prompt is shown
  `inputDesktop: "secure (device input allowed: blind click at a known position, no capture)"`.
- The lock screen and the Ctrl+Alt+Del screen are secure desktops too: with this option the device could also type
  there. The AI must never type passwords. **Use this option only on supervised test machines and VMs.**

`Scripts\Test-UacElevation.ps1` is the guided QA scenario for it:

```powershell
.\Scripts\Test-UacElevation.ps1 -Mode probe       # secure-desktop state, monitors, server's inputDesktop field
.\Scripts\Test-UacElevation.ps1 -Mode calibrate   # secure desktop OFF: measure the "Yes" button -> uac-calibration.json
.\Scripts\Test-UacElevation.ps1 -Mode run         # secure desktop ON: elevated PowerShell, blind device click on "Yes"
```

Parameters: `-YesX`/`-YesY` (override the measured position), `-CalibrationFile`, `-Exe`, `-UserIdleMs`
(default 1500), `-SecureWaitMs` (default 10000). During `-Mode run` do not touch mouse or keyboard: if the elevated
process starts without your click, the device clicked it. The script prints the elevated commands for switching the
secure desktop off and on; you run them yourself.

### 6.5 Lock screen, Ctrl+Alt+Del screen, sign-in

These are secure desktops too: input is refused (unless 6.4) and screenshots are not possible (black or failing).
When the PC locks during a task, the AI's tools report it; unlock the PC yourself. Keep the PC unlocked and the
screen on for unattended runs. The server never sends Win+L or Ctrl+Alt+Del.

### 6.6 Virtual machines in a window (Hyper-V VMConnect, VMware, VirtualBox)

Use the **default device tools**. VM windows read the real mouse and keyboard (Raw Input, keyboard hooks, mouse
capture) and often ignore simulated input; the virtual USB device behaves like your own mouse and keyboard.

- **Mouse**: works best when the guest has integration services / guest additions (absolute pointer, no mouse
  capture). Without them the VM may "capture" the mouse on a click; release it with the VM's key combination
  (Hyper-V: Ctrl+Alt+Left Arrow) - prefer guests with integration tools.
- **Keyboard**: the device keyboard sends key positions, chosen with the keyboard layout of the **VM window on your
  PC**. The guest translates them with **its own** layout. Use the **same keyboard layout in the guest as on the
  host**; otherwise characters come out wrong (for example `z`/`y` swapped between German and US). Characters sent
  with `SendInput` (dead keys, emoji, section 5) may not reach the guest at all.
- **Screenshots**: the VM window is captured like any window. The visual feedback after an action is limited to a
  100x100 px box around the pointer inside VM viewer windows (vmconnect, vmware, vmplayer, VirtualBoxVM), because the
  server cannot see the windows inside the guest; the AI takes a `desktop_capture` to see more.
- **Hyper-V Enhanced Session** is a Remote Desktop connection: see 6.7 b.
- UAC prompts **inside the guest** are on the guest's secure desktop but are drawn into the VM window like anything
  else, so the AI can see and click them there (unlike UAC on your own PC).
- For full automation inside a VM, install the server inside the VM itself (usbip-win2 in the guest, or the Extedo
  driver, [DRIVER.md](DRIVER.md)).

### 6.7 Remote Desktop

There are two different situations.

**a) The AI client and this server run inside a Remote Desktop session** (you are connected to the PC with RDP and the
AI works in that session):

- Device input is **not possible**: a USB device always belongs to the PC's physical console session, not to the RDP
  session. The server detects the RDP session: `desktop_status` → `remoteDesktopSession: true`,
  `recommendedMouseTools: "desktop_mouse_*_injected (...)"`; the device mouse tools refuse with a clear message, and
  `desktop_type_text` / `desktop_press_keys` automatically use `SendInput`.
- Use the `_injected` mouse tools. Administrator windows inside the session cannot be driven (UIPI), and UAC prompts in
  the session appear on its secure desktop - answer them yourself.
- **Do not minimise the Remote Desktop window** on your side and do not disconnect while the AI works: Windows stops
  drawing a minimised or disconnected session, so screenshots are black or fail and input goes nowhere.
- The 7 s user priority refers to input arriving in the session (your RDP client). Because RDP input has no device
  handle, it is recognised as yours only while no server is injecting at that moment.

**b) The AI works on your local PC and drives a Remote Desktop window** (`mstsc`, Windows App / `msrdc`) that shows
another PC:

- Use the **default device tools**: the RDP client forwards your local mouse and keyboard to the remote PC, and the
  virtual device is local input like yours. This also works for administrator windows and UAC prompts on the remote PC
  (in a remote session its UAC prompt is drawn into the RDP window).
- Keyboard layout: as with VMs (6.6), keep the same layout on both sides.
- Feedback inside the RDP window is limited to the 100x100 px box around the pointer; the AI uses `desktop_capture`.
- Keep the RDP window in the foreground and not in full screen on a different monitor than the AI expects.

### 6.8 Several AI clients at the same time

You can have Claude Code, Copilot, LM Studio and others configured at the same time, each with its own server copy.
Loading a server takes nothing over; whichever AI sends input takes the pointer ("baton") and the interrupted one is
told so. Details in section 10.

### 6.9 Demo videos and recordings

Frame, banner and marker are hidden from screen capture. To have them in a recording, start the server with
`--frame captured`. `--frame off` disables frame and banner completely (the cyan marker stays).

To preview the overlays without an AI, run the program with `--demo` (also with `--frame captured`); it shows the
marker, frame and banner permanently and serves no MCP. End it with Ctrl+C in its console.

### 6.10 Unattended test machines

For a dedicated test VM where nobody uses mouse and keyboard:

```json
"args": ["--user-idle-ms", "0", "--frame", "captured"]
```

- `--user-idle-ms 0`: input starts at once and is not stopped by "user" input. Without it, any other automation on
  the machine that injects input counts as a user and makes the AI wait.
- Keep the session unlocked and the display on (power settings), and do not use Remote Desktop to watch a console
  session you then disconnect from.
- Optional, only if UAC must be answered automatically: section 6.3 (UAC on the normal desktop) or 6.4
  (`--secure-desktop-input device`).

## 7. Tool reference

The server offers **25 tools**. All coordinates are physical pixels of the whole virtual desktop (section 7.5).
Read-only tools never take control and never wait for the user. Input tools wait for the user to be idle, take the
baton, act, and return visual feedback.

### 7.1 Overview

| Tool | Kind | What it does |
| --- | --- | --- |
| `desktop_status` | read-only | Input methods, monitor layout, pointer, user activity, control and emergency-stop state (section 9). |
| `desktop_capture` | read-only | Screenshot of the primary monitor, one monitor or the whole desktop. |
| `desktop_list_windows` | read-only | Visible top-level windows with handle and title. |
| `desktop_mouse_position` | read-only | Current pointer position. |
| `desktop_take_control` | control | Takes the baton explicitly; returns `desktop_status`. |
| `desktop_focus_window` | input + feedback | Restores and brings to the foreground a window by part of its title. |
| `desktop_type_text` | input + feedback | Types printable text; device keyboard when available, else SendInput. |
| `desktop_type_text_injected` | input + feedback | Types printable text with SendInput (any Unicode character). |
| `desktop_press_keys` | input + feedback | Presses keys / shortcuts in SendKeys syntax; device keyboard when available. |
| `desktop_press_keys_injected` | input + feedback | The same with SendInput. |
| `desktop_mouse_move` / `_injected` | input + feedback | Moves the pointer (human-like path, routed across monitors). |
| `desktop_mouse_click` / `_injected` | input + feedback | Single or double click; waits up to 0.5 s for a reaction. |
| `desktop_mouse_click_quick` / `_injected` | input, no feedback | Click and return at once (about 0.15 s), no screen capture. |
| `desktop_mouse_click_lazy` / `_injected` | input + feedback | Click and wait up to `waitMs` for a slow reaction, then until quiet. |
| `desktop_mouse_button` / `_injected` | input + feedback | Press or release one button (custom drags). |
| `desktop_mouse_drag` / `_injected` | input + feedback | Drag from one point to another. |
| `desktop_mouse_scroll` / `_injected` | input + feedback | Vertical or horizontal wheel. |
| `desktop_release_buttons` | input + feedback | Releases all buttons held by this server (both input paths). |

### 7.2 Tool details

**`desktop_status`** - no parameters. Returns the JSON described in section 9. Call it first in a session and after
errors that mention the device, the secure desktop or control.

**`desktop_capture`**

| Parameter | Type | Default | Values |
| --- | --- | --- | --- |
| `scope` | string | `primary` | `primary` (primary monitor), `monitor` (one monitor), `desktop` (all monitors) |
| `monitorIndex` | integer | `0` | monitor index from `desktop_status` → `layout.monitors[].index`, when `scope` is `monitor` |

Returns a JSON block `{"bounds":{x,y,width,height},"cursor":{x,y},"cursorComposited":true}` and a PNG. Image pixel
`(u,v)` is desktop pixel `(bounds.x+u, bounds.y+v)`. The cyan pointer marker is drawn into the image at the pointer.
Captures larger than 40 million pixels are refused. Errors: `Invalid monitorIndex.`,
`scope must be primary, monitor or desktop.`

**`desktop_list_windows`** - no parameters. Returns `[{"handle":"0x1A2B","title":"..."}]` for every visible top-level
window with a non-empty title, in Z-order (topmost first). Positions are not included; use `desktop_capture`.

**`desktop_mouse_position`** - no parameters. Returns `{"x":..,"y":..}`.

**`desktop_take_control`** - no parameters. Takes the baton from another server (that server's running input stops
and its held buttons are released) and returns `desktop_status`. Input tools do this automatically; use it to claim
the pointer before a sequence of read-only steps. It does not clear an emergency stop.

**`desktop_focus_window`**

| Parameter | Type | Description |
| --- | --- | --- |
| `titlePart` | string, required | Case-insensitive part of the window title. The first visible match in Z-order is used. |

Restores the window (if minimised) and calls `SetForegroundWindow`. Result: `{"handle","title","focused"}`;
`focused: false` means Windows refused to switch the foreground (focus-stealing rules) - click into the window
instead. Error: `No visible window with title containing '...'.`

**`desktop_type_text`** / **`desktop_type_text_injected`**

| Parameter | Type | Description |
| --- | --- | --- |
| `text` | string, required | 1-1000 printable characters. No control characters (no Enter, Tab, newline). |

Types into the focused control of the foreground window. The foreground window is checked before every character;
if it changes, typing stops (`Foreground window changed while typing.`), so text never lands in a window that popped
up. Results:

- `{"typedCharacters":12,"input":"device"}` - all characters typed with the device keyboard,
- `{"typedCharacters":12,"input":"injected"}` - typed with SendInput (no device keyboard, Remote Desktop, or the
  `_injected` tool),
- `{"typedCharacters":12,"input":"device","viaDevice":10,"viaInjected":2,"injectedCharacters":"€ü","note":"..."}` -
  some characters were not on the layout (or need a dead key) and were sent with SendInput.

**`desktop_press_keys`** / **`desktop_press_keys_injected`**

| Parameter | Type | Description |
| --- | --- | --- |
| `keys` | string, required | Key sequence in SendKeys syntax (7.3), e.g. `{ENTER}`, `^a{DEL}`, `%{F4}`, `#r`, `{TAB 3}`. |

The whole sequence is parsed and checked before the first key is pressed; with the device keyboard every character
must be on the foreground window's layout (otherwise nothing is pressed and the error says so). Unlike text entry the
foreground window may change between keys - that is what Alt+Tab, Win+R or Enter do; later characters use the new
window's layout. Result: `{"pressed":3,"keys":["Ctrl+A","Delete"],"input":"device"}`; keys without a PC scan code
(`{HELP}`) are listed in `injectedKeys`. `desktop_press_keys_injected` sends characters that are not on the layout as
Unicode, but cannot combine them with modifiers.

**`desktop_mouse_move`** / **`desktop_mouse_move_injected`**

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `x`, `y` | integer, required | | Target in physical desktop pixels; must be on a monitor (not in a gap between monitors). |
| `durationMs` | integer | `-1` | 0-10000 ms; `-1` = human-like duration from the distance (250 ms with `--motion linear`). |

The path is human-like (curved, variable speed, small overshoot on long moves kept on the target monitor) or linear
(`--motion linear`). Moves between monitors follow a planned route across the edges the monitors share (7.5). With the
device the final pixel is read back and corrected (the device's coordinate mapping is learned); if it cannot be
reached the error suggests `desktop_mouse_move_injected`. Result: `{"input":"device","cursor":{x,y}}`.

**`desktop_mouse_click`** / **`_injected`**, **`desktop_mouse_click_quick`** / **`_injected`**

| Parameter | Type | Default | Values |
| --- | --- | --- | --- |
| `button` | string | `left` | `left`, `right`, `middle`, `x1`, `x2` |
| `count` | integer | `1` | `1` single click, `2` double click (spacing adapted to the Windows double-click time) |

Clicks at the **current** pointer position - move first. The normal click waits up to 0.5 s for a visible reaction
and returns it; the quick click returns immediately, takes no screenshot at all and returns
`{"result":{...},"feedback":"skipped (quick action)"}` (it also drops the late-change tracking, 7.7).

**`desktop_mouse_click_lazy`** / **`_injected`** - like the click, plus:

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `waitMs` | integer | `9000` | 500-60000 ms (clamped): how long to wait for the first visible reaction. |

After the first change it waits until the area has been quiet for 1 s (at most 9 s after the first change) and
returns that final state. Use it for lazy-loading pages, progress bars and slow dialogs.

**`desktop_mouse_button`** / **`_injected`**

| Parameter | Type | Default | Values |
| --- | --- | --- | --- |
| `action` | string, required | | `down` or `up` |
| `button` | string | `left` | `left`, `right`, `middle`, `x1`, `x2` |

For custom drags (down, several moves, up). Always release after `down`. A release goes to the input path that pressed
the button and does not wait for user idle.

**`desktop_mouse_drag`** / **`_injected`**

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `fromX`, `fromY` | integer, required | | Start point. |
| `toX`, `toY` | integer, required | | Destination point. |
| `durationMs` | integer | `-1` | 0-10000 ms for the drag movement; `-1` = human-like (600 ms with `--motion linear`). |
| `button` | string | `left` | `left`, `right`, `middle`, `x1`, `x2` |

Moves to the start, presses, pauses briefly (drag threshold), moves, pauses (drop highlight), releases. The button is
released also when the drag is cancelled. Both points are validated before anything is pressed. A drop completes only
if the target application accepts it.

**`desktop_mouse_scroll`** / **`_injected`**

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `delta` | integer, required | | -12000..12000. 120 = one wheel notch. Positive vertical = up, positive horizontal = right. Device: a multiple of 120. |
| `axis` | string | `vertical` | `vertical` or `horizontal` |

Scrolls at the current pointer position (move the pointer over the scrollable area first).

**`desktop_release_buttons`** - no parameters. Releases every button this server holds on both input paths. Does not
wait for user idle and does not take control.

### 7.3 Key syntax (`desktop_press_keys`)

The syntax of Windows Forms
[`SendKeys`](https://learn.microsoft.com/dotnet/api/system.windows.forms.sendkeys), plus the Windows key:

| Write | Presses |
| --- | --- |
| `a`, `Z`, `5`, `.`, `é` | that character's key, with Shift / AltGr as the keyboard layout needs |
| `+` / `^` / `%` / `#` before a key | Shift / Ctrl / Alt / **Win** held for the next key: `^c` Ctrl+C, `%{F4}` Alt+F4, `#r` Win+R, `^+{ESC}` Ctrl+Shift+Esc |
| `+(abc)` | modifiers held for a whole group: Shift+A, Shift+B, Shift+C |
| `~` or `{ENTER}` | Enter |
| `{ESC}` (`{ESCAPE}`) `{TAB}` `{BS}` (`{BKSP}`, `{BACKSPACE}`) `{DEL}` (`{DELETE}`) `{INS}` (`{INSERT}`) `{HOME}` `{END}` `{PGUP}` `{PGDN}` | the named key |
| `{UP}` `{DOWN}` `{LEFT}` `{RIGHT}` | arrow keys |
| `{F1}` ... `{F24}` | function keys |
| `{CAPSLOCK}` `{NUMLOCK}` `{SCROLLLOCK}` `{PRTSC}` `{BREAK}` `{HELP}` | the named key (`{BREAK}` = Ctrl+Pause; `{HELP}` has no PC key and is always sent with SendInput) |
| `{ADD}` `{SUBTRACT}` `{MULTIPLY}` `{DIVIDE}` | numeric keypad + - * / |
| `{SPACE}` `{APPS}` `{WIN}` (`{LWIN}`) `{RWIN}` | Space, context-menu key, Windows key (extensions) |
| `{LEFT 5}`, `{TAB 3}`, `{x 10}` | repeat 1-100 times |
| `{+}` `{^}` `{%}` `{#}` `{~}` `{(}` `{)}` `{{}` `{}}` | the literal character |

Key names are case-insensitive (`{enter}` = `{ENTER}`). Each key press is: modifiers down, key down, key up, modifiers
up, with short human-like pauses.

Examples:

| Goal | `keys` |
| --- | --- |
| Confirm / run a typed command | `{ENTER}` |
| Select all and delete | `^a{DEL}` |
| Copy, paste | `^c`, `^v` |
| Close window | `%{F4}` |
| Run dialog | `#r` |
| Run as administrator from Start / Run | `^+{ENTER}` |
| Task Manager | `^+{ESC}` |
| Switch window | `%{TAB}` |
| Move 5 characters left with selection | `+{LEFT 5}` |
| Rename in Explorer | `{F2}` |

**Limits and guards**: at most 500 key presses per call. **Refused**: Ctrl+Alt+Del (opens the secure desktop),
Win+L (locks the PC, only you can unlock it), Ctrl+Alt+F12 (your emergency stop). Syntax errors are reported with the
position, e.g. `Unclosed '{' at position 3.` or `Unknown key {ENTRE}. Known: ...`.

### 7.4 Errors

Errors come back as tool results with `isError: true` and a JSON `error` text that explains what to do. Errors
before any input was sent (user busy, secure desktop, emergency stop) say `"feedback":"skipped (no input sent)"`.
Errors during an action still carry the visual feedback, so the AI sees the screen state. The most important
messages and their meaning are listed in section 11.

### 7.5 Coordinates and several monitors

- Coordinates are **physical pixels of the whole virtual desktop**. The server is per-monitor DPI aware, so a 4K
  monitor at 150 % scaling is still 3840 px wide. Monitors left of or above the primary monitor have **negative**
  coordinates.
- `desktop_status` → `layout` lists every monitor (index, name, position, size, last pixel `right`/`bottom`,
  portrait/landscape) and every **shared edge**: where two monitors touch and over which range, for example
  `DISPLAY3 right | DISPLAY4 left at x=-4321|-4320, y -1060..1099`. The pointer can pass between monitors only there.
- Moves and drags between monitors follow a planned route across shared edges, away from the corners, so they never
  enter gaps between monitors or Windows' sticky corners. Targets in a gap are rejected
  (`Point (x,y) lies in a gap between monitors`); targets outside the desktop too.
- After changing the monitor arrangement, resolution or scaling, capture again: old coordinates may point elsewhere.

### 7.6 Visual feedback

Every input tool (except the quick clicks) returns its JSON result followed by a PNG of **what changed**, also when
the action failed:

- **Anchor**: mouse tools use the pointer; `desktop_type_text`, `desktop_press_keys` and `desktop_focus_window` use the
  text caret (the pointer when the application has no Win32 caret, as in many browsers and WPF apps).
- **Limit**: the top-level window under the anchor (the foreground window for keyboard tools). Outside a known window
  - the desktop, or a VM / Remote Desktop viewer whose content has no window information - the limit is the 100x100 px
  box around the anchor.
- **Timing**: no fixed delay. The window is captured every 80 ms until it has changed and two captures in a row are
  equal; with no change it gives up after 0.5 s; while it keeps changing (video, loading) it stops after 9 s.
- **Crop**: the changed area joined with the 100x100 px box around the anchor. If a different window appeared at the
  anchor (menu, dialog), the whole new window is returned. The blinking caret is ignored. Crops larger than 1280 px on
  the longest side are scaled down.

The JSON `feedback` object: `region` (desktop rectangle shown), `scale` and `mapping`
(`desktop = (region.x + u / scale, region.y + v / scale)`), `changed`, `basis`, `settledMs`, `timing`
(`normal`/`lazy`), `source`, `window` (title), `process`, `anchor` (`x`,`y`,`kind`).

### 7.7 Late changes

Content that appears **after** a tool returned (lazy loading, a dialog that comes later) is reported on the **next**
tool call - also read-only ones such as `desktop_status` - in a `lateChange` section with a crop of the changed area:

```json
{"lateChange":{"since":"desktop_mouse_click","secondsAgo":2.6,"changed":true,"settled":true,"region":{...},"scale":1,"window":"..."}}
```

Without a change it is one line, `{"lateChange":{"since":"desktop_mouse_click","secondsAgo":4.1,"changed":false}}`.
`settled:false` means the area was still changing; call `desktop_status` again to see the final state. Each change is
reported once; nothing runs in the background between calls.

## 8. Command-line reference

`Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --help` (or `-help`, `-h`, `-?`, `/?`, `/h`) prints this list. Without a mode, the program is the MCP server
on standard input/output (that is how AI clients start it). Option names are case-sensitive; values are not.
Unknown options, stray arguments, options without their value and out-of-range values are rejected with exit code 2.

### 8.1 Server options

Put them into `args` of the MCP configuration (section 3.4).

| Option | Default | Meaning |
| --- | --- | --- |
| `--device usbip\|driver\|none` | `usbip` | What backs the device tools. `usbip`: virtual USB mouse **and keyboard** via usbip-win2 ([USBIP.md](USBIP.md)). `driver`: Extedo test-signed mouse driver - mouse only, typing then uses SendInput, test VMs ([DRIVER.md](DRIVER.md)). `none`: no device; device mouse tools fail with a hint to the `_injected` tools, typing uses SendInput. The `_injected` tools are always available. |
| `--usbip-attach auto\|manual` | `auto` | `auto`: the device host runs `usbip attach -r 127.0.0.1 -b 1-1` itself. `manual`: you run that command (for diagnosing usbip-win2). |
| `--usbip-exe <path>` | search | Path to `usbip.exe`. Default: the first `usbip.exe` on `PATH`, else `%ProgramFiles%\USBip\usbip.exe`. |
| `--device-sharing on\|off` | `on` | `on`: one shared device host serves all servers (section 10). `off`: each server owns its own device; only the first one gets port 3240, the others report it busy. |
| `--device-host-idle-s <0-86400>` | `600` | Seconds the shared device host keeps running after the last server disconnected (so restarting an AI client does not unplug the device). Only used when a server starts the host. |
| `--user-idle-ms <0-60000>` | `7000` | How long you must be idle before the AI's input starts. `0` = no waiting and no stop on your input (unattended test machines only). |
| `--user-wait-ms <0-600000>` | `30000` | How long a request waits for you to become idle before it returns an error without sending input. |
| `--motion human\|linear` | `human` | `human`: curved, variably paced paths (~125 Hz), overshoot on long moves, natural click/drag/typing pauses, distance-based durations. `linear`: straight constant-speed moves (default move 250 ms, drag 600 ms) and minimal pauses - faster and deterministic. |
| `--frame on\|off\|captured` | `on` | Blue frame + banner while an AI works. `on`: hidden from screen capture. `captured`: also in screenshots and recordings. `off`: no frame, no banner. |
| `--secure-desktop-input off\|device` | `off` | `off`: all input refused while the secure desktop (UAC, lock screen) is shown. `device`: device input may operate it blind at a pre-measured position; test machines only (section 6.4). |

Example configurations:

| Purpose | `args` |
| --- | --- |
| Default (recommended) | `[]` |
| No usbip-win2 installed, injected input only | `["--device", "none"]` |
| Demo recording | `["--frame", "captured"]` |
| Faster, deterministic motion | `["--motion", "linear"]` |
| Shorter user idle time | `["--user-idle-ms", "3000"]` |
| Unattended test VM | `["--user-idle-ms", "0", "--frame", "captured"]` |
| Test VM, AI answers UAC blind | `["--secure-desktop-input", "device"]` |
| usbip.exe in a custom folder | `["--usbip-exe", "D:\\Tools\\USBip\\usbip.exe"]` |

### 8.2 Modes

A mode replaces the MCP server; the program runs it in the console and exits.

| Mode | What it does |
| --- | --- |
| `--help`, `-help`, `-h`, `-?`, `/?`, `/h` | Prints the option list (server options, modes, exit codes, keys) and exits (0). Any of these anywhere on the command line wins over all other arguments. |
| `--version` | Prints `extedo-desktop-interaction 0.7.0`. |
| `--demo` | Shows cursor marker, frame and banner permanently without serving MCP; accepts the server options (`--frame captured`). Ctrl+C ends it. |
| `--device-host` | Runs the shared device host. Started automatically (detached) by the servers; accepts `--device`, `--usbip-exe`, `--usbip-attach`, `--device-host-idle-s`. Only one host runs per Windows session; a second one exits at once. |
| `--self-test [--input device\|injected]` | **Moves the real pointer** on its own test window: move, single and double click, drag and wheel, verified by the window. Default `--input device` (needs `--device usbip` or `driver`). Hands off mouse and keyboard. |
| `--feedback-live-test [--input device\|injected] [--save-feedback <folder>]` | **Moves the real pointer**: checks that visual feedback catches typing, scrolling, selection, a 350 ms reaction, a 2 s lazy load (reported on the next call) and no change for plain moves. `--save-feedback` writes the feedback PNGs into an existing folder. |
| `--motion-self-test` | Motion paths, HID report encoding, calibration, SendKeys parsing and refused shortcuts. No input. |
| `--layout-self-test` | Monitor routing on the real and on synthetic monitor layouts. No input. |
| `--feedback-self-test` | Change detection, anchor box and a real capture at the pointer. No input. |
| `--coordination-self-test` | Baton, pause and emergency stop between processes (starts worker processes with the internal `--coordination-worker <name>`). No input. |
| `--device-host-self-test` | Shared device host protocol with a fake device. No input. |
| `--usbip-self-test` | USB/IP protocol and USB HID emulation over loopback. No input. |
| `--usbip-install <USBip-x.y.z-x64.exe> [--usbip-sha256 <hash>]` | Silently installs usbip-win2. Elevated prompt required; only pinned installers, or the one matching `--usbip-sha256`. Reboot afterwards. |
| `--usbip-uninstall` | Silently uninstalls usbip-win2 (elevated). Reboot afterwards. |
| `--driver-install <ExtedoVirtualMouse.inf>` | Creates `Root\ExtedoVirtualMouse` and installs the test-signed driver (elevated, test VMs, [DRIVER.md](DRIVER.md)). |
| `--driver-uninstall` | Removes the device node(s) and the driver package (elevated). |

The live self-tests ignore `--user-idle-ms` and `--user-wait-ms`: they start at once, and touching mouse or keyboard
while they run aborts them (FAIL) - keep your hands off.

### 8.3 Exit codes

| Code | Meaning |
| --- | --- |
| `0` | Success; self-tests: PASS. The MCP server exits 0 when the client closes it. |
| `1` | Failure; self-tests: FAIL; installers: error (message on standard error). |
| `2` | Invalid command line (unknown option, missing value, value out of range). |

### 8.4 Removed option

`--backend` (older versions) is rejected with a hint: both input paths are now always available as separate tools;
`--device usbip|driver|none` chooses what backs the device tools.

## 9. desktop_status reference

| Field | Meaning |
| --- | --- |
| `inputs.device.enabled` | `false` with `--device none` (then `reason`). |
| `inputs.device.name` | `UsbIpVirtualMouse` or `ExtedoVirtualMouse`. |
| `inputs.device.available` | Virtual device attached and ready. |
| `inputs.device.keyboard` | The device keyboard is available (device typing). |
| `inputs.device.details` | Transport details: `shared` (the device host pipe), `host` (its `pid`, `instances` connected, `uptimeS`, `served` requests, baton `generation`, `idleExitMinutes`), usbip `server`, `busId`, `attach` result, or an `error` text. |
| `inputs.injected` | Always enabled: `SendInput`. |
| `remoteDesktopSession` | `true`: this is a Remote Desktop session; device input is impossible, use `_injected` tools. |
| `recommendedMouseTools` | Which mouse tool set to use right now, and why. |
| `typing` | Whether `desktop_type_text` uses the device keyboard or SendInput, and why. |
| `motion` | `human` or `linear`. |
| `stopped` | Emergency stop latched (Ctrl+Alt+F12 or tray menu). |
| `user.requiredIdleMs`, `user.maxWaitMs` | `--user-idle-ms`, `--user-wait-ms`. |
| `user.lastInputAgoMs` | How long ago you last used mouse or keyboard; input starts when it reaches `requiredIdleMs`. |
| `user.detection` | `raw input (...)`, or `unavailable` (then user priority cannot work). |
| `inputDesktop` | `default`; `secure (input refused)` while UAC / lock screen is shown; or `secure (device input allowed ...)` with `--secure-desktop-input device`. |
| `secureDesktopDeviceInput` | `true` when started with `--secure-desktop-input device`. |
| `control.instancePid` / `activePid` | This server's process id / the process holding the baton (0 = none). |
| `control.active` / `paused` | This server holds the baton / another server took it. |
| `control.generation` | Baton counter, increases on every takeover. |
| `control.hotkeyReady` | A server holds the Ctrl+Alt+F12 hotkey. If `false`, input is refused (fail closed). |
| `control.stopReason` | `emergency_stop`, `hotkey_unavailable` or `null`. |
| `bounds` | The virtual desktop rectangle. |
| `layout.monitors[]` | `index`, `name`, `primary`, `x`, `y`, `width`, `height`, `right`, `bottom`, `orientation`. |
| `layout.sharedEdges[]` | `between`, `at`, `range`: where the pointer can pass between monitors. |
| `cursor` | Pointer position. |
| `emergencyStop`, `coordinates` | Reminders: `Ctrl+Alt+F12`; physical desktop pixels, origin can be negative. |

## 10. Several AI clients and the shared device host

- **Loading does nothing.** Starting a server (an AI client starting) does not take control and shows nothing but its
  tray icon.
- **Whichever AI sends input takes over** the pointer ("baton"). The AI that was interrupted gets
  *"Interaction paused: another Desktop Interaction instance took control. A new interaction request takes the baton
  back."*; its running input stops and buttons it held are released. Read-only tools never take over.
- **One shared virtual device**: the first server that needs device input starts a background *device host*
  (the same program with `--device-host`, detached from the AI client, no console window). It owns the virtual mouse
  and keyboard and serves all servers of your Windows session over a named pipe that only your user can open
  (`\\.\pipe\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Device.<session id>`). Requests from a superseded server are
  refused, so it can never move the pointer for the new owner. The host ends **10 minutes** after the last server
  disconnected (`--device-host-idle-s`), so restarting an AI client does not unplug and re-plug the device.
- `desktop_status` → `inputs.device.details.host` shows the host's process id and how many servers are connected.
- The banner and pointer label always name the AI that is currently working.
- The emergency stop is shared: Ctrl+Alt+F12 stops all servers, and it is reset only when all of them have closed.
- `--device-sharing off` gives each server its own device (only the first server can use port 3240) - only for
  diagnosis.

## 11. Troubleshooting

| Symptom / message | Cause and fix |
| --- | --- |
| Server fails to start, exit code 2, *"Unknown option ..."*, *"... needs a value"*, *"... must be ..."* | Wrong `args` in the MCP configuration. Run the `.exe` with the same arguments in a console, compare with `--help`. |
| *"The user is using the mouse or keyboard ... waited 30 s"* | You were active. Let go of mouse and keyboard; the AI retries. Other software that injects input (a mouse jiggler, auto-clicker, remote-control tool) or a hovering drawing pen also counts as you. On test machines: `--user-idle-ms 0`. |
| *"The user moved the mouse or used the keyboard: input stopped"* | You touched mouse/keyboard during an action. Expected. |
| *"Escape is held; mouse operation cancelled."* | Escape was held down while an action ran. Release it. |
| *"The secure desktop is active ..."* | A UAC prompt, the lock screen or Ctrl+Alt+Del screen is shown. Answer / unlock it yourself (6.3), or see 6.4. |
| *"... this action uses injected input, which Windows never delivers to the secure desktop"* | With `--secure-desktop-input device` only the device tools work there. |
| *"Interaction paused: another Desktop Interaction instance took control"* | Another AI client sent input. Expected; the next input request of this AI takes the baton back. |
| *"Emergency stop is latched for all Desktop Interaction instances"* | Ctrl+Alt+F12 or the tray menu was used. Close all AI clients (or stop all processes, 3.3) and start again. |
| *"Emergency hotkey Ctrl+Alt+F12 is unavailable"* (`stopReason: hotkey_unavailable`) | Another application owns Ctrl+Alt+F12, or an old incompatible server version runs. Close it; input stays refused until a server can register the hotkey. |
| `inputs.device.available: false`, *"not attached ... no USB/IP client connected; usbip.exe not found"* | usbip-win2 not installed or not found. Install it (3.2) or pass `--usbip-exe`. |
| *"imported, waiting for Windows to configure it"* | First start: Windows installs the device drivers (a few seconds, up to 20 s). Try again. |
| *"Cannot listen on 127.0.0.1:3240"* | Another USB/IP server uses the port: an old server version without the shared host, a second host with `--device-sharing off`, or usbipd-win. Close it. |
| *"The shared device host did not start within 10 s"* / *"Lost the shared device host"* | The host could not start or crashed. The next request restarts it; check that the `.exe` is not blocked by security software. |
| *"This is a Remote Desktop session: device input would reach the console session"* | Use the `_injected` tools (6.7 a). |
| *"Device input is disabled (started with --device none)"* | Remove `--device none` or use `_injected` tools. |
| *"Device input moved the pointer to (a,b) instead of (x,y)"* | The device could not reach that pixel (unusual monitor layout, pointer clipped by an application). Try `desktop_mouse_move_injected`. |
| *"Point (x,y) lies in a gap between monitors"* / *"is outside the virtual desktop"* | Use coordinates inside a monitor from `desktop_status` → `layout`. |
| *"The ... backend scrolls whole wheel notches: delta must be a multiple of 120"* | Device scrolling: use 120, 240, -360, ... |
| `desktop_press_keys`: *"'x' is not on the keyboard layout of the foreground window"* | That character is not one key on the layout. Type text with `desktop_type_text`; use named keys for keys. |
| *"Ctrl+Alt+Del is refused"*, *"Win+L is refused"*, *"Ctrl+Alt+F12 ... never sent"* | By design (7.3). |
| *"Foreground window changed while typing."* | A window popped up or the focus moved while typing; nothing more was typed. Check the screen, focus the target and retry. |
| `desktop_type_text` result `input: "injected"` | No device keyboard: usbip-win2 missing, Remote Desktop session, or `--device driver/none`. In administrator windows the text does not arrive. |
| `injectedCharacters` in the result | Those characters are not on the window's keyboard layout (or need a dead key); they were sent with SendInput. |
| `desktop_focus_window` returns `focused: false` | Windows refused the foreground switch. Click into the window instead. |
| Wrong characters in a VM or RDP window | Different keyboard layouts on host and guest (6.6). |
| Clicks or text do nothing in an administrator window | An `_injected` tool was used; use the device tools. |
| Device keyboard missing after an update | An old device host still runs with the old device. Stop all `Extedo.AutoTest.Ai.Mcp.DesktopInteraction` processes (3.3); the next tool call starts a new host. |
| Build fails *"file is being used by another process"* | Running servers / device host keep the `.exe` open. Stop them (3.3) or build into another folder. |
| Frame or banner stays visible | It disappears 6 s after the last input. If it stays, the server hangs: stop the processes (3.3). |
| Screenshots black | Secure desktop, locked PC, display off, minimised or disconnected Remote Desktop session. |
| `user.detection: "unavailable"` | Raw input registration failed; user priority cannot work. Restart the AI client. |

## 12. Safety and privacy

- Screenshots and feedback pictures show the AI whatever is on your screen, and the AI client may send them to its
  model provider. Close confidential content, or do not run AI tasks while it is open. Connect only AI clients you
  trust.
- Text entry is limited to printable characters; keys and shortcuts are a separate, explicit tool, and
  Ctrl+Alt+Del, Win+L and your emergency stop Ctrl+Alt+F12 are refused. The AI must not type passwords.
- The server never elevates itself and never changes Windows settings. Installation modes (`--usbip-install`,
  `--driver-install`) run only when you start them yourself from an elevated prompt, and only pinned installers.
- The virtual device exists only while the device host runs (it ends 10 minutes after the last AI client).
- usbip-win2 talks to the device host only on the local machine (127.0.0.1:3240); the device host's pipe accepts only
  your own user account.
- Input fails closed: without the emergency hotkey registered, with the stop latched, on the secure desktop (unless
  6.4) and while you are active, nothing is sent.
- Use device input on the secure desktop (6.4) and "UAC on the normal desktop" (6.3) only on test machines, not on PCs
  with production access.

## 13. Checks after an update

From `Research\DesktopInteraction`:

```powershell
$exe = '.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe'
& $exe --version
& $exe --motion-self-test; & $exe --usbip-self-test; & $exe --device-host-self-test         # no input
& $exe --coordination-self-test; & $exe --layout-self-test; & $exe --feedback-self-test     # no input
.\Scripts\Smoke-Test.ps1 -Capture       # MCP protocol, all 25 tools listed, invalid input rejected, capture
.\Scripts\Test-MultiInstance.ps1        # two live servers: takeover, pause, hotkey recovery (no input)
& $exe --self-test --input device       # moves the real pointer on its own test window: hands off
& $exe --feedback-live-test --input device
```

Each must print `PASS` (exit code 0).

Scripts in `Scripts\`:

| Script | Purpose | Parameters |
| --- | --- | --- |
| `Invoke-DesktopTool.ps1` | Call one tool (or a list) ad hoc through a fresh server. | `-Tool`, `-ArgumentsJson` (default `{}`), `-ImagePath` (save the PNG), `-ActionsJson` (list of `{name,arguments}`), `-ServerArguments` (e.g. `'--device','none'`) |
| `Smoke-Test.ps1` | Protocol smoke test. | `-Executable`, `-Capture` |
| `Test-MultiInstance.ps1` | Two servers: baton, pause, emergency stop. | `-Executable` |
| `Test-UacElevation.ps1` | Blind UAC click QA scenario (6.4). | `-Mode probe\|calibrate\|run`, `-YesX`, `-YesY`, `-CalibrationFile`, `-Exe`, `-UserIdleMs`, `-SecureWaitMs` |
| `Install-UsbIp.ps1` | Install / remove usbip-win2 (elevated). | `-Installer`, `-Executable`, `-Sha256`, `-Uninstall` |
| `Install-Driver.ps1` | Install / remove the Extedo driver (elevated, test VMs). | `-Package`, `-Executable`, `-TrustTestCertificate`, `-Uninstall` |

Example: `.\Scripts\Invoke-DesktopTool.ps1 -Tool desktop_capture -ArgumentsJson '{"scope":"desktop"}' -ImagePath desktop.png`.

## 14. Files and glossary

| Path | Content |
| --- | --- |
| `bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe` | The server, device host, installers and self-tests (one program). |
| `mcp.example.json` | Example MCP client configuration. |
| `ThirdParty\usbip-win2\` | Where you put the usbip-win2 installer (not in git). |
| `Scripts\uac-calibration.json` | Measured UAC "Yes" position written by `Test-UacElevation.ps1 -Mode calibrate`. |
| `%TEMP%\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.usbip-install.log` | usbip-win2 installer log. |

| Term | Meaning |
| --- | --- |
| Baton | The right to send input. One server holds it at a time; any input request takes it. |
| Device input | Input through the virtual USB (or driver) mouse/keyboard; Windows sees real hardware. |
| Injected input | Input through Windows `SendInput`; flagged as simulated, blocked by elevated windows. |
| Device host | Background process (`--device-host`) that owns the virtual device for all servers of a Windows session. |
| Secure desktop | The protected desktop of UAC prompts, the lock screen and Ctrl+Alt+Del; not visible to normal programs. |
| UIPI | User Interface Privilege Isolation: Windows blocks injected input into windows with higher rights. |
| Visual feedback | The PNG of what changed that every input tool returns. |
| Late change | A change that appeared after a tool returned; reported on the next call. |
