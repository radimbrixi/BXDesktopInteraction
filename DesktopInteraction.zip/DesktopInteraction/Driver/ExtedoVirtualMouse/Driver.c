/*
 * ExtedoVirtualMouse - KMDF HID source driver using the Virtual HID Framework (VHF).
 *
 * Internal QA test automation only (test VMs and tester machines). Exposes one absolute pointing
 * device with 5 buttons, vertical wheel and horizontal pan. User mode writes complete reports via
 * IOCTL_EXTEDO_MOUSE_REPORT on \\.\ExtedoVirtualMouse; VHF delivers them to the HID class stack,
 * so Windows sees them as input from a mouse device (not as SendInput-injected input).
 *
 * The device is root-enumerated (Root\ExtedoVirtualMouse) with vhf.sys as lower filter (see INF).
 */
#include <ntddk.h>
#include <wdf.h>
#include <vhf.h>
#include "Public.h"

DRIVER_INITIALIZE DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD EvmEvtDeviceAdd;
EVT_WDF_OBJECT_CONTEXT_CLEANUP EvmEvtDeviceCleanup;
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL EvmEvtIoDeviceControl;
EVT_WDF_FILE_CLEANUP EvmEvtFileCleanup;

typedef struct _DEVICE_CONTEXT
{
    VHFHANDLE           Vhf;
    WDFSPINLOCK         Lock;
    BOOLEAN             HasReport;
    EXTEDO_MOUSE_REPORT Last;   // last delivered position/buttons (wheels stored as 0)
} DEVICE_CONTEXT, *PDEVICE_CONTEXT;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_CONTEXT, GetDeviceContext)

// Absolute pointer (same layout as common VM "tablet" pointers), report ID 1, 8 bytes total.
static const UCHAR ReportDescriptor[] =
{
    0x05, 0x01,        // Usage Page (Generic Desktop)
    0x09, 0x02,        // Usage (Mouse)
    0xA1, 0x01,        // Collection (Application)
    0x85, EXTEDO_MOUSE_REPORT_ID, //   Report ID (1)
    0x09, 0x01,        //   Usage (Pointer)
    0xA1, 0x00,        //   Collection (Physical)
    0x05, 0x09,        //     Usage Page (Button)
    0x19, 0x01,        //     Usage Minimum (1)
    0x29, 0x05,        //     Usage Maximum (5)
    0x15, 0x00,        //     Logical Minimum (0)
    0x25, 0x01,        //     Logical Maximum (1)
    0x95, 0x05,        //     Report Count (5)
    0x75, 0x01,        //     Report Size (1)
    0x81, 0x02,        //     Input (Data, Variable, Absolute)
    0x95, 0x01,        //     Report Count (1)
    0x75, 0x03,        //     Report Size (3)
    0x81, 0x03,        //     Input (Constant) - padding
    0x05, 0x01,        //     Usage Page (Generic Desktop)
    0x09, 0x30,        //     Usage (X)
    0x09, 0x31,        //     Usage (Y)
    0x15, 0x00,        //     Logical Minimum (0)
    0x26, 0xFF, 0x7F,  //     Logical Maximum (32767)
    0x35, 0x00,        //     Physical Minimum (0)
    0x46, 0xFF, 0x7F,  //     Physical Maximum (32767)
    0x75, 0x10,        //     Report Size (16)
    0x95, 0x02,        //     Report Count (2)
    0x81, 0x02,        //     Input (Data, Variable, Absolute)
    0x35, 0x00,        //     Physical Minimum (0) - reset to logical
    0x45, 0x00,        //     Physical Maximum (0)
    0x09, 0x38,        //     Usage (Wheel)
    0x15, 0x81,        //     Logical Minimum (-127)
    0x25, 0x7F,        //     Logical Maximum (127)
    0x75, 0x08,        //     Report Size (8)
    0x95, 0x01,        //     Report Count (1)
    0x81, 0x06,        //     Input (Data, Variable, Relative)
    0x05, 0x0C,        //     Usage Page (Consumer)
    0x0A, 0x38, 0x02,  //     Usage (AC Pan)
    0x95, 0x01,        //     Report Count (1)
    0x81, 0x06,        //     Input (Data, Variable, Relative)
    0xC0,              //   End Collection
    0xC0               // End Collection
};

DECLARE_CONST_UNICODE_STRING(EvmDeviceName, EXTEDO_MOUSE_DEVICE_NAME);
DECLARE_CONST_UNICODE_STRING(EvmDosName, EXTEDO_MOUSE_DOS_NAME);
// SYSTEM and Administrators: full access. Interactive users: read/write, so a non-elevated
// MCP server started by LM Studio can send reports (equivalent exposure to SendInput).
DECLARE_CONST_UNICODE_STRING(EvmDeviceSddl, L"D:P(A;;GA;;;SY)(A;;GA;;;BA)(A;;GRGW;;;IU)");

#ifdef ALLOC_PRAGMA
#pragma alloc_text(INIT, DriverEntry)
#pragma alloc_text(PAGE, EvmEvtDeviceAdd)
#pragma alloc_text(PAGE, EvmEvtDeviceCleanup)
#endif

NTSTATUS
DriverEntry(_In_ PDRIVER_OBJECT DriverObject, _In_ PUNICODE_STRING RegistryPath)
{
    WDF_DRIVER_CONFIG config;
    WDF_DRIVER_CONFIG_INIT(&config, EvmEvtDeviceAdd);
    return WdfDriverCreate(DriverObject, RegistryPath, WDF_NO_OBJECT_ATTRIBUTES, &config, WDF_NO_HANDLE);
}

static NTSTATUS
EvmSubmitReport(_In_ PDEVICE_CONTEXT Context, _In_ const EXTEDO_MOUSE_REPORT* Report)
{
    // VHF copies the report buffer before VhfReadReportSubmit returns.
    EXTEDO_MOUSE_REPORT copy = *Report;
    HID_XFER_PACKET packet;
    NTSTATUS status;

    if (Context->Vhf == NULL)
    {
        return STATUS_DEVICE_NOT_READY;
    }

    packet.reportBuffer = (PUCHAR)&copy;
    packet.reportBufferLen = sizeof(copy);
    packet.reportId = EXTEDO_MOUSE_REPORT_ID;

    status = VhfReadReportSubmit(Context->Vhf, &packet);
    if (NT_SUCCESS(status))
    {
        WdfSpinLockAcquire(Context->Lock);
        Context->Last = copy;
        Context->Last.Wheel = 0;
        Context->Last.HWheel = 0;
        Context->HasReport = TRUE;
        WdfSpinLockRelease(Context->Lock);
    }
    return status;
}

NTSTATUS
EvmEvtDeviceAdd(_In_ WDFDRIVER Driver, _Inout_ PWDFDEVICE_INIT DeviceInit)
{
    NTSTATUS status;
    WDF_FILEOBJECT_CONFIG fileConfig;
    WDF_OBJECT_ATTRIBUTES attributes;
    WDF_OBJECT_ATTRIBUTES lockAttributes;
    WDF_IO_QUEUE_CONFIG queueConfig;
    VHF_CONFIG vhfConfig;
    WDFDEVICE device;
    PDEVICE_CONTEXT context;

    UNREFERENCED_PARAMETER(Driver);
    PAGED_CODE();

    status = WdfDeviceInitAssignName(DeviceInit, &EvmDeviceName);
    if (!NT_SUCCESS(status)) return status;

    status = WdfDeviceInitAssignSDDLString(DeviceInit, &EvmDeviceSddl);
    if (!NT_SUCCESS(status)) return status;

    WdfDeviceInitSetDeviceType(DeviceInit, FILE_DEVICE_UNKNOWN);

    WDF_FILEOBJECT_CONFIG_INIT(&fileConfig, WDF_NO_EVENT_CALLBACK, WDF_NO_EVENT_CALLBACK, EvmEvtFileCleanup);
    WdfDeviceInitSetFileObjectConfig(DeviceInit, &fileConfig, WDF_NO_OBJECT_ATTRIBUTES);

    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attributes, DEVICE_CONTEXT);
    attributes.EvtCleanupCallback = EvmEvtDeviceCleanup;
    status = WdfDeviceCreate(&DeviceInit, &attributes, &device);
    if (!NT_SUCCESS(status)) return status;

    context = GetDeviceContext(device);   // zero-initialized by WDF

    WDF_OBJECT_ATTRIBUTES_INIT(&lockAttributes);
    lockAttributes.ParentObject = device;
    status = WdfSpinLockCreate(&lockAttributes, &context->Lock);
    if (!NT_SUCCESS(status)) return status;

    status = WdfDeviceCreateSymbolicLink(device, &EvmDosName);
    if (!NT_SUCCESS(status)) return status;

    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(&queueConfig, WdfIoQueueDispatchSequential);
    queueConfig.EvtIoDeviceControl = EvmEvtIoDeviceControl;
    status = WdfIoQueueCreate(device, &queueConfig, WDF_NO_OBJECT_ATTRIBUTES, WDF_NO_HANDLE);
    if (!NT_SUCCESS(status)) return status;

    VHF_CONFIG_INIT(&vhfConfig, WdfDeviceWdmGetDeviceObject(device), (USHORT)sizeof(ReportDescriptor), (PUCHAR)ReportDescriptor);
    status = VhfCreate(&vhfConfig, &context->Vhf);
    if (!NT_SUCCESS(status))
    {
        context->Vhf = NULL;
        return status;
    }

    return VhfStart(context->Vhf);
}

VOID
EvmEvtDeviceCleanup(_In_ WDFOBJECT Object)
{
    PDEVICE_CONTEXT context = GetDeviceContext((WDFDEVICE)Object);
    PAGED_CODE();

    if (context->Vhf != NULL)
    {
        VhfDelete(context->Vhf, TRUE);
        context->Vhf = NULL;
    }
}

VOID
EvmEvtIoDeviceControl(
    _In_ WDFQUEUE Queue,
    _In_ WDFREQUEST Request,
    _In_ size_t OutputBufferLength,
    _In_ size_t InputBufferLength,
    _In_ ULONG IoControlCode)
{
    NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;
    PEXTEDO_MOUSE_REPORT report;
    PDEVICE_CONTEXT context = GetDeviceContext(WdfIoQueueGetDevice(Queue));

    UNREFERENCED_PARAMETER(OutputBufferLength);

    if (IoControlCode == IOCTL_EXTEDO_MOUSE_REPORT)
    {
        status = WdfRequestRetrieveInputBuffer(Request, sizeof(EXTEDO_MOUSE_REPORT), (PVOID*)&report, NULL);
        if (NT_SUCCESS(status))
        {
            if (InputBufferLength != sizeof(EXTEDO_MOUSE_REPORT) ||
                report->ReportId != EXTEDO_MOUSE_REPORT_ID ||
                (report->Buttons & ~EXTEDO_MOUSE_BUTTON_MASK) != 0 ||
                report->X > EXTEDO_MOUSE_ABSOLUTE_MAX ||
                report->Y > EXTEDO_MOUSE_ABSOLUTE_MAX ||
                report->Wheel == -128 ||
                report->HWheel == -128)
            {
                status = STATUS_INVALID_PARAMETER;
            }
            else
            {
                status = EvmSubmitReport(context, report);
            }
        }
    }

    WdfRequestComplete(Request, status);
}

// A client handle closed (graceful exit or crash): release any buttons it left pressed,
// keeping the last position so the pointer does not jump.
VOID
EvmEvtFileCleanup(_In_ WDFFILEOBJECT FileObject)
{
    PDEVICE_CONTEXT context = GetDeviceContext(WdfFileObjectGetDevice(FileObject));
    EXTEDO_MOUSE_REPORT release = { 0 };
    BOOLEAN send = FALSE;

    WdfSpinLockAcquire(context->Lock);
    if (context->HasReport && context->Last.Buttons != 0)
    {
        release = context->Last;
        release.Buttons = 0;
        send = TRUE;
    }
    WdfSpinLockRelease(context->Lock);

    if (send)
    {
        (VOID)EvmSubmitReport(context, &release);
    }
}
