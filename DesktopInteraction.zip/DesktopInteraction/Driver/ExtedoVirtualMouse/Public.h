// Shared contract between ExtedoVirtualMouse.sys and the user-mode MCP server
// (Extedo.AutoTest.Ai.Mcp.DesktopInteraction, Desktop\DriverBackend.cs). Keep both in sync.
#pragma once

// User-mode path: \\.\ExtedoVirtualMouse
#define EXTEDO_MOUSE_DOS_NAME      L"\\DosDevices\\ExtedoVirtualMouse"
#define EXTEDO_MOUSE_DEVICE_NAME   L"\\Device\\ExtedoVirtualMouse"

#define EXTEDO_MOUSE_REPORT_ID     1
#define EXTEDO_MOUSE_BUTTON_MASK   0x1F    // left=1, right=2, middle=4, x1=8, x2=16
#define EXTEDO_MOUSE_ABSOLUTE_MAX  32767   // X/Y logical range 0..32767 (absolute pointer)

// 0x0022A000: FILE_DEVICE_UNKNOWN, function 0x800, METHOD_BUFFERED, FILE_WRITE_ACCESS
#define IOCTL_EXTEDO_MOUSE_REPORT CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_WRITE_ACCESS)

#include <pshpack1.h>
// Exactly matches the HID input report described in Driver.c (report ID 1).
typedef struct _EXTEDO_MOUSE_REPORT
{
    UCHAR  ReportId;   // must be EXTEDO_MOUSE_REPORT_ID
    UCHAR  Buttons;    // complete held-button state, EXTEDO_MOUSE_BUTTON_MASK
    USHORT X;          // absolute 0..32767, little-endian
    USHORT Y;          // absolute 0..32767, little-endian
    CHAR   Wheel;      // relative notches -127..127, positive = up
    CHAR   HWheel;     // relative notches -127..127, positive = right (AC Pan)
} EXTEDO_MOUSE_REPORT, *PEXTEDO_MOUSE_REPORT;
#include <poppack.h>

C_ASSERT(sizeof(EXTEDO_MOUSE_REPORT) == 8);
