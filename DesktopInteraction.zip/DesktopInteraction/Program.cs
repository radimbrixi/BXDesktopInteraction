using System.Text;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.SelfTests;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using ModelContextProtocol.Protocol;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction;

/// <summary>
/// Local stdio MCP server for Windows desktop interaction (mouse, text, screenshots, windows).
/// The WinForms message loop runs on the main STA thread (cursor overlay, tray icon, emergency hotkey);
/// the MCP host runs in the background.
/// </summary>
internal static class Program
{
    internal const string ServerName = "extedo-desktop-interaction";
    internal const string ServerVersion = "0.7.0";

    private const string Instructions =
        "Local Windows mouse, text and screenshot control. One shared system pointer. Coordinates are physical virtual-desktop pixels. " +
        "Capture again after layout changes. The user has priority: input waits until the user's own mouse and keyboard have been idle for 7 s, " +
        "and a running action stops when the user touches them. Starting an instance does not take control; input tools take the baton " +
        "(from another AI client's instance too), desktop_take_control does so explicitly; status, capture and list tools do not. Superseded input cancels. " +
        "Ctrl+Alt+F12 latches an emergency stop for all instances and is never cleared by takeover. desktop_type_text types printable text only; " +
        "press Enter, Escape, Tab, arrows, F-keys and shortcuts with desktop_press_keys (SendKeys syntax). Device tools reach elevated windows; injected tools do not.";

    [STAThread]
    private static void Main(string[] args)
    {
        if (DesktopOptions.WantsHelp(args)) { Console.WriteLine(DesktopOptions.Usage(ServerName, ServerVersion)); return; }
        if (args.Contains("--version")) { Console.WriteLine($"{ServerName} {ServerVersion}"); return; }
        ApplicationConfiguration.Initialize();
        if (args.Length == 2 && args[0] == "--coordination-worker") { CoordinationSelfTest.Worker(args[1]); return; } // internal: child of --coordination-self-test
        try { DesktopOptions.Validate(args); }
        catch (ArgumentException e) { Console.Error.WriteLine($"{e.Message} Run with --help for the list of options."); Environment.ExitCode = 2; return; }
        if (args.Contains("--coordination-self-test")) { Environment.ExitCode = CoordinationSelfTest.Run(); return; }
        if (args.Contains("--motion-self-test")) { Environment.ExitCode = MotionSelfTest.Run(); return; }
        if (args.Contains("--usbip-self-test")) { Environment.ExitCode = UsbIpSelfTest.Run(); return; }
        if (args.Contains("--feedback-self-test")) { Environment.ExitCode = FeedbackSelfTest.Run(); return; }
        if (args.Contains("--device-host-self-test")) { Environment.ExitCode = DeviceHostSelfTest.Run(); return; }
        if (args.Contains("--layout-self-test")) { Environment.ExitCode = LayoutSelfTest.Run(); return; }
        if (args.Contains("--usbip-install") || args.Contains("--usbip-uninstall"))
        {
            try
            {
                Environment.ExitCode = args.Contains("--usbip-uninstall")
                    ? UsbIpInstaller.Uninstall()
                    : UsbIpInstaller.Install(
                        DesktopOptions.RawValue(args, "--usbip-install") ?? throw new ArgumentException("Usage: --usbip-install <path to USBip-x.y.z-x64.exe> [--usbip-sha256 <hash>]"),
                        DesktopOptions.RawValue(args, "--usbip-sha256"));
            }
            catch (Exception e) { Console.Error.WriteLine(e.Message); Environment.ExitCode = 1; }
            return;
        }
        if (args.Contains("--driver-install") || args.Contains("--driver-uninstall"))
        {
            try
            {
                Environment.ExitCode = args.Contains("--driver-uninstall")
                    ? DriverInstaller.Uninstall()
                    : DriverInstaller.Install(DesktopOptions.RawValue(args, "--driver-install")
                        ?? throw new ArgumentException("Usage: --driver-install <path to ExtedoVirtualMouse.inf>"));
            }
            catch (Exception e) { Console.Error.WriteLine(e.Message); Environment.ExitCode = 1; }
            return;
        }

        DesktopOptions options;
        try { options = DesktopOptions.Parse(args); }
        catch (ArgumentException e) { Console.Error.WriteLine(e.Message); Environment.ExitCode = 2; return; }

        Native.timeBeginPeriod(1); // 1 ms timer resolution for ~125 Hz human-like motion pacing
        if (args.Contains("--device-host")) { Environment.ExitCode = DeviceHost.Run(options, options.HostIdle); return; }
        if (args.Contains("--self-test")) { Environment.ExitCode = InteractionSelfTest.Run(options); return; }
        if (args.Contains("--feedback-live-test")) { Environment.ExitCode = FeedbackLiveTest.Run(options, DesktopOptions.RawValue(args, "--save-feedback")); return; }

        Console.InputEncoding = new UTF8Encoding(false);
        Console.OutputEncoding = new UTF8Encoding(false);

        using var overlay = new CursorOverlay();
        using var device = options.CreateDevice(() => overlay.Control.Lease);
        using var injected = new SendInputBackend();
        var mouse = new MouseController(overlay, device, injected, options.HumanMotion, options.UserIdleMs, options.UserWaitMs, options.SecureDesktopDeviceInput);
        overlay.EmergencyStop = mouse.ReleaseAll;
        if (options.Frame) overlay.Frame = new ScreenFrame(overlay, excludeFromCapture: !options.FrameCaptured);
        if (!args.Contains("--demo")) { overlay.Driving = () => mouse.Driving; overlay.Framing = () => mouse.Framing; }
        Application.ApplicationExit += (_, _) => mouse.ReleaseAll();
        Console.CancelKeyPress += (_, _) => mouse.ReleaseAll();

        overlay.Shown += (_, _) => _ = Task.Run(async () =>
        {
            try
            {
                if (args.Contains("--demo")) await Task.Delay(Timeout.Infinite);
                else await BuildHost(args, mouse).RunAsync();
            }
            catch (Exception e) { Console.Error.WriteLine(e); Environment.ExitCode = 1; }
            finally
            {
                mouse.ReleaseAll();
                if (!overlay.IsDisposed) overlay.BeginInvoke(overlay.Close);
            }
        });

        Console.Error.WriteLine($"Extedo Desktop Interaction: local stdio MCP; device input {device?.Name ?? "disabled"}{(device is RemoteDeviceBackend ? " (shared device host)" : "")} + injected input SendInput; motion {(options.HumanMotion ? "human" : "linear")}; Ctrl+Alt+F12 emergency stop; Escape cancels motion.");
        Application.Run(overlay);
    }

    private static IHost BuildHost(string[] args, MouseController mouse)
    {
        var builder = Host.CreateApplicationBuilder(args);

        // stdout carries the MCP protocol; every log line must go to stderr.
        builder.Logging.ClearProviders();
        builder.Logging.AddConsole(options => options.LogToStandardErrorThreshold = LogLevel.Trace);
        builder.Logging.SetMinimumLevel(LogLevel.Warning);
        // Tool errors (e.g. invalid coordinates) are returned to the client; don't also log them as failures.
        builder.Logging.AddFilter("ModelContextProtocol.Server.McpServer", LogLevel.Critical);

        builder.Services.AddSingleton(mouse);
        var overlay = mouse.Overlay;
        builder.Services
            .AddMcpServer(options =>
            {
                options.ServerInfo = new Implementation { Name = ServerName, Version = ServerVersion };
                options.ServerInstructions = Instructions;
            })
            .WithRequestFilters(filters => filters.AddCallToolFilter(next => (context, cancellationToken) =>
            {
                // One stdio client per process: its name labels the cursor marker while this instance drives.
                overlay.ClientName ??= context.Server.ClientInfo is { } client ? client.Title ?? client.Name : null;
                return next(context, cancellationToken);
            }))
            .WithStdioServerTransport()
            .WithToolsFromAssembly();

        return builder.Build();
    }
}
