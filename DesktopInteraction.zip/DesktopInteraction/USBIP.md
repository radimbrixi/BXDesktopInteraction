# USB/IP virtual mouse (`--device usbip`, the default)

Device input on a normal Windows 10/11 PC **without an own driver and without driver signing**. The MCP server
emulates a USB absolute mouse and serves it over the USB/IP protocol on `127.0.0.1:3240`. The free, Microsoft-signed
[usbip-win2](https://github.com/vadimgrn/usbip-win2) client (BSD-2-Clause) attaches it, and Windows binds its own
in-box USB HID mouse drivers. Applications and hooks see a real USB mouse, not injected input.

```
LM Studio ──stdio──> Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe (--device usbip)
                        │ USB/IP server, 127.0.0.1:3240, bus id 1-1 (emulated USB mouse)
                        ▼
                    usbip-win2 (Microsoft-signed UDE driver) → usbccgp/hidusb/mouhid (Windows in-box) → input
```

| | `_injected` tools (SendInput) | `--device driver` | `--device usbip` |
| --- | --- | --- | --- |
| Input seen as | injected | device | device (USB mouse) |
| Own kernel driver | no | yes (test-signed or attestation) | no |
| Third-party install | none | ExtedoVirtualMouse | usbip-win2 (once, admin + reboot) |
| Secure Boot / test mode | n/a | test mode, or Partner Center | not needed (Microsoft-signed) |

The same USB device also has a **keyboard** (report ID 3): `desktop_type_text` presses real keys with the keyboard layout of the target window, so text reaches elevated windows too. The physical mouse and keyboard keep working next to the virtual ones. Full guide: [MANUAL.md](MANUAL.md).

## One-time setup (the user does this; the MCP server never installs anything)

1. **Ask IT/endpoint security first** on a managed PC: usbip-win2 is a third-party kernel driver (Microsoft-signed).
2. Create a restore point. Installing usbip-win2 briefly resets all USB hubs (attached USB devices reconnect).
3. Download the installer from [usbip-win2 releases](https://github.com/vadimgrn/usbip-win2/releases) (x64) into
   `ThirdParty\usbip-win2\` (git-ignored). Tested version: `USBip-0.9.8.1-x64.exe`, SHA-256
   `38cad6d4432b52d5bb9409d9ad03b72fdffc4ada4cd3a48fbeca1a2752a8518a`, Authenticode signer Cloudyne Systems (OSSign).
   Avoid 0.9.7.8 (memory corruption/BSOD bug, fixed in 0.9.8.0). Note the version you tested and keep testers on it.
4. Install silently from an elevated PowerShell, then reboot:

   ```powershell
   dotnet build Research\DesktopInteraction -c Release
   Research\DesktopInteraction\Scripts\Install-UsbIp.ps1
   ```

   This runs the Inno Setup installer with `/VERYSILENT /SUPPRESSMSGBOXES /NORESTART` (log in `%TEMP%`), but only
   when its SHA-256 is pinned in `Desktop\UsbIpInstaller.cs`. For another release pass `-Installer <path> -Sha256 <hash>`
   after testing it, and add it to the pinned list. Interactive alternative: run the installer as administrator.
5. Check that `usbip.exe` exists (default `C:\Program Files\USBip\usbip.exe`); otherwise pass `--usbip-exe <path>`.

Remove silently: `Scripts\Install-UsbIp.ps1 -Uninstall` (elevated), then reboot.

## Use

Nothing to configure: `--device usbip` is the default, and it backs the device mouse tools (`desktop_mouse_move`, ...).
The `_injected` tools use SendInput and work without usbip-win2.

On start the server listens on `127.0.0.1:3240` and runs `usbip attach -r 127.0.0.1 -b 1-1`. Windows enumerates
*Extedo Virtual Mouse and Keyboard (USB/IP)* (VID 1209 / PID 0001, the pid.codes test ID) within a few seconds; the first input waits up
to 20 s for it. When the server exits (also on crash) the connection closes and usbip-win2 unplugs the device.

- `--usbip-attach manual`: do not run `usbip attach`; attach yourself with `usbip attach -r 127.0.0.1 -b 1-1`
  (for example from an elevated prompt, if attach requires elevation on your installation).
- `desktop_status` → `inputs.device` (`available`, `keyboard`) and `inputs.device.details`: device host (pid,
  connected instances), attach result, delivered reports, learned axis mapping.
- The device is owned by the shared device host (`--device-host`, started automatically by the first server that
  needs it, ends 10 minutes after the last server, `--device-host-idle-s`), so all AI clients use the same device.

Verify device input (moves the real pointer on its own test window; hands off the mouse):

```powershell
.\bin\Release\net10.0-windows\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe --self-test --input device
```

It must print `PASS (UsbIpVirtualMouse, ...) ... injected=0`.

## Limits and troubleshooting

- One device host per Windows session serves the device on port 3240 for all instances. With
  `--device-sharing off` each instance owns its device and only the first gets the port. Another USB/IP server (for
  example usbipd-win) on 3240 conflicts; status then reports the listen error.
- The server listens on loopback only and accepts one importer at a time.
- Scroll accepts whole notches only (multiples of 120).
- Multiple monitors: Windows maps an absolute USB mouse to the **primary monitor only**. The device therefore has
  two collections (Windows shows two *HID-compliant mouse* entries): absolute (report ID 1) for targets on the primary
  monitor, exact in one step, and relative (report ID 2) for other monitors. Relative moves are corrected against the
  real pointer position until they land exactly, so they also work with *Enhance pointer precision* on (no mouse
  setting is changed). All buttons and the wheel use the relative collection, because Windows tracks button state
  per collection.
- Tested on Windows 11 with usbip-win2 0.9.8.1, three monitors, *Enhance pointer precision* on, test window on a
  secondary monitor: `--self-test --input device` passed 16 of 17 runs (human and linear motion), always
  `injected=0`. One early linear run failed during the drag step and could not be reproduced.
- Later, with seven monitors (several rotated/offset): relative moves first overshot into a neighbouring monitor's
  sticky corner. Fixed by damped relative steps that wait for Windows to apply each step, axis-by-axis sliding when a
  diagonal step is blocked at a monitor edge, and keeping the human-like overshoot on the target monitor. Afterwards
  the failing path passed 5 of 5 and the device self-test 6 of 6.
- With planned routes across shared edges: 16 of 16 moves across 3-5 monitors landed exactly (8 device, 8 injected),
  device self-test 4 of 4.
- `usbip attach` worked without elevation.
- `--usbip-self-test` checks the USB/IP protocol and device emulation in-process (no usbip-win2 needed, no input).
  It cannot prove compatibility with usbip-win2 itself: that is verified only by the `--self-test` above.
