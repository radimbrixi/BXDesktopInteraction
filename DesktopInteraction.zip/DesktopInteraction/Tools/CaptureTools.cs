using System.ComponentModel;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Tools;

[McpServerToolType]
internal sealed class CaptureTools(MouseController mouse)
{
    [McpServerTool(Name = "desktop_capture", Title = "Capture screenshot", ReadOnly = true, Destructive = false, Idempotent = false, OpenWorld = false)]
    [Description("Capture the primary monitor (default), one monitor by monitorIndex from desktop_status, or the whole desktop as PNG, with the cyan cursor marker composited. Image pixel (u,v) maps to desktop (bounds.x+u, bounds.y+v). Maximum 40 million pixels. Does not take control." + StatusTools.Late)]
    public CallToolResult Capture(
        [Description("primary, monitor or desktop.")] string scope = "primary",
        [Description("Monitor index (0-63) when scope is monitor.")] int monitorIndex = 0)
        => ToolGuard.Read(() => mouse.Capture(scope, monitorIndex));
}
