using System.ComponentModel;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Tools;

[McpServerToolType]
internal sealed class KeyboardTools(MouseController mouse)
{
    internal const string Feedback = " Returns visual feedback: a PNG of what changed around the text caret (the pointer if the app has no Win32 caret), limited to the focused window, or 100x100 px outside a known window." + StatusTools.Late;

    [McpServerTool(Name = "desktop_type_text", Title = "Type text", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Type printable Unicode text into the focused control. Uses the virtual device keyboard when available (real key presses with the window's keyboard layout: reaches elevated windows such as admin PowerShell, VM windows and games), otherwise SendInput; the result says which ('input'). Printable text only: press Enter, Tab, Escape and shortcuts with desktop_press_keys. Stops if the foreground window changes." + Feedback)]
    public Task<CallToolResult> TypeText([Description("1-1000 printable characters.")] string text)
        => ToolGuard.Act("desktop_type_text", FeedbackFocus.Keyboard, null, () => mouse.TypeText(text),
            prepare: ToolGuard.Input(mouse, CancellationToken.None));

    internal const string KeySyntax = " Syntax of Windows Forms SendKeys: characters press their key; + Shift, ^ Ctrl, % Alt, # Win apply to the next key or a group, e.g. ^c, ^+{ESC}, %{F4}, #r, +(abc); ~ or {ENTER} Enter; named keys {ESC} {TAB} {BS} {DEL} {INS} {HOME} {END} {PGUP} {PGDN} {UP} {DOWN} {LEFT} {RIGHT} {F1}-{F24} {SPACE} {CAPSLOCK} {NUMLOCK} {SCROLLLOCK} {PRTSC} {BREAK} {HELP} {APPS} {WIN} {ADD} {SUBTRACT} {MULTIPLY} {DIVIDE}; {KEY n} repeats (n 1-100, e.g. {LEFT 5}); literal {+} {^} {%} {#} {~} {(} {)} {{} {}}. At most 500 presses. Refused: Ctrl+Alt+Del, Win+L, Ctrl+Alt+F12.";

    [McpServerTool(Name = "desktop_press_keys", Title = "Press keys", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Press keys and shortcuts (Enter, Escape, Tab, arrows, F-keys, Ctrl+C, Alt+F4, Win+R, ...) in the foreground window. Uses the virtual device keyboard when available (real key presses: reach elevated windows such as admin PowerShell, VM windows), otherwise SendInput; the result says which ('input')." + KeySyntax + Feedback)]
    public Task<CallToolResult> PressKeys([Description("Key sequence in SendKeys syntax, e.g. \"{ENTER}\", \"{ESC}\", \"^a{DEL}\", \"%{F4}\", \"#r\", \"{TAB 3}\".")] string keys)
        => ToolGuard.Act("desktop_press_keys", FeedbackFocus.Keyboard, null, () => mouse.PressKeys(keys),
            prepare: ToolGuard.Input(mouse, CancellationToken.None));

    [McpServerTool(Name = "desktop_press_keys_injected", Title = "Press keys (SendInput)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Press keys and shortcuts with SendInput (injected; blocked by elevated windows). Use in a Remote Desktop session or without the device keyboard." + KeySyntax + Feedback)]
    public Task<CallToolResult> PressKeysInjected([Description("Key sequence in SendKeys syntax, e.g. \"{ENTER}\", \"{ESC}\", \"^a{DEL}\".")] string keys)
        => ToolGuard.Act("desktop_press_keys_injected", FeedbackFocus.Keyboard, null, () => mouse.PressKeys(keys, InputKind.Injected),
            prepare: ToolGuard.Input(mouse, CancellationToken.None));

    [McpServerTool(Name = "desktop_type_text_injected", Title = "Type text (SendInput)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Type printable Unicode text into the focused control with SendInput (injected; any character; blocked by elevated windows). Use when desktop_type_text reports characters it could not type, or in a Remote Desktop session. Printable text only (keys: desktop_press_keys_injected). Stops if the foreground window changes." + Feedback)]
    public Task<CallToolResult> TypeTextInjected([Description("1-1000 printable characters.")] string text)
        => ToolGuard.Act("desktop_type_text_injected", FeedbackFocus.Keyboard, null, () => mouse.TypeText(text, InputKind.Injected),
            prepare: ToolGuard.Input(mouse, CancellationToken.None));
}
