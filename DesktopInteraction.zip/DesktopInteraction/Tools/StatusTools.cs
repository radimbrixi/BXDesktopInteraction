using System.ComponentModel;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Tools;

[McpServerToolType]
internal sealed class StatusTools(MouseController mouse)
{
    internal const string Late = " Also reports late changes: what changed in the area of the previous action's feedback since that result (lazy loading, late rendering).";

    [McpServerTool(Name = "desktop_status", Title = "Desktop status", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Read the input methods (device mouse attached or not, Remote Desktop session or not, which mouse tools to use), monitor layout, pointer position, emergency-stop and ownership state. Does not take control." + Late)]
    public CallToolResult Status() => ToolGuard.Read(() => mouse.Status());

    [McpServerTool(Name = "desktop_take_control", Title = "Take control", ReadOnly = false, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Take the interaction baton from another instance, pausing its in-flight input. Does not reset a session-wide emergency stop. Other input tools take the baton automatically; status and capture do not." + Late)]
    public CallToolResult TakeControl() => ToolGuard.Read(() => { mouse.TakeControl(); return mouse.Status(); });

    [McpServerTool(Name = "desktop_mouse_position", Title = "Mouse position", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Read the actual shared Windows pointer position in physical desktop pixels." + Late)]
    public CallToolResult MousePosition() => ToolGuard.Read(MouseController.Position);
}
