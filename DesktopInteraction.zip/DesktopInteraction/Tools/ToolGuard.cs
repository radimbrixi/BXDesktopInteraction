using System.Text.Json;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using ModelContextProtocol;
using ModelContextProtocol.Protocol;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Tools;

/// <summary>
/// Tool result helpers. Every tool result ends with the late-change section: what changed in the area of the
/// previous action's feedback since that result was returned (lazy loading, late rendering). Action tools also
/// return forced visual feedback for their own action, also on failure.
/// </summary>
internal static class ToolGuard
{
    internal static string Json(object value) => JsonSerializer.Serialize(value);

    internal static T Run<T>(Func<T> action)
    {
        try { return action(); }
        catch (McpException) { throw; }
        catch (Exception e) { throw new McpException(e.Message, e); }
    }

    /// <summary>Read-only tool: its JSON (or other blocks) plus the late-change section; keeps watching afterwards.</summary>
    internal static CallToolResult Read(Func<object> read) => Read(() => (IList<ContentBlock>)[new TextContentBlock { Text = Json(read()) }]);

    internal static CallToolResult Read(Func<IList<ContentBlock>> read)
    {
        var blocks = Run(read);
        var late = VisualFeedback.CollectLate(rebase: true);
        return new CallToolResult { Content = [.. blocks, .. late] };
    }

    /// <summary>
    /// Runs an action with forced visual feedback: text result (or error) followed by a PNG of what changed around
    /// the pointer or caret, then the late-change section about the previous action. Failed actions return isError
    /// with the same feedback, so the model always sees the screen.
    /// </summary>
    /// <param name="tool">Tool name, used to label later late-change reports.</param>
    /// <param name="expected">Where the pointer will end (move/drag target); null = where it is now.</param>
    /// <param name="prepare">Runs before the screen baseline is taken (waiting for the user to be idle, taking the baton); its failure is returned without feedback.</param>
    internal static async Task<CallToolResult> Act(string tool, FeedbackFocus focus, Point? expected, Func<Task<object>> action, VisualFeedback.FeedbackTiming? timing = null, Func<Task>? prepare = null)
    {
        if (await Prepare(prepare) is { } refused) return refused;
        var late = await Task.Run(() => VisualFeedback.CollectLate(rebase: false)); // look before this action changes the screen
        using var before = VisualFeedback.Begin(focus, expected);
        object result;
        bool failed = false;
        try { result = await action(); }
        catch (Exception e) { result = new { error = e.Message }; failed = true; }
        var content = await Task.Run(() => VisualFeedback.Complete(before, focus, result, tool, timing)); // waits until the screen has settled
        return new CallToolResult { Content = [.. content, .. late], IsError = failed };
    }

    internal static Task<CallToolResult> Act(string tool, FeedbackFocus focus, Point? expected, Func<object> action, VisualFeedback.FeedbackTiming? timing = null, Func<Task>? prepare = null)
        => Act(tool, focus, expected, () => Task.FromResult(action()), timing, prepare);

    /// <summary>Input request: waits for the user to be idle and takes the baton before the action (and its feedback baseline).</summary>
    internal static Func<Task> Input(MouseController mouse, CancellationToken cancellationToken) => () => mouse.BeginInput(cancellationToken);

    private static async Task<CallToolResult?> Prepare(Func<Task>? prepare)
    {
        if (prepare is null) return null;
        try { await prepare(); return null; }
        catch (Exception e) { return new CallToolResult { Content = [new TextContentBlock { Text = Json(new { error = e.Message, feedback = "skipped (no input sent)" }) }], IsError = true }; }
    }

    /// <summary>
    /// Quick action: no screen capture at all (no feedback, no late-change section); returns as soon as the input
    /// is sent. The baseline is dropped, so neither the previous action's nor this action's changes are reported later.
    /// </summary>
    internal static async Task<CallToolResult> Quick(Func<Task<object>> action, Func<Task>? prepare = null)
    {
        if (await Prepare(prepare) is { } refused) return refused;
        VisualFeedback.Forget();
        object result; bool failed = false;
        try { result = await action(); }
        catch (Exception e) { result = new { error = e.Message }; failed = true; }
        VisualFeedback.Forget();
        return new CallToolResult { Content = [new TextContentBlock { Text = Json(new { result, feedback = "skipped (quick action)" }) }], IsError = failed };
    }
}
