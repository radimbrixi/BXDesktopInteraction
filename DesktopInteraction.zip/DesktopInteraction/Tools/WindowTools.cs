using System.ComponentModel;
using System.Text;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;
using static Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Tools.ToolGuard;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Tools;

[McpServerToolType]
internal sealed class WindowTools(MouseController mouse)
{
    [McpServerTool(Name = "desktop_list_windows", Title = "List windows", ReadOnly = true, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("List visible top-level windows with their handle and title. Does not take control." + StatusTools.Late)]
    public CallToolResult ListWindows() => ToolGuard.Read(() =>
    {
        var windows = new List<object>();
        Native.EnumWindows((hWnd, _) =>
        {
            var title = Title(hWnd);
            if (Native.IsWindowVisible(hWnd) && !string.IsNullOrWhiteSpace(title))
                windows.Add(new { handle = $"0x{hWnd:X}", title });
            return true;
        }, 0);
        return (object)windows;
    });

    [McpServerTool(Name = "desktop_focus_window", Title = "Focus window", ReadOnly = false, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Restore and bring to the foreground the first visible window whose title contains the given text (case-insensitive)." + KeyboardTools.Feedback)]
    public Task<CallToolResult> FocusWindow([Description("Part of the window title.")] string titlePart) => ToolGuard.Act("desktop_focus_window", FeedbackFocus.Keyboard, null, () =>
    {
        if (string.IsNullOrWhiteSpace(titlePart)) throw new ArgumentException("titlePart must not be empty.");
        nint found = 0;
        Native.EnumWindows((hWnd, _) =>
        {
            if (Native.IsWindowVisible(hWnd) && Title(hWnd).Contains(titlePart, StringComparison.OrdinalIgnoreCase)) { found = hWnd; return false; }
            return true;
        }, 0);
        if (found == 0) throw new ArgumentException($"No visible window with title containing '{titlePart}'.");

        bool focused = false;
        mouse.Execute(() => { Native.ShowWindow(found, 9 /* SW_RESTORE */); focused = Native.SetForegroundWindow(found); });
        return (object)new { handle = $"0x{found:X}", title = Title(found), focused };
    }, prepare: ToolGuard.Input(mouse, CancellationToken.None));

    private static string Title(nint hWnd)
    {
        int length = Native.GetWindowTextLength(hWnd);
        if (length == 0) return string.Empty;
        var builder = new StringBuilder(length + 1);
        Native.GetWindowText(hWnd, builder, builder.Capacity);
        return builder.ToString();
    }
}
