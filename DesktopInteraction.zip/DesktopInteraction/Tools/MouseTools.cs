using System.ComponentModel;
using Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;
using ModelContextProtocol.Protocol;
using ModelContextProtocol.Server;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Tools;

/// <summary>Mouse tools with device input (virtual USB mouse or ExtedoVirtualMouse driver). Each returns visual feedback.</summary>
[McpServerToolType]
internal sealed class MouseTools(MouseController mouse)
{
    internal const string Feedback = " Returns visual feedback: a PNG of what changed around the pointer (limit: the window under it, or 100x100 px outside a known window)." + StatusTools.Late;

    [McpServerTool(Name = "desktop_mouse_move", Title = "Move mouse (device)", ReadOnly = false, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Move the pointer with the virtual USB mouse (real device input, like a hand on a mouse). Use on a normal desktop or VM console. Fails if the virtual mouse is not attached or in a Remote Desktop session; then use desktop_mouse_move_injected. Human-like path by default." + Feedback)]
    public Task<CallToolResult> Move(
        [Description("Target X in physical desktop pixels (origin can be negative on multi-monitor setups).")] int x,
        [Description("Target Y in physical desktop pixels.")] int y,
        [Description("Movement duration 0-10000 ms; -1 (default) = human-like duration based on distance.")] int durationMs = -1,
        CancellationToken cancellationToken = default)
        => MouseActions.Move(mouse, InputKind.Device, x, y, durationMs < 0 ? null : durationMs, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_click", Title = "Click (device)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Click at the current pointer position with the virtual USB mouse. count=2 performs a double click. Waits up to 0.5 s for a reaction; for slow reactions (lazy loading) use the _lazy click, to skip feedback the _quick click." + Feedback)]
    public Task<CallToolResult> Click(
        [Description(MouseActions.ButtonDescription)] string button = "left",
        [Description("1 for a single click, 2 for a double click.")] int count = 1,
        CancellationToken cancellationToken = default)
        => MouseActions.Click(mouse, InputKind.Device, button, count, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_click_quick", Title = "Quick click (device)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Click at the current pointer position with the virtual USB mouse and return at once, without visual feedback of the click. No screen capture at all, also no late-change report. Use for clicks whose effect you do not need to see (or will capture later).")]
    public Task<CallToolResult> ClickQuick(
        [Description(MouseActions.ButtonDescription)] string button = "left",
        [Description("1 for a single click, 2 for a double click.")] int count = 1,
        CancellationToken cancellationToken = default)
        => MouseActions.ClickQuick(mouse, InputKind.Device, button, count, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_click_lazy", Title = "Click and wait for lazy load (device)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Click with the virtual USB mouse when the reaction takes time (lazy loading, progress bar, slow dialog): waits up to waitMs for the screen to react, then until it has been quiet for 1 s (at most 9 s after the first change), and returns that final state as visual feedback." + MouseActions.LazyFeedback)]
    public Task<CallToolResult> ClickLazy(
        [Description(MouseActions.ButtonDescription)] string button = "left",
        [Description("1 for a single click, 2 for a double click.")] int count = 1,
        [Description("How long to wait for the first reaction, 500-60000 ms (default 9000).")] int waitMs = 9000,
        CancellationToken cancellationToken = default)
        => MouseActions.ClickLazy(mouse, InputKind.Device, button, count, waitMs, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_button", Title = "Press/release button (device)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Press or release a button of the virtual USB mouse for multi-step drags. Always release after down." + Feedback)]
    public Task<CallToolResult> Button(
        [Description("down or up.")] string action,
        [Description(MouseActions.ButtonDescription)] string button = "left")
        => MouseActions.Button(mouse, InputKind.Device, action, button);

    [McpServerTool(Name = "desktop_mouse_drag", Title = "Drag (device)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Drag with the virtual USB mouse: move to start, hold, move to destination, release (also on cancellation). A drop completes only if the target application accepts it." + Feedback)]
    public Task<CallToolResult> Drag(
        [Description("Start X in physical desktop pixels.")] int fromX,
        [Description("Start Y in physical desktop pixels.")] int fromY,
        [Description("Destination X in physical desktop pixels.")] int toX,
        [Description("Destination Y in physical desktop pixels.")] int toY,
        [Description("Drag movement duration 0-10000 ms; -1 (default) = human-like duration.")] int durationMs = -1,
        [Description(MouseActions.ButtonDescription)] string button = "left",
        CancellationToken cancellationToken = default)
        => MouseActions.Drag(mouse, InputKind.Device, fromX, fromY, toX, toY, durationMs < 0 ? null : durationMs, button, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_scroll", Title = "Scroll (device)", ReadOnly = false, Destructive = false, Idempotent = false, OpenWorld = false)]
    [Description("Scroll with the virtual USB mouse wheel at the pointer: multiples of 120 (one notch); positive vertical is up, positive horizontal is right." + Feedback)]
    public Task<CallToolResult> Scroll(
        [Description("Wheel delta -12000..12000, a multiple of 120.")] int delta,
        [Description("vertical or horizontal.")] string axis = "vertical")
        => MouseActions.Scroll(mouse, InputKind.Device, delta, axis);

    [McpServerTool(Name = "desktop_release_buttons", Title = "Release buttons", ReadOnly = false, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Release all mouse buttons held by this server, device and injected. Does not take control." + Feedback)]
    public Task<CallToolResult> ReleaseButtons()
        => ToolGuard.Act("desktop_release_buttons", FeedbackFocus.Pointer, null, () => { mouse.ReleaseAll(); return new { released = true, cursor = MouseController.Position() }; });
}

/// <summary>The same mouse tools with SendInput (injected input, no driver). Each returns visual feedback.</summary>
[McpServerToolType]
internal sealed class InjectedMouseTools(MouseController mouse)
{
    [McpServerTool(Name = "desktop_mouse_move_injected", Title = "Move mouse (injected)", ReadOnly = false, Destructive = false, Idempotent = true, OpenWorld = false)]
    [Description("Move the pointer with Windows SendInput (software input, marked as injected). Use in Remote Desktop sessions or when the virtual USB mouse is unavailable. Human-like path by default." + MouseTools.Feedback)]
    public Task<CallToolResult> Move(
        [Description("Target X in physical desktop pixels (origin can be negative on multi-monitor setups).")] int x,
        [Description("Target Y in physical desktop pixels.")] int y,
        [Description("Movement duration 0-10000 ms; -1 (default) = human-like duration based on distance.")] int durationMs = -1,
        CancellationToken cancellationToken = default)
        => MouseActions.Move(mouse, InputKind.Injected, x, y, durationMs < 0 ? null : durationMs, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_click_injected", Title = "Click (injected)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Click at the current pointer position with SendInput. count=2 performs a double click. Waits up to 0.5 s for a reaction; for slow reactions (lazy loading) use the _lazy click, to skip feedback the _quick click." + MouseTools.Feedback)]
    public Task<CallToolResult> Click(
        [Description(MouseActions.ButtonDescription)] string button = "left",
        [Description("1 for a single click, 2 for a double click.")] int count = 1,
        CancellationToken cancellationToken = default)
        => MouseActions.Click(mouse, InputKind.Injected, button, count, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_click_quick_injected", Title = "Quick click (injected)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Click at the current pointer position with SendInput and return at once, without visual feedback of the click. No screen capture at all, also no late-change report. Use for clicks whose effect you do not need to see (or will capture later).")]
    public Task<CallToolResult> ClickQuick(
        [Description(MouseActions.ButtonDescription)] string button = "left",
        [Description("1 for a single click, 2 for a double click.")] int count = 1,
        CancellationToken cancellationToken = default)
        => MouseActions.ClickQuick(mouse, InputKind.Injected, button, count, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_click_lazy_injected", Title = "Click and wait for lazy load (injected)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Click with SendInput when the reaction takes time (lazy loading, progress bar, slow dialog): waits up to waitMs for the screen to react, then until it has been quiet for 1 s (at most 9 s after the first change), and returns that final state as visual feedback." + MouseActions.LazyFeedback)]
    public Task<CallToolResult> ClickLazy(
        [Description(MouseActions.ButtonDescription)] string button = "left",
        [Description("1 for a single click, 2 for a double click.")] int count = 1,
        [Description("How long to wait for the first reaction, 500-60000 ms (default 9000).")] int waitMs = 9000,
        CancellationToken cancellationToken = default)
        => MouseActions.ClickLazy(mouse, InputKind.Injected, button, count, waitMs, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_button_injected", Title = "Press/release button (injected)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Press or release a mouse button with SendInput for multi-step drags. Always release after down." + MouseTools.Feedback)]
    public Task<CallToolResult> Button(
        [Description("down or up.")] string action,
        [Description(MouseActions.ButtonDescription)] string button = "left")
        => MouseActions.Button(mouse, InputKind.Injected, action, button);

    [McpServerTool(Name = "desktop_mouse_drag_injected", Title = "Drag (injected)", ReadOnly = false, Destructive = true, Idempotent = false, OpenWorld = false)]
    [Description("Drag with SendInput: move to start, hold, move to destination, release (also on cancellation). A drop completes only if the target application accepts it." + MouseTools.Feedback)]
    public Task<CallToolResult> Drag(
        [Description("Start X in physical desktop pixels.")] int fromX,
        [Description("Start Y in physical desktop pixels.")] int fromY,
        [Description("Destination X in physical desktop pixels.")] int toX,
        [Description("Destination Y in physical desktop pixels.")] int toY,
        [Description("Drag movement duration 0-10000 ms; -1 (default) = human-like duration.")] int durationMs = -1,
        [Description(MouseActions.ButtonDescription)] string button = "left",
        CancellationToken cancellationToken = default)
        => MouseActions.Drag(mouse, InputKind.Injected, fromX, fromY, toX, toY, durationMs < 0 ? null : durationMs, button, cancellationToken);

    [McpServerTool(Name = "desktop_mouse_scroll_injected", Title = "Scroll (injected)", ReadOnly = false, Destructive = false, Idempotent = false, OpenWorld = false)]
    [Description("Scroll with SendInput at the pointer: 120 units per notch (any value allowed); positive vertical is up, positive horizontal is right." + MouseTools.Feedback)]
    public Task<CallToolResult> Scroll(
        [Description("Wheel delta -12000..12000 (120 per notch).")] int delta,
        [Description("vertical or horizontal.")] string axis = "vertical")
        => MouseActions.Scroll(mouse, InputKind.Injected, delta, axis);
}

/// <summary>Shared implementation of both mouse tool sets.</summary>
internal static class MouseActions
{
    internal const string ButtonDescription = "left, right, middle, x1 or x2.";
    internal const string LazyFeedback = " Feedback: what changed around the pointer (limit: the window under it, or 100x100 px outside a known window)." + StatusTools.Late;

    internal static Task<CallToolResult> ClickQuick(MouseController mouse, InputKind kind, string button, int count, CancellationToken ct)
        => ToolGuard.Quick(async () =>
        {
            await mouse.Click(kind, button, count, ct);
            return Result(kind);
        }, ToolGuard.Input(mouse, ct));

    internal static Task<CallToolResult> ClickLazy(MouseController mouse, InputKind kind, string button, int count, int waitMs, CancellationToken ct)
    {
        if (waitMs is < 500 or > 60000) waitMs = Math.Clamp(waitMs, 500, 60000);
        return ToolGuard.Act(Name("click_lazy", kind), FeedbackFocus.Pointer, null, async () =>
        {
            await mouse.Click(kind, button, count, ct);
            return new { input = kind == InputKind.Device ? "device" : "injected", waitMs, cursor = MouseController.Position() };
        }, VisualFeedback.FeedbackTiming.Lazy(waitMs), ToolGuard.Input(mouse, ct));
    }

    internal static string NameOf(string action, InputKind kind) => Name(action, kind);

    private static string Name(string action, InputKind kind) => $"desktop_mouse_{action}{(kind == InputKind.Device ? "" : "_injected")}";

    private static object Result(InputKind kind) => new { input = kind == InputKind.Device ? "device" : "injected", cursor = MouseController.Position() };

    internal static Task<CallToolResult> Move(MouseController mouse, InputKind kind, int x, int y, int? durationMs, CancellationToken ct)
        => ToolGuard.Act(Name("move", kind), FeedbackFocus.Pointer, new Point(x, y), async () =>
        {
            await mouse.Move(kind, x, y, durationMs, ct);
            return Result(kind);
        }, prepare: ToolGuard.Input(mouse, ct));

    internal static Task<CallToolResult> Click(MouseController mouse, InputKind kind, string button, int count, CancellationToken ct)
        => ToolGuard.Act(Name("click", kind), FeedbackFocus.Pointer, null, async () =>
        {
            await mouse.Click(kind, button, count, ct);
            return Result(kind);
        }, prepare: ToolGuard.Input(mouse, ct));

    internal static Task<CallToolResult> Button(MouseController mouse, InputKind kind, string action, string button)
        => ToolGuard.Act(Name("button", kind), FeedbackFocus.Pointer, null, () =>
        {
            if (action is not ("down" or "up")) throw new ArgumentException("action must be down or up.");
            mouse.Button(kind, button, action == "down");
            return new { action, input = kind == InputKind.Device ? "device" : "injected", cursor = MouseController.Position() };
        }, prepare: action == "up" ? null : ToolGuard.Input(mouse, CancellationToken.None));

    internal static Task<CallToolResult> Drag(MouseController mouse, InputKind kind, int fromX, int fromY, int toX, int toY, int? durationMs, string button, CancellationToken ct)
        => ToolGuard.Act(Name("drag", kind), FeedbackFocus.Pointer, new Point(toX, toY), async () =>
        {
            await mouse.Drag(kind, fromX, fromY, toX, toY, durationMs, button, ct);
            return Result(kind);
        }, prepare: ToolGuard.Input(mouse, ct));

    internal static Task<CallToolResult> Scroll(MouseController mouse, InputKind kind, int delta, string axis)
        => ToolGuard.Act(Name("scroll", kind), FeedbackFocus.Pointer, null, () =>
        {
            if (axis is not ("vertical" or "horizontal")) throw new ArgumentException("axis must be vertical or horizontal.");
            mouse.Scroll(kind, delta, axis == "horizontal");
            return Result(kind);
        }, prepare: ToolGuard.Input(mouse, CancellationToken.None));
}
