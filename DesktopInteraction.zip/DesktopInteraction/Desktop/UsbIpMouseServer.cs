using System.Buffers.Binary;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Minimal USB/IP device server (protocol 1.1.1, as the Linux usbip host driver) exporting one
/// <see cref="UsbIpMouseDevice"/> on 127.0.0.1. A USB/IP client - usbip-win2 on Windows - imports it and
/// Windows then sees a real USB mouse. Loopback only; one importer at a time. All headers are big-endian.
/// </summary>
internal sealed class UsbIpMouseServer : IDisposable
{
    internal const string BusId = "1-1";
    internal const int DefaultPort = 3240;
    private const ushort ProtocolVersion = 0x0111;
    private const ushort OpReqDevList = 0x8005, OpRepDevList = 0x0005, OpReqImport = 0x8003, OpRepImport = 0x0003;
    private const uint CmdSubmit = 1, CmdUnlink = 2, RetSubmit = 3, RetUnlink = 4;
    private const int StatusUnlinked = -104; // -ECONNRESET
    private const int MaxQueuedReports = 1024;

    private readonly TcpListener listener;
    private readonly CancellationTokenSource stop = new();
    private readonly object gate = new();
    private readonly Queue<(uint Seq, int Length, int Packets)> pendingIn = new();
    private readonly Queue<byte[]> reports = new();
    private Stream? importer;
    private int configuration;
    private byte[] currentReport = [1, 0, 0, 0, 0, 0, 0, 0];

    internal UsbIpMouseServer(int port)
    {
        listener = new TcpListener(IPAddress.Loopback, port);
        listener.Server.ExclusiveAddressUse = true;
        listener.Start();
        Port = ((IPEndPoint)listener.LocalEndpoint).Port;
        _ = Task.Run(AcceptLoop);
    }

    internal int Port { get; }

    internal long DeliveredReports { get; private set; }

    internal int Imports { get; private set; }

    internal bool Imported { get { lock (gate) return importer is not null; } }

    /// <summary>Imported and configured by the host: reports can be delivered.</summary>
    internal bool Ready { get { lock (gate) return importer is not null && configuration != 0; } }

    internal bool WaitReady(TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;
        lock (gate)
        {
            while (importer is null || configuration == 0)
            {
                var left = deadline - DateTime.UtcNow;
                if (left <= TimeSpan.Zero || !Monitor.Wait(gate, left)) return importer is not null && configuration != 0;
            }
            return true;
        }
    }

    /// <summary>Queues one input report for the interrupt endpoint (delivered in order, at the host's polling rate).</summary>
    internal void Send(byte[] report)
    {
        lock (gate)
        {
            if (importer is null || configuration == 0) throw new InvalidOperationException("The USB/IP virtual mouse is not attached.");
            if (reports.Count >= MaxQueuedReports) throw new InvalidOperationException("The USB/IP host stopped polling the virtual mouse.");
            reports.Enqueue(report);
            currentReport = report;
            DeliverLocked();
        }
    }

    private async Task AcceptLoop()
    {
        while (!stop.IsCancellationRequested)
        {
            TcpClient client;
            try { client = await listener.AcceptTcpClientAsync(stop.Token); }
            catch { return; }
            client.NoDelay = true;
            _ = Task.Run(() => Serve(client));
        }
    }

    private void Serve(TcpClient client)
    {
        using var _ = client;
        using var stream = client.GetStream();
        using var registration = stop.Token.Register(client.Close);
        bool imported = false;
        try
        {
            var header = new byte[8];
            stream.ReadExactly(header);
            ushort code = BinaryPrimitives.ReadUInt16BigEndian(header.AsSpan(2));
            if (code == OpReqDevList)
            {
                var device = UsbIpMouseDevice.UsbIpDeviceRecord(BusId);
                var reply = new byte[8 + 4 + device.Length + 4];
                WriteOpHeader(reply, OpRepDevList, 0);
                BinaryPrimitives.WriteUInt32BigEndian(reply.AsSpan(8), 1);
                device.CopyTo(reply, 12);
                reply[12 + device.Length] = 3; // interface: HID, subclass 0, protocol 0
                stream.Write(reply);
                return;
            }
            if (code != OpReqImport) return;

            var busId = new byte[32];
            stream.ReadExactly(busId);
            bool accept = Encoding.ASCII.GetString(busId).TrimEnd('\0') == BusId;
            lock (gate)
            {
                accept &= importer is null;
                if (accept) { importer = stream; imported = true; configuration = 0; pendingIn.Clear(); reports.Clear(); Imports++; }
            }
            if (!accept) { var busy = new byte[8]; WriteOpHeader(busy, OpRepImport, 1); stream.Write(busy); return; }

            var import = new byte[8 + 312];
            WriteOpHeader(import, OpRepImport, 0);
            UsbIpMouseDevice.UsbIpDeviceRecord(BusId).CopyTo(import, 8);
            lock (gate) stream.Write(import);
            UrbLoop(stream);
        }
        catch (Exception) when (stop.IsCancellationRequested || client is { Connected: false }) { }
        catch (IOException) { }
        catch (InvalidDataException) { }
        finally
        {
            if (imported)
                lock (gate)
                {
                    importer = null; configuration = 0; pendingIn.Clear(); reports.Clear();
                    Monitor.PulseAll(gate);
                }
        }
    }

    private void UrbLoop(Stream stream)
    {
        var header = new byte[48];
        while (true)
        {
            stream.ReadExactly(header);
            var h = header.AsSpan();
            uint command = U32(h), seq = U32(h[4..]), direction = U32(h[12..]), endpoint = U32(h[16..]);
            if (command == CmdUnlink)
            {
                uint target = U32(h[20..]);
                lock (gate)
                {
                    int before = pendingIn.Count;
                    var keep = pendingIn.Where(u => u.Seq != target).ToList();
                    pendingIn.Clear();
                    foreach (var u in keep) pendingIn.Enqueue(u);
                    WriteHeader(stream, RetUnlink, seq, keep.Count < before ? StatusUnlinked : 0, 0, 0, []);
                }
                continue;
            }
            if (command != CmdSubmit) throw new InvalidDataException($"Unexpected USB/IP command {command}.");

            int length = (int)U32(h[24..]);
            int packets = (int)U32(h[32..]);
            if (length is < 0 or > 1 << 20) throw new InvalidDataException("Invalid transfer length.");
            var outData = direction == 0 && length > 0 ? new byte[length] : [];
            stream.ReadExactly(outData);
            if (packets > 0) { stream.ReadExactly(new byte[16 * packets]); Reply(stream, seq, UsbIpMouseDevice.StatusStall, packets, []); continue; }

            if (endpoint == 0)
            {
                int status; byte[] data;
                lock (gate)
                {
                    int before = configuration;
                    (status, data) = UsbIpMouseDevice.Control(h[40..48], ref configuration, currentReport);
                    if (configuration != before) Monitor.PulseAll(gate);
                }
                if (direction == 0) Reply(stream, seq, status, packets, [], status == 0 ? outData.Length : 0);
                else Reply(stream, seq, status, packets, data);
            }
            else if (endpoint == 1 && direction == 1)
            {
                lock (gate) { pendingIn.Enqueue((seq, length, packets)); DeliverLocked(); }
            }
            else Reply(stream, seq, UsbIpMouseDevice.StatusStall, packets, []);
        }
    }

    private void DeliverLocked()
    {
        if (importer is null) return;
        while (pendingIn.Count > 0 && reports.Count > 0)
        {
            var urb = pendingIn.Dequeue();
            var report = reports.Dequeue();
            try { WriteHeader(importer, RetSubmit, urb.Seq, 0, urb.Packets, 0, report.Length > urb.Length ? report[..urb.Length] : report); }
            catch (IOException e) { throw new InvalidOperationException("The USB/IP connection to the virtual mouse was lost.", e); }
            DeliveredReports++;
        }
    }

    private void Reply(Stream stream, uint seq, int status, int packets, byte[] data, int outLength = 0)
    {
        lock (gate) WriteHeader(stream, RetSubmit, seq, status, packets, outLength, data);
    }

    /// <summary>RET_SUBMIT / RET_UNLINK: 48-byte header (devid, direction, ep = 0) followed by IN data.</summary>
    private static void WriteHeader(Stream stream, uint command, uint seq, int status, int packets, int outLength, byte[] data)
    {
        var buffer = new byte[48 + (command == RetSubmit ? data.Length : 0)];
        var s = buffer.AsSpan();
        BinaryPrimitives.WriteUInt32BigEndian(s, command);
        BinaryPrimitives.WriteUInt32BigEndian(s[4..], seq);
        BinaryPrimitives.WriteInt32BigEndian(s[20..], status);
        if (command == RetSubmit)
        {
            BinaryPrimitives.WriteInt32BigEndian(s[24..], data.Length > 0 ? data.Length : outLength); // actual_length
            BinaryPrimitives.WriteInt32BigEndian(s[32..], packets);                                    // number_of_packets (echoed)
            data.CopyTo(buffer, 48);
        }
        stream.Write(buffer);
    }

    private static void WriteOpHeader(byte[] buffer, ushort code, uint status)
    {
        BinaryPrimitives.WriteUInt16BigEndian(buffer, ProtocolVersion);
        BinaryPrimitives.WriteUInt16BigEndian(buffer.AsSpan(2), code);
        BinaryPrimitives.WriteUInt32BigEndian(buffer.AsSpan(4), status);
    }

    private static uint U32(ReadOnlySpan<byte> s) => BinaryPrimitives.ReadUInt32BigEndian(s);

    public void Dispose()
    {
        stop.Cancel();
        listener.Stop();
        lock (gate) Monitor.PulseAll(gate);
    }
}
