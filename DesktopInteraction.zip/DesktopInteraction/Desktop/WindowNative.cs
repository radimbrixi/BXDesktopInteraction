using System.Runtime.InteropServices;
using System.Text;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>Window geometry and session queries used by visual feedback and input selection.</summary>
internal static class WindowNative
{
    [StructLayout(LayoutKind.Sequential)]
    internal struct Rect { public int Left, Top, Right, Bottom; }

    [DllImport("user32.dll")] internal static extern int GetSystemMetrics(int index);
    [DllImport("user32.dll")] internal static extern bool GetWindowRect(nint hWnd, out Rect rect);
    [DllImport("user32.dll")] internal static extern bool IsIconic(nint hWnd);
    [DllImport("user32.dll")] internal static extern uint GetWindowThreadProcessId(nint hWnd, out uint processId);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetClassName(nint hWnd, StringBuilder name, int max);
    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")] private static extern nint GetWindowLongPtr(nint hWnd, int index);
    [DllImport("dwmapi.dll")] private static extern int DwmGetWindowAttribute(nint hWnd, int attribute, out Rect value, int size);
    [DllImport("dwmapi.dll")] private static extern int DwmGetWindowAttribute(nint hWnd, int attribute, out int value, int size);

    /// <summary>SM_REMOTESESSION: this process runs in a Remote Desktop session.</summary>
    internal static bool IsRemoteSession => GetSystemMetrics(0x1000) != 0;

    internal static string ClassName(nint hWnd)
    {
        var name = new StringBuilder(256);
        return GetClassName(hWnd, name, name.Capacity) > 0 ? name.ToString() : "";
    }

    /// <summary>Visible frame in physical pixels (DWM extended frame bounds; window rect as fallback).</summary>
    internal static Rectangle Bounds(nint hWnd)
    {
        if (DwmGetWindowAttribute(hWnd, 9 /* DWMWA_EXTENDED_FRAME_BOUNDS */, out Rect r, Marshal.SizeOf<Rect>()) != 0 && !GetWindowRect(hWnd, out r))
            return Rectangle.Empty;
        return Rectangle.FromLTRB(r.Left, r.Top, r.Right, r.Bottom);
    }

    internal static bool IsCloaked(nint hWnd) => DwmGetWindowAttribute(hWnd, 14 /* DWMWA_CLOAKED */, out int cloaked, sizeof(int)) == 0 && cloaked != 0;

    /// <summary>WS_EX_TRANSPARENT: click-through overlay (for example the cursor marker), not a real target.</summary>
    internal static bool IsClickThrough(nint hWnd) => (GetWindowLongPtr(hWnd, -20 /* GWL_EXSTYLE */) & 0x20) != 0;

    internal static string ProcessName(nint hWnd)
    {
        GetWindowThreadProcessId(hWnd, out uint pid);
        try { using var process = System.Diagnostics.Process.GetProcessById((int)pid); return process.ProcessName; }
        catch { return ""; }
    }

    internal static uint ProcessId(nint hWnd) { GetWindowThreadProcessId(hWnd, out uint pid); return pid; }

    [StructLayout(LayoutKind.Sequential)]
    private struct GuiThreadInfo
    {
        public int Size, Flags;
        public nint Active, Focus, Capture, MenuOwner, MoveSize, Caret;
        public Rect CaretRect;
    }

    [DllImport("user32.dll")] private static extern bool GetGUIThreadInfo(uint threadId, ref GuiThreadInfo info);
    [DllImport("user32.dll")] private static extern bool ClientToScreen(nint hWnd, ref Point point);

    /// <summary>
    /// Screen position (centre) of the system text caret of the foreground thread, or null when the application
    /// does not use the Win32 caret (many browsers, WPF and custom-drawn controls).
    /// </summary>
    internal static Point? CaretPosition(nint foreground) =>
        CaretRect(foreground) is { } r ? new Point(r.X + r.Width / 2, r.Y + r.Height / 2) : null;

    /// <summary>Screen rectangle of the Win32 text caret of the foreground thread, or null without one.</summary>
    internal static Rectangle? CaretRect(nint foreground)
    {
        if (foreground == 0) return null;
        var info = new GuiThreadInfo { Size = Marshal.SizeOf<GuiThreadInfo>() };
        uint thread = GetWindowThreadProcessId(foreground, out _);
        if (thread == 0 || !GetGUIThreadInfo(thread, ref info) || info.Caret == 0) return null;
        var topLeft = new Point(info.CaretRect.Left, info.CaretRect.Top);
        if (!ClientToScreen(info.Caret, ref topLeft)) return null;
        return new Rectangle(topLeft, new Size(Math.Max(1, info.CaretRect.Right - info.CaretRect.Left), Math.Max(1, info.CaretRect.Bottom - info.CaretRect.Top)));
    }
}
