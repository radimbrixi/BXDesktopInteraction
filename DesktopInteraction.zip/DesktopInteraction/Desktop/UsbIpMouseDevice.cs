using System.Buffers.Binary;
using System.Text;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// The emulated USB device: full-speed, one HID interface with three collections on interrupt IN endpoint 0x81
/// (1 ms polling): the absolute pointer of the ExtedoVirtualMouse driver (report ID 1), a relative mouse
/// (report ID 2) and a keyboard (report ID 3: modifiers + 6 keys), 8 bytes each. Real keyboard input is not
/// subject to UIPI, so typing reaches elevated windows (admin PowerShell), VM windows and other raw-input consumers.
/// Windows binds its in-box drivers (usbccgp/hidusb/mouhid). VID 0x1209 PID 0x0001 is the pid.codes test ID
/// reserved for private testing.
/// </summary>
internal static class UsbIpMouseDevice
{
    internal const ushort VendorId = 0x1209, ProductId = 0x0001, BcdDevice = 0x0200; // 2.00: keyboard collection added (new descriptor, re-enumerated)
    internal const int StatusOk = 0, StatusStall = -32 /* -EPIPE */;

    internal static readonly byte[] ReportDescriptor =
    [
        0x05, 0x01, 0x09, 0x02, 0xA1, 0x01,             // Generic Desktop / Mouse / Collection (Application)
        0x85, 0x01,                                     //   Report ID (1)
        0x09, 0x01, 0xA1, 0x00,                         //   Pointer / Collection (Physical)
        0x05, 0x09, 0x19, 0x01, 0x29, 0x05,             //     Buttons 1..5
        0x15, 0x00, 0x25, 0x01, 0x95, 0x05, 0x75, 0x01, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x03, 0x81, 0x03,             //     3 bits padding
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31,             //     X, Y absolute 0..32767
        0x15, 0x00, 0x26, 0xFF, 0x7F, 0x35, 0x00, 0x46, 0xFF, 0x7F,
        0x75, 0x10, 0x95, 0x02, 0x81, 0x02,
        0x35, 0x00, 0x45, 0x00,
        0x09, 0x38, 0x15, 0x81, 0x25, 0x7F,             //     Wheel -127..127 relative
        0x75, 0x08, 0x95, 0x01, 0x81, 0x06,
        0x05, 0x0C, 0x0A, 0x38, 0x02,                   //     Consumer / AC Pan relative
        0x95, 0x01, 0x81, 0x06,
        0xC0, 0xC0,

        // Relative mouse (report ID 2): other monitors, and all buttons/wheel (see AbsoluteHidBackend)
        0x05, 0x01, 0x09, 0x02, 0xA1, 0x01,             // Generic Desktop / Mouse / Collection (Application)
        0x85, 0x02,                                     //   Report ID (2)
        0x09, 0x01, 0xA1, 0x00,                         //   Pointer / Collection (Physical)
        0x05, 0x09, 0x19, 0x01, 0x29, 0x05,             //     Buttons 1..5
        0x15, 0x00, 0x25, 0x01, 0x95, 0x05, 0x75, 0x01, 0x81, 0x02,
        0x95, 0x01, 0x75, 0x03, 0x81, 0x03,             //     3 bits padding
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31,             //     X, Y relative -32767..32767
        0x16, 0x01, 0x80, 0x26, 0xFF, 0x7F,
        0x75, 0x10, 0x95, 0x02, 0x81, 0x06,
        0x09, 0x38, 0x15, 0x81, 0x25, 0x7F,             //     Wheel -127..127 relative
        0x75, 0x08, 0x95, 0x01, 0x81, 0x06,
        0x05, 0x0C, 0x0A, 0x38, 0x02,                   //     Consumer / AC Pan relative
        0x95, 0x01, 0x81, 0x06,
        0xC0, 0xC0,

        // Keyboard (report ID 3): 8 modifier bits (LCtrl LShift LAlt LGui RCtrl RShift RAlt RGui) + 6-key array
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01,             // Generic Desktop / Keyboard / Collection (Application)
        0x85, 0x03,                                     //   Report ID (3)
        0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7,             //   Keyboard usages E0..E7 (modifiers)
        0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
        0x05, 0x07, 0x19, 0x00, 0x2A, 0xFF, 0x00,       //   Keyboard usages 0..255 (key array)
        0x15, 0x00, 0x26, 0xFF, 0x00, 0x75, 0x08, 0x95, 0x06, 0x81, 0x00,
        0xC0,
    ];

    internal static readonly byte[] DeviceDescriptor =
    [
        18, 1, 0x00, 0x02,                              // bcdUSB 2.00
        0, 0, 0, 64,                                    // class per interface, EP0 64 bytes
        VendorId & 0xFF, VendorId >> 8, ProductId & 0xFF, ProductId >> 8,
        BcdDevice & 0xFF, BcdDevice >> 8,
        1, 2, 3,                                        // manufacturer, product, serial strings
        1,                                              // one configuration
    ];

    internal static readonly byte[] HidDescriptor =
        [9, 0x21, 0x11, 0x01, 0, 1, 0x22, (byte)ReportDescriptor.Length, (byte)(ReportDescriptor.Length >> 8)];

    internal static readonly byte[] ConfigurationDescriptor =
    [
        9, 2, 34, 0, 1, 1, 0, 0xA0, 50,                 // 34 bytes total, 1 interface, value 1, bus powered, 100 mA
        9, 4, 0, 0, 1, 3, 0, 0, 0,                      // interface 0, 1 endpoint, HID, no boot protocol
        .. HidDescriptor,
        7, 5, 0x81, 3, 8, 0, 1,                         // EP1 IN interrupt, 8 bytes, every 1 ms
    ];

    private static readonly string[] Strings = ["", "Extedo", "Extedo Virtual Mouse and Keyboard (USB/IP)", "EXTEDO-USBIP-0001"];

    /// <summary>
    /// Handles one control transfer on endpoint 0. <paramref name="configuration"/> tracks SET_CONFIGURATION;
    /// <paramref name="currentReport"/> answers HID GET_REPORT. Unsupported requests stall.
    /// </summary>
    internal static (int Status, byte[] Data) Control(ReadOnlySpan<byte> setup, ref int configuration, byte[] currentReport)
    {
        byte type = setup[0], request = setup[1];
        ushort value = BinaryPrimitives.ReadUInt16LittleEndian(setup[2..]);
        ushort length = BinaryPrimitives.ReadUInt16LittleEndian(setup[6..]);
        byte[]? data = (type, request) switch
        {
            (0x80, 6) => (value >> 8) switch
            {
                1 => DeviceDescriptor,
                2 => ConfigurationDescriptor,
                3 => StringDescriptor(value & 0xFF),
                _ => null,                              // device qualifier, BOS, other speed: not a high-speed device
            },
            (0x81, 6) => (value >> 8) switch { 0x21 => HidDescriptor, 0x22 => ReportDescriptor, _ => null },
            (0x00, 9) when (value & 0xFF) is 0 or 1 => SetConfiguration(ref configuration, value & 0xFF),
            (0x80, 8) => [(byte)configuration],
            (0x01, 11) when value == 0 => [],           // SET_INTERFACE alternate 0
            (0x81, 10) => [0],                          // GET_INTERFACE
            (0x80 or 0x81 or 0x82, 0) => [0, 0],        // GET_STATUS
            (0x00 or 0x01 or 0x02, 1 or 3) => [],       // CLEAR/SET_FEATURE (remote wakeup, endpoint halt)
            (0x21, 0x0A or 0x0B or 0x09) => [],         // HID SET_IDLE, SET_PROTOCOL, SET_REPORT
            (0xA1, 1) => currentReport,                 // HID GET_REPORT
            (0xA1, 2) => [0],                           // HID GET_IDLE
            (0xA1, 3) => [1],                           // HID GET_PROTOCOL: report
            _ => null,
        };
        return data is null ? (StatusStall, []) : (StatusOk, data.Length > length ? data[..length] : data);
    }

    private static byte[] SetConfiguration(ref int configuration, int value) { configuration = value; return []; }

    private static byte[]? StringDescriptor(int index)
    {
        if (index == 0) return [4, 3, 0x09, 0x04];      // US English
        if (index >= Strings.Length) return null;
        var text = Encoding.Unicode.GetBytes(Strings[index]);
        return [(byte)(text.Length + 2), 3, .. text];
    }

    /// <summary>usbip_usb_device (312 bytes, network byte order) as sent in OP_REP_DEVLIST / OP_REP_IMPORT.</summary>
    internal static byte[] UsbIpDeviceRecord(string busId)
    {
        var record = new byte[312];
        Encoding.ASCII.GetBytes($"/sys/devices/extedo/usb1/{busId}").CopyTo(record, 0);
        Encoding.ASCII.GetBytes(busId).CopyTo(record, 256);
        var s = record.AsSpan(288);
        BinaryPrimitives.WriteUInt32BigEndian(s, 1);        // busnum
        BinaryPrimitives.WriteUInt32BigEndian(s[4..], 1);   // devnum
        BinaryPrimitives.WriteUInt32BigEndian(s[8..], 2);   // speed: full
        BinaryPrimitives.WriteUInt16BigEndian(s[12..], VendorId);
        BinaryPrimitives.WriteUInt16BigEndian(s[14..], ProductId);
        BinaryPrimitives.WriteUInt16BigEndian(s[16..], BcdDevice);
        // class/subclass/protocol 0 (per interface), configuration value 1, 1 configuration, 1 interface
        s[21] = 1; s[22] = 1; s[23] = 1;
        return record;
    }
}
