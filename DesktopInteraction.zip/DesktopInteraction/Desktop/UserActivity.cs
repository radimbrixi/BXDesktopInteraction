using System.Runtime.InteropServices;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Detects the user's own mouse and keyboard input through Raw Input (RIDEV_INPUTSINK, so also while another window
/// has the focus). Input from the virtual mouse (usbip VID_1209&amp;PID_0001 or the ExtedoVirtualMouse driver) is
/// recognised by its device ancestry and ignored. Injected input (SendInput) arrives without a device handle; it is
/// ignored while any Desktop Interaction instance has just injected (<see cref="SharedControl.LastInputTick"/>),
/// otherwise it counts as the user (for example Remote Desktop input or other automation).
/// </summary>
internal sealed class UserActivity
{
    private const int OwnInjectionMarginMs = 250;
    private static readonly string[] OwnDeviceMarkers = ["VID_1209&PID_0001", "EXTEDOVIRTUALMOUSE"];
    private readonly Dictionary<nint, bool> own = [];
    private readonly SharedControl control;
    private long lastUserInput = long.MinValue / 2;

    internal UserActivity(SharedControl control) => this.control = control;

    /// <summary><see cref="Environment.TickCount64"/> of the last user input (very old when none was seen).</summary>
    internal long LastUserInput => Interlocked.Read(ref lastUserInput);

    internal bool Registered { get; private set; }

    /// <summary>Registers for mouse and keyboard raw input on the given (message-loop) window.</summary>
    internal void Register(nint hwnd)
    {
        RawInputDevice[] devices =
        [
            new() { UsagePage = 1, Usage = 2, Flags = 0x100 /* RIDEV_INPUTSINK */, Target = hwnd },
            new() { UsagePage = 1, Usage = 6, Flags = 0x100, Target = hwnd },
        ];
        Registered = RegisterRawInputDevices(devices, (uint)devices.Length, (uint)Marshal.SizeOf<RawInputDevice>());
    }

    /// <summary>Handles WM_INPUT. Returns true when the message was raw input.</summary>
    internal bool Handle(ref Message m)
    {
        if (m.Msg != 0x00FF) return false;
        uint size = (uint)Marshal.SizeOf<RawInputHeader>();
        if (GetRawInputData(m.LParam, 0x10000005 /* RID_HEADER */, out var header, ref size, (uint)Marshal.SizeOf<RawInputHeader>()) == uint.MaxValue) return true;
        if (header.Type is not (0 or 1)) return true; // mouse or keyboard only
        bool user = header.Device == 0
            ? Environment.TickCount64 - control.LastInputTick > OwnInjectionMarginMs
            : !IsOwnDevice(header.Device);
        if (user) Interlocked.Exchange(ref lastUserInput, Environment.TickCount64);
        return true;
    }

    /// <summary>Marks user input now (self-tests).</summary>
    internal void Simulate() => Interlocked.Exchange(ref lastUserInput, Environment.TickCount64);

    private bool IsOwnDevice(nint device)
    {
        if (own.TryGetValue(device, out bool known)) return known;
        bool result = false;
        try
        {
            string? name = DeviceName(device);
            if (name is not null)
            {
                result = Matches(name);
                // \\?\HID#VID_1209&PID_0001&MI_00#8&abc&0&0000#{guid} -> HID\VID_1209&PID_0001&MI_00\8&abc&0&0000
                var parts = name.TrimStart('\\', '?').Split('#');
                if (!result && parts.Length >= 3 && CM_Locate_DevNodeW(out uint node, $"{parts[0]}\\{parts[1]}\\{parts[2]}", 0) == 0)
                    for (int level = 0; level < 6 && !result && CM_Get_Parent(out node, node, 0) == 0; level++)
                        result = Matches(DeviceId(node));
            }
        }
        catch { /* unknown devices count as the user */ }
        own[device] = result;
        return result;
    }

    private static bool Matches(string? id) => id is not null && OwnDeviceMarkers.Any(marker => id.Contains(marker, StringComparison.OrdinalIgnoreCase));

    private static string? DeviceName(nint device)
    {
        uint chars = 0;
        GetRawInputDeviceInfoW(device, 0x20000007 /* RIDI_DEVICENAME */, null, ref chars);
        if (chars == 0) return null;
        var buffer = new char[chars];
        return GetRawInputDeviceInfoW(device, 0x20000007, buffer, ref chars) == uint.MaxValue ? null : new string(buffer).TrimEnd('\0');
    }

    private static string? DeviceId(uint node)
    {
        var buffer = new char[512];
        return CM_Get_Device_IDW(node, buffer, (uint)buffer.Length, 0) == 0 ? new string(buffer).TrimEnd('\0') : null;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct RawInputDevice { public ushort UsagePage, Usage; public uint Flags; public nint Target; }

    [StructLayout(LayoutKind.Sequential)]
    private struct RawInputHeader { public uint Type, Size; public nint Device, WParam; }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool RegisterRawInputDevices(RawInputDevice[] devices, uint count, uint size);

    [DllImport("user32.dll")]
    private static extern uint GetRawInputData(nint rawInput, uint command, out RawInputHeader data, ref uint size, uint headerSize);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern uint GetRawInputDeviceInfoW(nint device, uint command, char[]? data, ref uint size);

    [DllImport("cfgmgr32.dll", CharSet = CharSet.Unicode)]
    private static extern int CM_Locate_DevNodeW(out uint node, string deviceId, uint flags);

    [DllImport("cfgmgr32.dll")]
    private static extern int CM_Get_Parent(out uint parent, uint node, uint flags);

    [DllImport("cfgmgr32.dll", CharSet = CharSet.Unicode)]
    private static extern int CM_Get_Device_IDW(uint node, char[] buffer, uint length, uint flags);
}
