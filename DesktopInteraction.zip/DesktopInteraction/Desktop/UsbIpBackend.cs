using System.Diagnostics;
using System.Net.Sockets;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Device input without an own driver: this process emulates a USB absolute mouse (<see cref="UsbIpMouseServer"/>
/// on 127.0.0.1:3240) and the Microsoft-signed usbip-win2 client attaches it, so Windows binds its in-box USB HID
/// mouse drivers. See USBIP.md. Requires usbip-win2 installed by the user; this process never installs anything.
/// </summary>
internal sealed class UsbIpBackend : AbsoluteHidBackend
{
    private static readonly TimeSpan FirstAttachTimeout = TimeSpan.FromSeconds(20);

    private readonly UsbIpMouseServer? server;
    private readonly string? startError;
    private readonly string? usbipExe;
    private readonly Process? attachProcess;
    private string attachResult = "not started";
    private bool wasReady;

    internal UsbIpBackend(string? usbipExePath, bool autoAttach) : base(relativeCollection: true)
    {
        try { server = new UsbIpMouseServer(UsbIpMouseServer.DefaultPort); }
        catch (SocketException e)
        {
            startError = $"Cannot listen on 127.0.0.1:{UsbIpMouseServer.DefaultPort} ({e.Message}). Another USB/IP server " +
                         "(an older Desktop Interaction instance without the shared device host, a second device host, or usbipd-win) is using the port.";
            return;
        }

        usbipExe = Locate(usbipExePath);
        if (!autoAttach) { attachResult = $"manual: run 'usbip attach -r 127.0.0.1 -b {UsbIpMouseServer.BusId}'"; return; }
        if (usbipExe is null)
        {
            attachResult = "usbip.exe not found: install usbip-win2 (USBIP.md) or pass --usbip-exe <path>";
            return;
        }
        try
        {
            attachProcess = Process.Start(new ProcessStartInfo(usbipExe, ["attach", "-r", "127.0.0.1", "-b", UsbIpMouseServer.BusId])
            {
                UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true,
            });
            attachResult = "running";
            var process = attachProcess!;
            _ = Task.Run(() =>
            {
                string output = (process.StandardOutput.ReadToEnd() + " " + process.StandardError.ReadToEnd()).Trim();
                process.WaitForExit();
                attachResult = $"usbip attach exit {process.ExitCode}{(output.Length > 0 ? ": " + output : "")}";
            });
        }
        catch (Exception e) { attachResult = $"usbip attach could not start: {e.Message}"; }
    }

    public override string Name => "UsbIpVirtualMouse";

    protected override bool KeyboardCollection => true;

    protected override void Transmit(byte[] report)
    {
        EnsureReady();
        server!.Send(report);
    }

    protected override object TransportDiagnostics()
    {
        if (server is null) throw new InvalidOperationException(startError);
        if (!server.Ready) throw new InvalidOperationException(NotReadyMessage());
        return new
        {
            server = $"127.0.0.1:{server.Port}", busId = UsbIpMouseServer.BusId,
            usbip = usbipExe ?? "not found", attach = attachResult, server.DeliveredReports, server.Imports,
        };
    }

    protected override void DisposeTransport()
    {
        server?.Dispose(); // closing the connection unplugs the device in usbip-win2
        try { if (attachProcess is { HasExited: false }) attachProcess.Kill(); } catch { }
        attachProcess?.Dispose();
    }

    /// <summary>Waits for the first attach (Windows enumerates the device in a few seconds); later losses fail at once.</summary>
    private void EnsureReady()
    {
        if (server is null) throw new InvalidOperationException(startError);
        if (server.WaitReady(wasReady ? TimeSpan.Zero : FirstAttachTimeout)) { wasReady = true; return; }
        throw new InvalidOperationException(NotReadyMessage());
    }

    private string NotReadyMessage() =>
        $"The USB/IP virtual mouse is not attached ({(server!.Imported ? "imported, waiting for Windows to configure it" : "no USB/IP client connected")}; " +
        $"{attachResult}). Install usbip-win2 and see USBIP.md, or start with --device none.";

    private static string? Locate(string? explicitPath)
    {
        if (!string.IsNullOrEmpty(explicitPath)) return File.Exists(explicitPath) ? Path.GetFullPath(explicitPath) : null;
        var candidates = (Environment.GetEnvironmentVariable("PATH") ?? "")
            .Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries)
            .Select(dir => Path.Combine(dir.Trim('"'), "usbip.exe"))
            .Append(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "USBip", "usbip.exe"));
        return candidates.FirstOrDefault(File.Exists);
    }
}
