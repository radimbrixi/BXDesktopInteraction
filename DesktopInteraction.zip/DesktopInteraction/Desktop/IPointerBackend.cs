namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Low-level pointer transport. Implementations perform one immediate action;
/// pacing, human-like paths and ownership checks live in <see cref="MouseController"/>.
/// Button masks: left=1, right=2, middle=4, x1=8, x2=16.
/// </summary>
internal interface IPointerBackend : IDisposable
{
    /// <summary>Name reported by desktop_status ("SendInput" or "ExtedoVirtualMouse").</summary>
    string Name { get; }

    /// <summary>The backend can deliver input now (device attached / driver present).</summary>
    bool Available { get; }

    /// <summary>True when input originates from a (virtual) HID device rather than SendInput injection.</summary>
    bool IsDevice { get; }

    void MoveTo(int x, int y);

    void Button(int mask, bool down);

    /// <summary>Scroll in SendInput units: 120 per wheel notch.</summary>
    void Scroll(int delta, bool horizontal);

    /// <summary>Forget held buttons without sending input (another instance took over and released them).</summary>
    void ForgetButtons();

    /// <summary>
    /// Called after a move when the real pointer did not land on the requested pixel.
    /// Returns true when the backend adjusted its calibration and the move should be re-sent.
    /// </summary>
    bool Recalibrate(int requestedX, int requestedY, int actualX, int actualY);

    /// <summary>The device also has a keyboard (USB/IP device: report ID 3).</summary>
    bool HasKeyboard => false;

    /// <summary>
    /// Sends one keyboard state: HID modifier bits (LCtrl 1, LShift 2, LAlt 4, RAlt 0x40) and one HID key usage
    /// (0 = none). <c>Key(0, 0)</c> releases everything.
    /// </summary>
    void Key(int modifiers, int usage) => throw new NotSupportedException($"{Name} has no keyboard.");

    /// <summary>Availability details for desktop_status.</summary>
    object Diagnostics();
}
