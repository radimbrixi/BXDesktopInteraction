using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Blue glowing frame around every monitor while an AI drives the desktop, like OpenAI Codex computer use (its capture
/// border on every captured display plus a full-display overlay with a "ChatGPT is using your computer. Esc to cancel"
/// banner, all hidden from its own screenshots): a solid rim with a soft inset glow that pulses (2 s, ease in-out),
/// fades in/out in 300 ms, and a top-centre banner naming the AI client and how to take over. Each monitor gets four
/// edge strips (top, bottom, left, right): per-pixel-alpha layered windows that are click-through, never activate,
/// stay topmost and are excluded from screen capture (<c>WDA_EXCLUDEFROMCAPTURE</c>), so neither this server's nor
/// any other tool's screenshots contain the frame. Raw <see cref="NativeWindow"/>s positioned by UpdateLayeredWindow in
/// physical pixels, so per-monitor DPI changes never rescale them. Rebuilt on display changes. Runs on the UI thread.
/// </summary>
internal sealed class ScreenFrame : IDisposable
{
    internal static readonly Color Blue = Color.FromArgb(0, 140, 255);
    private const double FadeMs = 300, PulseMs = 2000;
    private readonly List<Strip> strips = [];
    private readonly List<Strip> banners = [];
    private string bannerClient = "AI";
    private int lastBannerAlpha = -1;
    private readonly Control owner;
    private double opacity;
    private bool dirty = true;
    private long lastTopmost;
    private int lastAlpha = -1;

    private readonly bool excludeFromCapture;

    /// <param name="excludeFromCapture">false keeps the frame in screenshots and recordings (demo videos).</param>
    internal ScreenFrame(Control owner, bool excludeFromCapture = true)
    {
        this.owner = owner;
        this.excludeFromCapture = excludeFromCapture;
        SystemEvents.DisplaySettingsChanged += OnDisplayChanged;
    }

    internal bool Visible => opacity > 0;

    private void OnDisplayChanged(object? sender, EventArgs e)
    {
        if (owner.IsHandleCreated && !owner.IsDisposed) owner.BeginInvoke(() => dirty = true);
    }

    /// <summary>Called every UI tick (~16 ms): fades towards <paramref name="wanted"/> and pulses while visible.</summary>
    /// <param name="client">AI client named in the banner ("claude-code is using your computer").</param>
    internal void Tick(bool wanted, double elapsedMs, string? client = null)
    {
        if (opacity == 0 && !wanted) return;
        client = string.IsNullOrWhiteSpace(client) ? "AI" : client;
        if (wanted && client != bannerClient) { bannerClient = client; dirty = true; }
        if (wanted && dirty) Rebuild();
        opacity = Math.Clamp(opacity + (wanted ? 1 : -1) * elapsedMs / FadeMs, 0, 1);
        double phase = Environment.TickCount64 % (long)PulseMs / PulseMs;
        double pulse = 0.78 + 0.22 * (0.5 - 0.5 * Math.Cos(2 * Math.PI * phase)); // ease in-out between 78 % and 100 %
        int alpha = (int)Math.Round(255 * opacity * pulse);
        if (alpha != lastAlpha)
        {
            lastAlpha = alpha;
            foreach (var strip in strips) strip.SetAlpha((byte)alpha, opacity > 0);
        }
        // The banner fades with the frame but does not pulse (readable text).
        int bannerAlpha = (int)Math.Round(255 * opacity);
        if (bannerAlpha != lastBannerAlpha)
        {
            lastBannerAlpha = bannerAlpha;
            foreach (var banner in banners) banner.SetAlpha((byte)bannerAlpha, opacity > 0);
        }
        KeepTopmost();
    }

    private void KeepTopmost()
    {
        if (opacity <= 0 || Environment.TickCount64 - lastTopmost < 1000) return;
        lastTopmost = Environment.TickCount64;
        foreach (var strip in strips) strip.Topmost();
        foreach (var banner in banners) banner.Topmost();
    }

    private void Rebuild()
    {
        dirty = false;
        foreach (var strip in strips) strip.Dispose();
        foreach (var banner in banners) banner.Dispose();
        strips.Clear();
        banners.Clear();
        foreach (var screen in Screen.AllScreens)
        {
            var b = screen.Bounds;
            int t = Math.Clamp(Math.Min(b.Width, b.Height) / 40, 24, 72); // glow depth, ~27 px at 1080p
            strips.Add(new Strip(excludeFromCapture, new Rectangle(b.X, b.Y, b.Width, t), area => RenderGlow(b, area)));
            strips.Add(new Strip(excludeFromCapture, new Rectangle(b.X, b.Bottom - t, b.Width, t), area => RenderGlow(b, area)));
            strips.Add(new Strip(excludeFromCapture, new Rectangle(b.X, b.Y + t, t, b.Height - 2 * t), area => RenderGlow(b, area)));
            strips.Add(new Strip(excludeFromCapture, new Rectangle(b.Right - t, b.Y + t, t, b.Height - 2 * t), area => RenderGlow(b, area)));
            // Codex-style banner at the top centre of every monitor, just inside the rim.
            using var text = RenderBanner($"{bannerClient} is using your computer", "Move the mouse or press a key to take over  ·  Ctrl+Alt+F12 stops all");
            var place = new Rectangle(b.X + (b.Width - text.Width) / 2, b.Y + 6, text.Width, text.Height);
            banners.Add(new Strip(excludeFromCapture, place, _ => (Bitmap)text.Clone()));
        }
        lastAlpha = -1;
        lastBannerAlpha = -1;
    }

    /// <summary>Alpha from the distance to the nearest monitor edge: solid rim, then a soft inset glow.</summary>
    private static Bitmap RenderGlow(Rectangle monitor, Rectangle area)
    {
        int depth = Math.Clamp(Math.Min(monitor.Width, monitor.Height) / 40, 24, 72);
        const int Rim = 3;
        var image = new Bitmap(area.Width, area.Height, PixelFormat.Format32bppArgb);
        var data = image.LockBits(new Rectangle(Point.Empty, image.Size), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        var row = new int[area.Width];
        for (int y = 0; y < area.Height; y++)
        {
            int py = area.Y + y, dy = Math.Min(py - monitor.Y, monitor.Bottom - 1 - py);
            for (int x = 0; x < area.Width; x++)
            {
                int px = area.X + x, d = Math.Min(dy, Math.Min(px - monitor.X, monitor.Right - 1 - px));
                double a = d < Rim ? 0.95 : Math.Pow(Math.Max(0, 1 - (d - Rim) / (double)(depth - Rim)), 2.2) * 0.6;
                row[x] = (int)Math.Round(a * 255) << 24 | Blue.R << 16 | Blue.G << 8 | Blue.B;
            }
            Marshal.Copy(row, 0, data.Scan0 + y * data.Stride, area.Width);
        }
        image.UnlockBits(data);
        return image;
    }

    /// <summary>Rounded blue pill with a bold title and a hint line (white text).</summary>
    internal static Bitmap RenderBanner(string title, string hint)
    {
        using var titleFont = new Font("Segoe UI", 11f, FontStyle.Bold, GraphicsUnit.Point);
        using var hintFont = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point);
        Size titleSize, hintSize;
        using (var probe = new Bitmap(1, 1))
        using (var g = Graphics.FromImage(probe))
        {
            titleSize = Size.Ceiling(g.MeasureString(title, titleFont));
            hintSize = Size.Ceiling(g.MeasureString(hint, hintFont));
        }
        const int PadX = 22, PadY = 8, Gap = 1;
        int width = Math.Max(titleSize.Width, hintSize.Width) + 2 * PadX, height = titleSize.Height + Gap + hintSize.Height + 2 * PadY;
        var image = new Bitmap(width, height, PixelFormat.Format32bppArgb);
        using (var g = Graphics.FromImage(image))
        {
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            g.Clear(Color.Transparent);
            int r = height / 2;
            using var path = new System.Drawing.Drawing2D.GraphicsPath();
            path.AddArc(0, 0, 2 * r, height - 1, 90, 180);
            path.AddArc(width - 1 - 2 * r, 0, 2 * r, height - 1, 270, 180);
            path.CloseFigure();
            using var fill = new SolidBrush(Color.FromArgb(235, 0, 98, 196));
            using var rim = new Pen(Color.FromArgb(255, Blue), 2f);
            g.FillPath(fill, path);
            g.DrawPath(rim, path);
            using var white = new SolidBrush(Color.White);
            using var soft = new SolidBrush(Color.FromArgb(225, 255, 255, 255));
            g.DrawString(title, titleFont, white, (width - titleSize.Width) / 2f, PadY);
            g.DrawString(hint, hintFont, soft, (width - hintSize.Width) / 2f, PadY + titleSize.Height + Gap);
        }
        return image;
    }

    public void Dispose()
    {
        SystemEvents.DisplaySettingsChanged -= OnDisplayChanged;
        foreach (var strip in strips) strip.Dispose();
        foreach (var banner in banners) banner.Dispose();
        strips.Clear();
        banners.Clear();
    }

    /// <summary>One click-through layered window showing a pre-rendered per-pixel-alpha image (edge strip or banner).</summary>
    private sealed class Strip : NativeWindow, IDisposable
    {
        private readonly Rectangle area;
        private nint bitmap, memoryDc, previous;
        private bool shown;

        internal Strip(bool excludeFromCapture, Rectangle area, Func<Rectangle, Bitmap> render)
        {
            this.area = area;
            CreateHandle(new CreateParams
            {
                Caption = "Extedo Desktop Interaction frame",
                X = area.X, Y = area.Y, Width = area.Width, Height = area.Height,
                Style = unchecked((int)0x80000000), // WS_POPUP
                ExStyle = 0x00080000 | 0x00000020 | 0x00000080 | 0x08000000 | 0x00000008, // LAYERED | TRANSPARENT | TOOLWINDOW | NOACTIVATE | TOPMOST
            });
            if (excludeFromCapture) SetWindowDisplayAffinity(Handle, 0x11 /* WDA_EXCLUDEFROMCAPTURE */);
            using var image = render(area);
            Render(image);
        }

        private void Render(Bitmap image)
        {
            nint screen = GetDC(0);
            memoryDc = CreateCompatibleDC(screen);
            bitmap = image.GetHbitmap(Color.FromArgb(0));
            previous = SelectObject(memoryDc, bitmap);
            var size = new Size(area.Width, area.Height);
            var source = Point.Empty;
            var position = area.Location;
            var blend = new Blend { Op = 0, Flags = 0, Alpha = 0, Format = 1 /* AC_SRC_ALPHA */ };
            UpdateLayeredWindow(Handle, screen, ref position, ref size, memoryDc, ref source, 0, ref blend, 2 /* ULW_ALPHA */);
            ReleaseDC(0, screen);
        }

        internal void SetAlpha(byte alpha, bool visible)
        {
            var blend = new Blend { Op = 0, Flags = 0, Alpha = alpha, Format = 1 };
            UpdateLayeredWindowAlpha(Handle, 0, 0, 0, 0, 0, 0, ref blend, 2);
            if (visible != shown) { ShowWindow(Handle, visible ? 4 /* SW_SHOWNOACTIVATE */ : 0 /* SW_HIDE */); shown = visible; }
        }

        internal void Topmost() => SetWindowPos(Handle, -1 /* HWND_TOPMOST */, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010 /* NOSIZE | NOMOVE | NOACTIVATE */);

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0084) { m.Result = -1; return; } // WM_NCHITTEST: HTTRANSPARENT
            base.WndProc(ref m);
        }

        public void Dispose()
        {
            if (memoryDc != 0) { SelectObject(memoryDc, previous); DeleteDC(memoryDc); memoryDc = 0; }
            if (bitmap != 0) { DeleteObject(bitmap); bitmap = 0; }
            DestroyHandle();
        }
    }

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    private struct Blend { public byte Op, Flags, Alpha, Format; }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UpdateLayeredWindow(nint hwnd, nint screenDc, ref Point position, ref Size size, nint sourceDc, ref Point source, int key, ref Blend blend, int flags);

    [DllImport("user32.dll", EntryPoint = "UpdateLayeredWindow", SetLastError = true)]
    private static extern bool UpdateLayeredWindowAlpha(nint hwnd, nint screenDc, nint position, nint size, nint sourceDc, nint source, int key, ref Blend blend, int flags);

    [DllImport("user32.dll")] private static extern bool SetWindowDisplayAffinity(nint hwnd, uint affinity);
    [DllImport("user32.dll")] private static extern bool ShowWindow(nint hwnd, int command);
    [DllImport("user32.dll")] private static extern bool SetWindowPos(nint hwnd, nint after, int x, int y, int cx, int cy, uint flags);
    [DllImport("user32.dll")] private static extern nint GetDC(nint hwnd);
    [DllImport("user32.dll")] private static extern int ReleaseDC(nint hwnd, nint dc);
    [DllImport("gdi32.dll")] private static extern nint CreateCompatibleDC(nint dc);
    [DllImport("gdi32.dll")] private static extern bool DeleteDC(nint dc);
    [DllImport("gdi32.dll")] private static extern nint SelectObject(nint dc, nint obj);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(nint obj);
}
