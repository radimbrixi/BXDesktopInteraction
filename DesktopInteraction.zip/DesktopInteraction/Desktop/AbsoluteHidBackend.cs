using System.Buffers.Binary;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Shared logic of the device backends: an absolute HID pointer (report ID 1) and, when the device has one, a
/// relative mouse collection (report ID 2), each 8 bytes. Subclasses only transport reports (VHF driver IOCTL,
/// USB/IP interrupt endpoint). Layout: Driver\ExtedoVirtualMouse\Public.h and <see cref="UsbIpMouseDevice"/>.
/// <para>
/// Windows maps an absolute mouse without the virtual-desktop flag (in-box mouhid never sets it) to the primary
/// monitor only. With a relative collection, targets on the primary monitor use absolute reports (exact in one step)
/// and targets on other monitors use relative reports corrected against the real pointer position. Buttons and
/// wheel then always travel in the relative collection, because Windows tracks button state per collection.
/// </para>
/// </summary>
internal abstract class AbsoluteHidBackend : IPointerBackend
{
    internal const int AbsoluteMax = 32767;
    internal const int RelativeMax = 32767;

    protected readonly object gate = new();
    private readonly bool relative;
    private readonly Rectangle absoluteArea;
    private int buttons;
    private ushort lastX, lastY;
    private int lastPixelX = int.MinValue, lastPixelY = int.MinValue;
    private readonly AxisMap mapX, mapY;

    /// <param name="relativeCollection">The device also has the relative collection (report ID 2).</param>
    protected AbsoluteHidBackend(bool relativeCollection)
    {
        relative = relativeCollection;
        absoluteArea = relative ? Screen.PrimaryScreen!.Bounds : SystemInformation.VirtualScreen;
        mapX = AxisMap.FromRange(absoluteArea.X, absoluteArea.Width);
        mapY = AxisMap.FromRange(absoluteArea.Y, absoluteArea.Height);
    }

    public abstract string Name { get; }

    public bool IsDevice => true;

    public bool Available { get { lock (gate) { try { TransportDiagnostics(); return true; } catch { return false; } } } }

    /// <summary>Delivers one report to the device. Called under <see cref="gate"/>; throws when the device is unavailable.</summary>
    protected abstract void Transmit(byte[] report);

    /// <summary>Transport details for desktop_status. Called under <see cref="gate"/>; throws when unavailable.</summary>
    protected abstract object TransportDiagnostics();

    protected abstract void DisposeTransport();

    public void MoveTo(int x, int y)
    {
        lock (gate)
        {
            if (!relative || absoluteArea.Contains(x, y))
            {
                SendAbsolute(mapX.ToDevice(x), mapY.ToDevice(y), relative ? 0 : buttons, 0, 0);
                lastPixelX = x; lastPixelY = y;
                return;
            }
            RelativeStep(x, y);
            lastPixelX = int.MinValue;
        }
    }

    private double gainX = 1, gainY = 1;
    private const double Damping = 0.7;

    /// <summary>
    /// One damped relative correction towards (x,y). Windows applies pointer ballistics (for example "Enhance pointer
    /// precision") to relative input, so the pixels moved per count vary with speed. Each step sends 70 % of the
    /// remaining distance divided by the learned gain, waits until Windows has applied it (so the next step never
    /// counts the same distance twice) and updates the gain from what really moved. This converges instead of
    /// overshooting when the gain is above 1.
    /// </summary>
    private void RelativeStep(int x, int y)
    {
        Native.GetCursorPos(out var p);
        int ex = x - p.X, ey = y - p.Y;
        if (ex == 0 && ey == 0) return;
        // Last pixels: move slowly, so pointer acceleration stays below 1 pixel per count.
        if (Math.Abs(ex) <= 2 && Math.Abs(ey) <= 2) Thread.Sleep(25);
        int cx = Counts(ex, gainX), cy = Counts(ey, gainY);
        var q = SendRelative(p, cx, cy);
        // Windows blocks a diagonal step that leaves a monitor outside the edge it shares with the next one
        // (offset or rotated monitors): slide along one axis at a time instead.
        if (q.X == p.X && q.Y == p.Y && cx != 0 && cy != 0)
        {
            q = SendRelative(p, cx, 0);
            if (q.X == p.X && q.Y == p.Y) q = SendRelative(p, 0, cy);
            return;
        }
        gainX = LearnGain(gainX, cx, q.X - p.X);
        gainY = LearnGain(gainY, cy, q.Y - p.Y);
    }

    /// <summary>Sends one relative report and waits (max 15 ms) until Windows has moved the pointer.</summary>
    private Native.Point SendRelative(Native.Point from, int cx, int cy)
    {
        Transmit(EncodeRelative(cx, cy, buttons, 0, 0));
        var clock = System.Diagnostics.Stopwatch.StartNew();
        Native.GetCursorPos(out var q);
        while (q.X == from.X && q.Y == from.Y && clock.ElapsedMilliseconds < 15) { Thread.Sleep(1); Native.GetCursorPos(out q); }
        return q;
    }

    internal static int Counts(int error, double gain)
    {
        int counts = (int)Math.Round(error * Damping / gain);
        if (counts == 0) counts = Math.Sign(error);
        return Math.Clamp(counts, -RelativeMax, RelativeMax);
    }

    /// <summary>Pixels per count, smoothed; ignores tiny or blocked moves (screen edges) that say nothing about the gain.</summary>
    internal static double LearnGain(double gain, int counts, int moved)
    {
        if (Math.Abs(counts) < 3 || moved == 0 || Math.Sign(moved) != Math.Sign(counts)) return gain;
        return Math.Clamp(0.6 * gain + 0.4 * (moved / (double)counts), 0.2, 8);
    }

    public void Button(int mask, bool down)
    {
        lock (gate)
        {
            int next = down ? buttons | mask : buttons & ~mask;
            if (relative) Transmit(EncodeRelative(0, 0, next, 0, 0));
            else { var (x, y) = CurrentDevicePosition(); SendAbsolute(x, y, next, 0, 0); }
            buttons = next;
        }
    }

    public void Scroll(int delta, bool horizontal)
    {
        if (delta % 120 != 0) throw new ArgumentException($"The {Name} backend scrolls whole wheel notches: delta must be a multiple of 120.");
        lock (gate)
        {
            var (x, y) = relative ? ((ushort)0, (ushort)0) : CurrentDevicePosition();
            int notches = delta / 120;
            while (notches != 0)
            {
                int chunk = Math.Clamp(notches, -127, 127);
                int wheel = horizontal ? 0 : chunk, pan = horizontal ? chunk : 0;
                if (relative) Transmit(EncodeRelative(0, 0, buttons, wheel, pan));
                else SendAbsolute(x, y, buttons, wheel, pan);
                notches -= chunk;
            }
        }
    }

    public void ForgetButtons() { lock (gate) buttons = 0; }

    /// <summary>The device has the keyboard collection (report ID 3).</summary>
    protected virtual bool KeyboardCollection => false;

    public bool HasKeyboard => KeyboardCollection;

    private bool keysHeld;

    public void Key(int modifiers, int usage)
    {
        if (!KeyboardCollection) throw new NotSupportedException($"{Name} has no keyboard.");
        lock (gate)
        {
            Transmit(EncodeKeyboard(modifiers, usage));
            keysHeld = modifiers != 0 || usage != 0;
        }
    }

    /// <summary>Keyboard report: id 3, modifier bits, 6-key array (one key used).</summary>
    internal static byte[] EncodeKeyboard(int modifiers, int usage)
    {
        if (modifiers is < 0 or > 255 || usage is < 0 or > 255) throw new ArgumentOutOfRangeException(nameof(usage), "Report is outside the HID descriptor limits.");
        return [3, (byte)modifiers, (byte)usage, 0, 0, 0, 0, 0];
    }

    /// <summary>Sends reports without buttons/keys when any is held (shared device host: takeover or instance request).</summary>
    internal void ReleaseButtons()
    {
        lock (gate)
        {
            if (keysHeld) { try { Transmit(EncodeKeyboard(0, 0)); } finally { keysHeld = false; } }
            if (buttons == 0) return;
            try
            {
                if (relative) Transmit(EncodeRelative(0, 0, 0, 0, 0));
                else SendAbsolute(lastX, lastY, 0, 0, 0);
            }
            finally { buttons = 0; }
        }
    }

    public bool Recalibrate(int requestedX, int requestedY, int actualX, int actualY)
    {
        lock (gate)
        {
            // Relative targets are re-sent as a correction from the real position (pointer ballistics vary).
            if (relative && !absoluteArea.Contains(requestedX, requestedY)) return true;
            return mapX.Learn(lastX, actualX, requestedX) | mapY.Learn(lastY, actualY, requestedY);
        }
    }

    public object Diagnostics()
    {
        lock (gate)
        {
            try
            {
                return new
                {
                    available = true, transport = TransportDiagnostics(), keyboard = KeyboardCollection,
                    absoluteArea = new { absoluteArea.X, absoluteArea.Y, absoluteArea.Width, absoluteArea.Height },
                    otherMonitors = relative ? "relative, corrected to the exact pixel" : "absolute mapping only",
                    mapX = mapX.ToString(), mapY = mapY.ToString(),
                };
            }
            catch (Exception e) { return new { available = false, error = e.Message }; }
        }
    }

    /// <summary>Keeps the pointer where it is: reuse the last report when the pointer has not moved since.</summary>
    private (ushort x, ushort y) CurrentDevicePosition()
    {
        Native.GetCursorPos(out var p);
        if (p.X == lastPixelX && p.Y == lastPixelY) return (lastX, lastY);
        return (mapX.ToDevice(p.X), mapY.ToDevice(p.Y));
    }

    private void SendAbsolute(ushort x, ushort y, int buttonMask, int wheel, int horizontalWheel)
    {
        Transmit(Encode(x, y, buttonMask, wheel, horizontalWheel));
        lastX = x; lastY = y;
    }

    /// <summary>Absolute report: id 1, buttons, X (LE), Y (LE), wheel, horizontal wheel.</summary>
    internal static byte[] Encode(ushort x, ushort y, int buttonMask, int wheel, int horizontalWheel)
    {
        if (x > AbsoluteMax || y > AbsoluteMax) throw new ArgumentOutOfRangeException(nameof(x), "Report is outside the HID descriptor limits.");
        return Report(1, x, y, buttonMask, wheel, horizontalWheel);
    }

    /// <summary>Relative report: id 2, buttons, dX (LE, signed), dY (LE, signed), wheel, horizontal wheel.</summary>
    internal static byte[] EncodeRelative(int dx, int dy, int buttonMask, int wheel, int horizontalWheel)
    {
        if (dx is < -RelativeMax or > RelativeMax || dy is < -RelativeMax or > RelativeMax)
            throw new ArgumentOutOfRangeException(nameof(dx), "Report is outside the HID descriptor limits.");
        return Report(2, unchecked((ushort)(short)dx), unchecked((ushort)(short)dy), buttonMask, wheel, horizontalWheel);
    }

    private static byte[] Report(byte id, ushort x, ushort y, int buttonMask, int wheel, int horizontalWheel)
    {
        if (buttonMask is < 0 or > 31 || wheel is < -127 or > 127 || horizontalWheel is < -127 or > 127)
            throw new ArgumentOutOfRangeException(nameof(buttonMask), "Report is outside the HID descriptor limits.");
        var data = new byte[8];
        data[0] = id;
        data[1] = (byte)buttonMask;
        BinaryPrimitives.WriteUInt16LittleEndian(data.AsSpan(2), x);
        BinaryPrimitives.WriteUInt16LittleEndian(data.AsSpan(4), y);
        data[6] = unchecked((byte)(sbyte)wheel);
        data[7] = unchecked((byte)(sbyte)horizontalWheel);
        return data;
    }

    public void Dispose()
    {
        lock (gate)
        {
            try
            {
                if (keysHeld) Transmit(EncodeKeyboard(0, 0));
                if (buttons != 0)
                {
                    if (relative) Transmit(EncodeRelative(0, 0, 0, 0, 0));
                    else SendAbsolute(lastX, lastY, 0, 0, 0);
                }
            }
            catch { /* the device side releases on disconnect */ }
            buttons = 0;
            DisposeTransport();
        }
    }
}

/// <summary>
/// Maps one pixel axis to the absolute HID range 0..32767: pixel = Offset + value * Scale.
/// Starts with the expected area and learns the real mapping from observed pointer positions.
/// </summary>
internal sealed class AxisMap(double offset, double scale)
{
    internal double Offset { get; private set; } = offset;
    internal double Scale { get; private set; } = scale;
    private (ushort value, int pixel)? anchor;

    internal static AxisMap FromRange(int origin, int length) => new(origin, Math.Max(1, length - 1) / (double)AbsoluteHidBackend.AbsoluteMax);

    internal ushort ToDevice(int pixel) => (ushort)Math.Clamp((int)Math.Round((pixel - Offset) / Scale), 0, AbsoluteHidBackend.AbsoluteMax);

    /// <summary>Learn from a sent value and the pixel the pointer actually reached. Returns true if the mapping changed.</summary>
    internal bool Learn(ushort sentValue, int actualPixel, int requestedPixel)
    {
        if (actualPixel == requestedPixel) { anchor ??= (sentValue, actualPixel); return false; }
        double oldOffset = Offset, oldScale = Scale;
        if (anchor is { } a && Math.Abs(a.value - sentValue) > 2000 && a.pixel != actualPixel)
        {
            Scale = (actualPixel - a.pixel) / (double)(sentValue - a.value);
            Offset = a.pixel - a.value * Scale;
        }
        else
        {
            Offset = actualPixel - sentValue * Scale;
        }
        anchor = (sentValue, actualPixel);
        return Math.Abs(oldOffset - Offset) > 0.01 || Math.Abs(oldScale - Scale) > 1e-9;
    }

    public override string ToString() => $"pixel = {Offset:0.##} + value * {Scale:0.######}";
}
