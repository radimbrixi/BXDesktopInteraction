namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Command-line options. Both input paths are always offered as separate tools; <c>--device</c> selects what backs
/// the device tools: <c>usbip</c> (default, virtual USB mouse via usbip-win2), <c>driver</c> (ExtedoVirtualMouse,
/// test-signed) or <c>none</c>. Also <c>--motion human|linear</c>, <c>--usbip-exe &lt;path&gt;</c>,
/// <c>--usbip-attach auto|manual</c>, <c>--user-idle-ms &lt;0-60000&gt;</c> (user inactivity required before input,
/// default 7000, 0 = off), <c>--device-sharing on|off</c> (one shared device host for all instances, default on),
/// <c>--frame on|off|captured</c> (blue frame around all monitors while an AI drives, default on = hidden from screen capture; captured = also in screenshots/recordings), <c>--device-host-idle-s &lt;s&gt;</c> (host lifetime without instances, default 600), <c>--user-wait-ms &lt;0-600000&gt;</c> (longest wait for it, default 30000), <c>--secure-desktop-input off|device</c> (default off; device = let the virtual device operate the secure desktop/UAC prompt with a blind click at a pre-measured position, since it cannot be captured - test machines only), and for <c>--self-test</c> <c>--input device|injected</c>.
/// </summary>
internal sealed record DesktopOptions(string Device, bool HumanMotion, string? UsbIpExe = null, bool UsbIpAutoAttach = true, InputKind SelfTestInput = InputKind.Device, int UserIdleMs = 7000, int UserWaitMs = 30000, bool SharedDevice = true, TimeSpan HostIdle = default, bool Frame = true, bool FrameCaptured = false, bool SecureDesktopDeviceInput = false)
{
    internal static DesktopOptions Parse(string[] args)
    {
        if (args.Contains("--backend"))
            throw new ArgumentException("--backend was replaced: both input paths are always available as separate tools. Use --device usbip|driver|none to choose what backs the device tools.");
        string device = Value(args, "--device") ?? "usbip";
        string motion = Value(args, "--motion") ?? "human";
        string attach = Value(args, "--usbip-attach") ?? "auto";
        string input = Value(args, "--input") ?? "device";
        if (device is not ("usbip" or "driver" or "none")) throw new ArgumentException("--device must be usbip, driver or none.");
        if (motion is not ("human" or "linear")) throw new ArgumentException("--motion must be human or linear.");
        if (attach is not ("auto" or "manual")) throw new ArgumentException("--usbip-attach must be auto or manual.");
        if (input is not ("device" or "injected")) throw new ArgumentException("--input must be device or injected.");
        int idle = Bounded(args, "--user-idle-ms", 7000, 60000);
        int wait = Bounded(args, "--user-wait-ms", 30000, 600000);
        string sharing = Value(args, "--device-sharing") ?? "on";
        if (sharing is not ("on" or "off")) throw new ArgumentException("--device-sharing must be on or off.");
        string frame = Value(args, "--frame") ?? "on";
        if (frame is not ("on" or "off" or "captured")) throw new ArgumentException("--frame must be on, off or captured.");
        int hostIdle = Bounded(args, "--device-host-idle-s", (int)DeviceHost.DefaultIdle.TotalSeconds, 86400);
        string secureDesktop = Value(args, "--secure-desktop-input") ?? "off";
        if (secureDesktop is not ("off" or "device")) throw new ArgumentException("--secure-desktop-input must be off or device.");
        return new(device, motion == "human", RawValue(args, "--usbip-exe"), attach == "auto", input == "device" ? InputKind.Device : InputKind.Injected, idle, wait,
            sharing == "on", TimeSpan.FromSeconds(hostIdle), frame != "off", frame == "captured", secureDesktop == "device");
    }

    private static int Bounded(string[] args, string name, int fallback, int max)
    {
        string? raw = RawValue(args, name);
        if (raw is null) return fallback;
        if (!int.TryParse(raw, out int value) || value < 0 || value > max) throw new ArgumentException($"{name} must be 0-{max}.");
        return value;
    }

    /// <summary>
    /// The device backend of an MCP instance: the shared device host (one virtual mouse for all AI clients), or with
    /// <c>--device-sharing off</c> a device owned by this process alone (the first instance wins the usbip port).
    /// </summary>
    internal IPointerBackend? CreateDevice(Func<long> generation)
    {
        if (Device == "none") return null;
        if (!SharedDevice) return CreateLocalDevice();
        var arguments = new List<string> { "--device-host", "--device", Device, "--device-host-idle-s", ((int)HostIdle.TotalSeconds).ToString() };
        if (UsbIpExe is not null) arguments.AddRange(["--usbip-exe", $"\"{UsbIpExe}\""]);
        if (!UsbIpAutoAttach) arguments.AddRange(["--usbip-attach", "manual"]);
        return new RemoteDeviceBackend(Device == "usbip" ? "UsbIpVirtualMouse" : "ExtedoVirtualMouse", string.Join(' ', arguments), generation);
    }

    /// <summary>Device owned by this process. Device backends connect lazily, so the server starts (and reports status) without the device.</summary>
    internal IPointerBackend? CreateLocalDevice() => Device switch
    {
        "usbip" => new UsbIpBackend(UsbIpExe, UsbIpAutoAttach),
        "driver" => new DriverBackend(),
        _ => null,
    };

    /// <summary>Options that take a value (the next argument).</summary>
    private static readonly HashSet<string> ValueOptions =
    [
        "--device", "--motion", "--usbip-exe", "--usbip-attach", "--user-idle-ms", "--user-wait-ms", "--device-sharing", "--frame",
        "--device-host-idle-s", "--secure-desktop-input", "--input", "--save-feedback", "--usbip-install", "--usbip-sha256", "--driver-install",
        "--backend", // removed; Parse explains the replacement
    ];

    /// <summary>Options without a value: modes and switches.</summary>
    private static readonly HashSet<string> FlagOptions =
    [
        "--demo", "--device-host", "--self-test", "--feedback-live-test", "--coordination-self-test", "--motion-self-test", "--usbip-self-test",
        "--feedback-self-test", "--device-host-self-test", "--layout-self-test", "--usbip-uninstall", "--driver-uninstall", "--help", "--version",
    ];

    /// <summary>True for <c>--help</c>, <c>-help</c>, <c>-h</c>, <c>-?</c>, <c>/?</c> and <c>/h</c>.</summary>
    internal static bool WantsHelp(string[] args) => args.Any(a => a is "--help" or "-h" or "-?" or "/?" or "/h" or "-help");

    /// <summary>
    /// Rejects unknown options, stray arguments and options missing their value, so a typo in an MCP client's
    /// <c>args</c> fails at once instead of silently running with a default.
    /// </summary>
    internal static void Validate(string[] args)
    {
        for (int i = 0; i < args.Length; i++)
        {
            string arg = args[i];
            if (ValueOptions.Contains(arg))
            {
                if (i + 1 >= args.Length || args[i + 1].StartsWith("--", StringComparison.Ordinal))
                    throw new ArgumentException($"{arg} needs a value.");
                i++;
            }
            else if (!FlagOptions.Contains(arg))
                throw new ArgumentException(arg.StartsWith('-') || arg.StartsWith('/') ? $"Unknown option '{arg}'." : $"Unexpected argument '{arg}'.");
        }
    }

    /// <summary>Text printed by <c>--help</c>. Keep it in sync with <see cref="Parse"/>, Program.Main and MANUAL.md section 7.</summary>
    internal static string Usage(string serverName, string version) => $$"""
        Extedo Desktop Interaction {{version}} - local stdio MCP server ("{{serverName}}") for Windows desktop control:
        screenshots, mouse (virtual USB device or SendInput), text and key input, window focus. Manual: MANUAL.md.

        USAGE
          Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe [server options]       run the MCP server on stdin/stdout
          Extedo.AutoTest.Ai.Mcp.DesktopInteraction.exe <mode> [options]       run a tool mode (see MODES)

          The MCP server is started by the AI client: put the options into "args" of its MCP configuration, e.g.
            "args": ["--frame", "captured", "--user-idle-ms", "3000"]
          stdout carries the MCP protocol; diagnostics go to stderr. Do not start it with "dotnet run".
          Option names are case-sensitive; values are not (--device USBIP = --device usbip).

        SERVER OPTIONS
          --device usbip|driver|none          What backs the device tools (desktop_mouse_*, and the device
                                              keyboard of desktop_type_text / desktop_press_keys). Default: usbip
                                                usbip  virtual USB mouse + keyboard via usbip-win2 (USBIP.md)
                                                driver Extedo test-signed mouse driver, mouse only (DRIVER.md)
                                                none   no device: device mouse tools fail, typing uses SendInput
          --usbip-attach auto|manual          auto: the device host runs "usbip attach" itself. manual: you run
                                              "usbip attach -r 127.0.0.1 -b 1-1" yourself.         Default: auto
          --usbip-exe <path>                  usbip.exe to use.       Default: first usbip.exe on PATH, else
                                              %ProgramFiles%\USBip\usbip.exe
          --device-sharing on|off             on: one shared device host process serves all AI clients.
                                              off: each server owns its own device (only the first one gets
                                              port 3240).                                            Default: on
          --device-host-idle-s <0-86400>      Seconds the shared device host stays alive after the last
                                              server disconnected.                                  Default: 600
          --user-idle-ms <0-60000>            The user must have been idle this long before AI input starts.
                                              0 = no waiting and no stop on user input (unattended
                                              test machines only).                                 Default: 7000
          --user-wait-ms <0-600000>           Longest wait for that idle time; then the tool returns an error
                                              without sending input.                              Default: 30000
          --motion human|linear               human: curved, variably paced paths, overshoot, natural pauses.
                                              linear: straight, constant-speed (moves 250 ms).    Default: human
          --frame on|off|captured             Blue frame + "... is using your computer" banner on every monitor
                                              while an AI drives.                                    Default: on
                                                on       hidden from all screen capture and screenshots
                                                captured also visible in screenshots and recordings (demos)
                                                off      no frame and no banner (the cursor marker remains)
          --secure-desktop-input off|device   off: all input is refused while the secure desktop (UAC prompt,
                                              lock screen) is shown. device: the virtual device may operate it
                                              BLIND at a position measured beforehand (it cannot be captured).
                                              Test machines only; injected input is always refused there.
                                                                                                    Default: off

        MODES (instead of the MCP server; exit code 0 = PASS / success)
          --help, -help, -h, -?, /?, /h       Show this help.
          --version                           Print the version.
          --demo                              Show the cursor marker, frame and banner without serving MCP.
                                              Accepts the server options (e.g. --frame captured). Ctrl+C ends it.
          --device-host                       Run the shared device host (started automatically by servers;
                                              takes --device, --usbip-exe, --usbip-attach, --device-host-idle-s).
          --self-test [--input device|injected]
                                              Moves the REAL pointer on its own test window: move, click,
                                              double click, drag, wheel. Hands off mouse and keyboard.
                                              --input defaults to device (needs --device usbip or driver).
          --feedback-live-test [--input device|injected] [--save-feedback <existing folder>]
                                              Visual-feedback test on its own window (typing, scroll, drag,
                                              late changes). Moves the real pointer. Saves the PNGs if asked.
          --motion-self-test                  Motion paths, HID report encoding, calibration. No input.
          --layout-self-test                  Monitor routing on real and synthetic layouts. No input.
          --feedback-self-test                Change detection and cropping, real capture. No input.
          --coordination-self-test            Baton, pause and emergency stop between processes. No input.
          --device-host-self-test             Shared device host protocol with a fake device. No input.
          --usbip-self-test                   USB/IP protocol and USB HID emulation over loopback. No input.
          --usbip-install <USBip-x.y.z-x64.exe> [--usbip-sha256 <hash>]
                                              Silent install of usbip-win2 (elevated prompt; reboot after).
                                              Only pinned installers, or the one matching --usbip-sha256.
          --usbip-uninstall                   Silent uninstall of usbip-win2 (elevated prompt; reboot after).
          --driver-install <ExtedoVirtualMouse.inf>
                                              Install the Extedo test-signed driver (elevated, test VMs).
          --driver-uninstall                  Remove the Extedo driver device and package (elevated).

        EXIT CODES
          0 success / PASS   1 failure / FAIL   2 invalid command line

        KEYS WHILE IT RUNS
          Ctrl+Alt+F12  emergency stop for all instances (latched until every server has closed)
          Escape (hold) cancels the running mouse operation
          Moving the mouse / pressing a key stops the running AI action (unless --user-idle-ms 0)
        """;

    internal static string? Value(string[] args, string name) => RawValue(args, name)?.ToLowerInvariant();

    internal static string? RawValue(string[] args, string name)
    {
        int index = Array.IndexOf(args, name);
        return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
    }
}
