using System.IO.Pipes;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Device backend of an MCP server instance: forwards every device action to the shared <see cref="DeviceHost"/>, so
/// all AI clients drive the same virtual mouse. Starts the host when none is running and reconnects (restarting it)
/// when it went away. Requests carry this instance's baton generation; the host refuses superseded instances.
/// </summary>
internal sealed class RemoteDeviceBackend : IPointerBackend
{
    private static readonly TimeSpan ConnectTimeout = TimeSpan.FromSeconds(10);
    private static readonly TimeSpan RequestTimeout = TimeSpan.FromSeconds(30); // first usbip attach takes up to 20 s

    private readonly object gate = new();
    private readonly string hostArguments;
    private readonly Func<long> generation;
    private NamedPipeClientStream? pipe;
    private StreamReader? reader;
    private StreamWriter? writer;
    private string? lastError;
    private long retryAfter;
    private bool pressed;

    private readonly string pipeName;

    internal RemoteDeviceBackend(string name, string hostArguments, Func<long> generation, string? pipeName = null)
    {
        Name = name;
        this.pipeName = pipeName ?? DeviceHost.PipeName;
        this.hostArguments = hostArguments;
        this.generation = generation;
        // Start (or find) the host in the background, so the device is attached by the first input request.
        _ = Task.Run(() => { try { lock (gate) Connect(); } catch { } });
    }

    public string Name { get; }

    public bool IsDevice => true;

    public bool Available
    {
        get
        {
            try { return Request(new() { ["op"] = "diagnostics" })?["available"]?.GetValue<bool>() == true; }
            catch { return false; }
        }
    }

    public void MoveTo(int x, int y) => Request(new() { ["op"] = "move", ["x"] = x, ["y"] = y });

    public void Button(int mask, bool down)
    {
        Request(new() { ["op"] = "button", ["mask"] = mask, ["down"] = down });
        if (down) pressed = true;
    }

    public bool HasKeyboard
    {
        get
        {
            try { return Request(new() { ["op"] = "diagnostics" })?["keyboard"]?.GetValue<bool>() == true; }
            catch { return false; }
        }
    }

    public void Key(int modifiers, int usage)
    {
        Request(new() { ["op"] = "key", ["mod"] = modifiers, ["usage"] = usage });
        if (modifiers != 0 || usage != 0) pressed = true;
    }

    public void Scroll(int delta, bool horizontal) => Request(new() { ["op"] = "scroll", ["delta"] = delta, ["horizontal"] = horizontal });

    /// <summary>Takeover: the host releases device buttons and keys held for the previous owner (on this instance's first request anyway).</summary>
    /// <remarks>Cheap when this instance pressed nothing: idle instances call it often (paused-state cleanup).</remarks>
    public void ForgetButtons()
    {
        if (!pressed) return;
        pressed = false;
        try { Request(new() { ["op"] = "release" }); } catch { /* superseded (the new owner's first request releases) or host gone */ }
    }

    public bool Recalibrate(int requestedX, int requestedY, int actualX, int actualY)
        => Request(new() { ["op"] = "recalibrate", ["rx"] = requestedX, ["ry"] = requestedY, ["ax"] = actualX, ["ay"] = actualY })?.GetValue<bool>() == true;

    public object Diagnostics()
    {
        try
        {
            var result = Request(new() { ["op"] = "diagnostics" });
            return new { shared = $"device host over \\\\.\\pipe\\{pipeName}", host = result };
        }
        catch (Exception e) { return new { shared = "device host unavailable", error = e.Message }; }
    }

    private JsonNode? Request(JsonObject request)
    {
        lock (gate)
        {
            request["g"] = generation();
            Connect();
            try
            {
                writer!.WriteLine(request.ToJsonString());
                var pending = reader!.ReadLineAsync();
                if (!pending.Wait(RequestTimeout)) throw new IOException("The shared device host did not answer.");
                var reply = JsonNode.Parse(pending.Result ?? throw new IOException("The shared device host closed the connection."))!;
                if (reply["ok"]!.GetValue<bool>()) return reply["r"];
                string message = reply["e"]?.GetValue<string>() ?? "Device host error.";
                throw reply["cancelled"]?.GetValue<bool>() == true ? new OperationCanceledException(message) : new InvalidOperationException(message);
            }
            catch (Exception e) when (e is IOException or ObjectDisposedException or AggregateException)
            {
                Disconnect();
                throw new InvalidOperationException($"Lost the shared device host ({e.GetBaseException().Message}); the next request restarts it.", e);
            }
        }
    }

    private void Connect()
    {
        if (pipe is { IsConnected: true }) return;
        Disconnect();
        if (Environment.TickCount64 < retryAfter) throw new InvalidOperationException(lastError ?? "Shared device host unavailable.");
        try
        {
            if (!TryOpen(TimeSpan.FromMilliseconds(200)))
            {
                DeviceHost.Launch(hostArguments);
                if (!TryOpen(ConnectTimeout)) throw new TimeoutException($"The shared device host did not start within {ConnectTimeout.TotalSeconds} s.");
            }
            lastError = null;
        }
        catch (Exception e)
        {
            Disconnect();
            lastError = $"Shared device host unavailable: {e.Message}";
            retryAfter = Environment.TickCount64 + 2000;
            throw new InvalidOperationException(lastError, e);
        }
    }

    private bool TryOpen(TimeSpan timeout)
    {
        var deadline = DateTime.UtcNow + timeout;
        do
        {
            var client = new NamedPipeClientStream(".", pipeName, PipeDirection.InOut, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
            try
            {
                client.Connect((int)Math.Clamp((deadline - DateTime.UtcNow).TotalMilliseconds, 50, 1000));
                pipe = client;
                reader = new StreamReader(client, new UTF8Encoding(false));
                writer = new StreamWriter(client, new UTF8Encoding(false)) { AutoFlush = true };
                return true;
            }
            catch (Exception e) when (e is TimeoutException or IOException)
            {
                client.Dispose();
                if (DateTime.UtcNow < deadline) Thread.Sleep(100);
            }
        }
        while (DateTime.UtcNow < deadline);
        return false;
    }

    private void Disconnect()
    {
        try { writer?.Dispose(); } catch (IOException) { }
        reader?.Dispose(); pipe?.Dispose();
        writer = null; reader = null; pipe = null;
    }

    public void Dispose()
    {
        lock (gate) Disconnect();
    }
}
