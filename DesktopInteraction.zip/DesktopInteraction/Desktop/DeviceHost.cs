using System.Diagnostics;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Shared device host: one process per Windows session owns the virtual mouse (USB/IP server + usbip attach, or the
/// ExtedoVirtualMouse driver handle) and serves every Desktop Interaction instance - one per AI client - over a
/// current-user-only named pipe. Instances start it on demand (<c>--device-host usbip|driver</c>, detached, no
/// inherited handles); it exits after <see cref="DefaultIdle"/> without connected instances, so restarting an AI client
/// does not unplug and re-plug the device. Calibration and held-button state live here once for all instances.
/// <para>
/// Each request carries the sender's baton generation (<see cref="SharedControl.Lease"/>). A request from a newer
/// generation first releases buttons still held for the previous owner; a request from an older generation is refused,
/// so a superseded instance can never move the pointer or press a button for the new owner.
/// </para>
/// Protocol: one JSON object per line. Request <c>{"op":"move|button|key|scroll|release|recalibrate|diagnostics","g":gen,...}</c>,
/// response <c>{"ok":true,"r":...}</c> or <c>{"ok":false,"e":"message"}</c>.
/// </summary>
internal static class DeviceHost
{
    internal static readonly TimeSpan DefaultIdle = TimeSpan.FromMinutes(10);

    internal static string PipeName => $"Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Device.{Process.GetCurrentProcess().SessionId}";

    private static string MutexName => @"Local\Extedo.AutoTest.Ai.Mcp.DesktopInteraction.DeviceHost";

    internal static int Run(DesktopOptions options, TimeSpan idle)
    {
        using var single = new Mutex(false, MutexName);
        try { if (!single.WaitOne(0)) return 0; } // another host serves this session
        catch (AbandonedMutexException) { }
        try
        {
            using var device = options.CreateLocalDevice() ?? throw new ArgumentException("--device-host needs usbip or driver.");
            new Server(device, idle, PipeName).Serve();
            return 0;
        }
        finally { single.ReleaseMutex(); }
    }

    internal sealed class Server(IPointerBackend device, TimeSpan idle, string pipeName)
    {
        private readonly object gate = new();
        private readonly Stopwatch uptime = Stopwatch.StartNew();
        private long generation;
        private int clients;
        private long served;
        private long lastClientLeft = Environment.TickCount64;
        private readonly CancellationTokenSource stop = new();

        internal void Stop() => stop.Cancel();

        internal void Serve()
        {
            _ = Task.Run(async () =>
            {
                while (!stop.IsCancellationRequested)
                {
                    await Task.Delay(1000);
                    if (Volatile.Read(ref clients) == 0 && Environment.TickCount64 - Interlocked.Read(ref lastClientLeft) > idle.TotalMilliseconds) stop.Cancel();
                }
            });
            while (!stop.IsCancellationRequested)
            {
                var pipe = new NamedPipeServerStream(pipeName, PipeDirection.InOut, NamedPipeServerStream.MaxAllowedServerInstances,
                    PipeTransmissionMode.Byte, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
                try { pipe.WaitForConnectionAsync(stop.Token).GetAwaiter().GetResult(); }
                catch (OperationCanceledException) { pipe.Dispose(); break; }
                Interlocked.Increment(ref clients);
                _ = Task.Run(() => Client(pipe));
            }
        }

        private void Client(NamedPipeServerStream pipe)
        {
            try
            {
                using (pipe)
                using (var reader = new StreamReader(pipe, new UTF8Encoding(false)))
                using (var writer = new StreamWriter(pipe, new UTF8Encoding(false)) { AutoFlush = true })
                {
                    string? line;
                    while ((line = reader.ReadLine()) is not null) writer.WriteLine(Handle(line));
                }
            }
            catch (IOException) { /* instance closed */ }
            finally
            {
                Interlocked.Exchange(ref lastClientLeft, Environment.TickCount64);
                // All instances gone: their shared baton memory is gone too and a new set starts at generation 1.
                if (Interlocked.Decrement(ref clients) == 0) lock (gate) generation = 0;
            }
        }

        private string Handle(string line)
        {
            try
            {
                var request = JsonNode.Parse(line)!.AsObject();
                string op = (string)request["op"]!;
                long g = (long?)request["g"] ?? 0;
                lock (gate)
                {
                    Interlocked.Increment(ref served);
                    if (op == "diagnostics") return Ok(Diagnostics());
                    if (g < generation) throw new OperationCanceledException("Interaction paused: another Desktop Interaction instance took control of the shared device.");
                    if (g > generation) { generation = g; Release(); } // buttons held for the previous owner
                    switch (op)
                    {
                        case "move": device.MoveTo((int)request["x"]!, (int)request["y"]!); return Ok(null);
                        case "button": device.Button((int)request["mask"]!, (bool)request["down"]!); return Ok(null);
                        case "key": device.Key((int)request["mod"]!, (int)request["usage"]!); return Ok(null);
                        case "scroll": device.Scroll((int)request["delta"]!, (bool)request["horizontal"]!); return Ok(null);
                        case "release": Release(); return Ok(null);
                        case "recalibrate": return Ok(device.Recalibrate((int)request["rx"]!, (int)request["ry"]!, (int)request["ax"]!, (int)request["ay"]!));
                        default: throw new ArgumentException($"Unknown device host operation '{op}'.");
                    }
                }
            }
            catch (Exception e) { return JsonSerializer.Serialize(new { ok = false, e = e.Message, cancelled = e is OperationCanceledException }); }
        }

        /// <summary>Really releases held device buttons (a shared device has no other owner to do it).</summary>
        private void Release()
        {
            if (device is AbsoluteHidBackend hid) hid.ReleaseButtons();
            else device.ForgetButtons();
        }

        private object Diagnostics() => new
        {
            available = device.Available,
            keyboard = device.HasKeyboard,
            details = device.Diagnostics(),
            host = new { pid = Environment.ProcessId, instances = Volatile.Read(ref clients), uptimeS = (long)uptime.Elapsed.TotalSeconds, served = Interlocked.Read(ref served), generation, idleExitMinutes = idle.TotalMinutes },
        };

        private static string Ok(object? result) => JsonSerializer.Serialize(new { ok = true, r = result });
    }

    /// <summary>
    /// Starts the host detached: no inherited handles (it must never hold an AI client's stdio pipes open), no console,
    /// own process group, and out of the client's job when the job allows it (so closing that client does not kill it).
    /// </summary>
    internal static void Launch(string arguments)
    {
        string exe = Environment.ProcessPath ?? throw new InvalidOperationException("Cannot locate the executable to start the device host.");
        var startup = new StartupInfo { Size = Marshal.SizeOf<StartupInfo>() };
        const uint Detached = 0x00000008, NewGroup = 0x00000200, Breakaway = 0x01000000;
        string command = $"\"{exe}\" {arguments}";
        foreach (uint flags in new[] { Detached | NewGroup | Breakaway, Detached | NewGroup })
        {
            if (CreateProcessW(null, new StringBuilder(command), 0, 0, false, flags, 0, Path.GetDirectoryName(exe), ref startup, out var info))
            {
                CloseHandle(info.Process); CloseHandle(info.Thread);
                return;
            }
        }
        throw new InvalidOperationException($"Cannot start the shared device host (error {Marshal.GetLastWin32Error()}).");
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct StartupInfo
    {
        public int Size; public string? Reserved, Desktop, Title;
        public int X, Y, XSize, YSize, XCountChars, YCountChars, FillAttribute, Flags;
        public short ShowWindow, Reserved2; public nint Reserved3, StdInput, StdOutput, StdError;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct ProcessInformation { public nint Process, Thread; public int ProcessId, ThreadId; }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool CreateProcessW(string? application, StringBuilder commandLine, nint processAttributes, nint threadAttributes, bool inheritHandles, uint flags, nint environment, string? directory, ref StartupInfo startup, out ProcessInformation info);

    [DllImport("kernel32.dll")]
    private static extern bool CloseHandle(nint handle);
}
