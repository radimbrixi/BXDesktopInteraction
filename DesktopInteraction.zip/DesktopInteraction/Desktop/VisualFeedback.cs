using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text.Json;
using ModelContextProtocol.Protocol;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>What an action's feedback is anchored to.</summary>
internal enum FeedbackFocus
{
    /// <summary>Mouse actions: the pointer; the limit is the window under it.</summary>
    Pointer,
    /// <summary>Keyboard and focus actions: the text caret (pointer if the app has no Win32 caret); the limit is the foreground window.</summary>
    Keyboard,
}

/// <summary>
/// Forced visual feedback for every action: a PNG of what changed around the anchor (pointer or text caret).
/// The limit is the anchor's window; when there is no usable window (desktop, VM or Remote Desktop viewer whose
/// content has no window information) it is the 100x100 box around the anchor. Inside a window the crop is the
/// bounding box of changed pixels (before vs. after the action) joined with the 100x100 anchor box; when a different
/// window appears at the anchor (menu, dialog) the whole new window is returned.
/// </summary>
internal static class VisualFeedback
{
    internal const int AnchorBox = 100;
    internal const int MaxSide = 1280;       // larger crops are scaled down; metadata reports the scale
    internal const int MinSettleMs = 120;    // first after-capture
    internal const int PollMs = 80;          // then compare consecutive captures until the screen is stable
    internal const int NoChangeWaitMs = 500; // how long to wait for a late reaction before reporting "no change"
    internal const int MaxSettleMs = 9000;   // upper bound while the screen keeps changing (loading, animation, video)
    internal const int Margin = 16;
    internal const int Threshold = 24;       // per-channel difference that counts as a change

    private static readonly HashSet<string> Viewers = new(StringComparer.OrdinalIgnoreCase)
    {
        "vmconnect", "vmware", "vmplayer", "vmware-vmx", "VirtualBoxVM", "mstsc", "msrdc",
    };

    internal sealed record Region(Rectangle Bounds, string Source, nint Handle, string? Title, string? Process);

    internal sealed class Before(Region region, Bitmap? image, Point cursor, string? error, Rectangle? caret = null) : IDisposable
    {
        internal Region Region { get; } = region;
        internal Bitmap? Image { get; } = image;
        internal Point Cursor { get; } = cursor;
        internal string? Error { get; } = error;
        internal Rectangle? Caret { get; } = caret;
        public void Dispose() => Image?.Dispose();
    }

    /// <summary>Captures the region the action is expected to affect (the move/drag target, or the current anchor).</summary>
    internal static Before Begin(FeedbackFocus focus, Point? expected)
    {
        var cursor = Cursor();
        try
        {
            // An invalid target (outside the desktop) will be rejected: the pointer stays, so watch where it is.
            var target = expected is { } e && SystemInformation.VirtualScreen.Contains(e) ? e : cursor;
            var region = focus == FeedbackFocus.Pointer ? RegionAt(target) : KeyboardRegion();
            return new Before(region, Snapshot(region.Bounds), cursor, null, WindowNative.CaretRect(Native.GetForegroundWindow()));
        }
        catch (Exception e) { return new Before(new Region(Rectangle.Empty, "none", 0, null, null), null, cursor, e.Message); }
    }

    /// <summary>Text result followed by the feedback PNG. Never throws: capture problems are reported in the text.</summary>
    internal static List<ContentBlock> Complete(Before before, FeedbackFocus focus, object result, string tool = "action", FeedbackTiming? timing = null)
    {
        try
        {
            var clock = System.Diagnostics.Stopwatch.StartNew();
            Thread.Sleep(MinSettleMs);
            var cursor = Cursor();
            var (region, anchor) = focus == FeedbackFocus.Pointer ? (RegionAt(cursor), cursor) : KeyboardRegionAndAnchor(cursor);
            bool sameRegion = before.Image is not null && before.Region.Bounds == region.Bounds && before.Region.Handle == region.Handle;
            using var after = Settle(before, region, sameRegion, clock, ref cursor, timing ?? FeedbackTiming.Normal);
            int settledMs = (int)clock.ElapsedMilliseconds;
            Remember(tool, region, after);
            Rectangle crop; bool changed; string basis;

            if (region.Source != "window")
            {
                crop = new Rectangle(Point.Empty, region.Bounds.Size);
                changed = sameRegion && ChangedBounds(before.Image!, after, Ignored(region.Bounds, before, cursor)) is not null;
                basis = $"{AnchorBox}x{AnchorBox} box around the {(focus == FeedbackFocus.Pointer ? "pointer" : "caret")} ({region.Source})";
            }
            else if (!sameRegion)
            {
                crop = new Rectangle(Point.Empty, region.Bounds.Size);
                changed = true;
                basis = "whole window: a different or moved window is at the anchor";
            }
            else
            {
                var anchorBox = Rectangle.Intersect(Box(anchor, region.Bounds), region.Bounds);
                anchorBox.Offset(-region.Bounds.X, -region.Bounds.Y);
                var diff = ChangedBounds(before.Image!, after, Ignored(region.Bounds, before, cursor));
                changed = diff is not null;
                crop = diff is { } d ? Rectangle.Union(Expand(d, Margin, after.Size), anchorBox) : anchorBox;
                basis = changed ? "changed area and anchor box within the window" : "no change detected: anchor box within the window";
            }

            using var image = Render(after, crop, new Point(cursor.X - region.Bounds.X, cursor.Y - region.Bounds.Y), out double scale);
            using var png = new MemoryStream();
            image.Save(png, ImageFormat.Png);
            var bounds = new Rectangle(region.Bounds.X + crop.X, region.Bounds.Y + crop.Y, crop.Width, crop.Height);
            var text = JsonSerializer.Serialize(new
            {
                result,
                feedback = new
                {
                    region = new { x = bounds.X, y = bounds.Y, width = bounds.Width, height = bounds.Height },
                    scale, mapping = "desktop = (region.x + u / scale, region.y + v / scale)",
                    changed, basis, settledMs, timing = (timing ?? FeedbackTiming.Normal).Name, source = region.Source, window = region.Title, process = region.Process,
                    anchor = new { x = anchor.X, y = anchor.Y, kind = focus == FeedbackFocus.Pointer ? "pointer" : anchor == cursor ? "pointer (no Win32 caret)" : "caret" },
                    beforeCaptureError = before.Error,
                },
            });
            return [new TextContentBlock { Text = text }, ImageContentBlock.FromBytes(png.ToArray(), "image/png")];
        }
        catch (Exception e)
        {
            return [new TextContentBlock { Text = JsonSerializer.Serialize(new { result, feedback = new { error = "Visual feedback unavailable: " + e.Message } }) }];
        }
    }

    /// <summary>
    /// How long feedback waits. <see cref="Normal"/>: up to 500 ms for a reaction, then until two captures in a
    /// row are equal. <see cref="Lazy"/>: up to the given time for a first reaction, then until the area has been quiet
    /// for 1 s (a progress bar or spinner replaced by content is captured as the final content). Either way at most
    /// <see cref="MaxSettleMs"/> after the first change (continuous animation, video).
    /// </summary>
    internal readonly record struct FeedbackTiming(string Name, int NoChangeWaitMs, int QuietMs, int MaxAfterChangeMs)
    {
        internal static readonly FeedbackTiming Normal = new("normal", VisualFeedback.NoChangeWaitMs, PollMs, MaxSettleMs);
        internal static FeedbackTiming Lazy(int waitMs) => new($"lazy (waits up to {waitMs} ms for a reaction)", waitMs, 1000, MaxSettleMs);
    }

    /// <summary>
    /// Waits until the screen has reacted and settled instead of trusting a fixed delay: apps render late (Electron,
    /// browsers), animate scrolling and load lazily. See <see cref="FeedbackTiming"/>.
    /// </summary>
    private static Bitmap Settle(Before before, Region region, bool sameRegion, System.Diagnostics.Stopwatch clock, ref Point cursor, FeedbackTiming timing)
    {
        var after = Snapshot(region.Bounds);
        Bitmap? previous = null;
        long firstChange = -1, lastMotion = clock.ElapsedMilliseconds;
        try
        {
            while (true)
            {
                long now = clock.ElapsedMilliseconds;
                var ignore = Ignored(region.Bounds, before, cursor);
                bool changed = !sameRegion || ChangedBounds(before.Image!, after, ignore) is not null;
                if (changed && firstChange < 0) firstChange = now;
                if (previous is null || ChangedBounds(previous, after, ignore) is not null) lastMotion = now;
                if (changed && previous is not null && now - lastMotion >= timing.QuietMs) break;      // reacted and quiet
                if (!changed && now >= timing.NoChangeWaitMs) break;                                    // no reaction in time
                if (changed && now - firstChange >= timing.MaxAfterChangeMs) break;                     // keeps changing
                previous?.Dispose();
                previous = after;
                Thread.Sleep(PollMs);
                cursor = Cursor();
                after = Snapshot(region.Bounds);
            }
            return after;
        }
        finally { previous?.Dispose(); }
    }

    /// <summary>A quick action shows no feedback: forget the previous baseline, so its effect is not reported later as a late change.</summary>
    internal static void Forget() { lock (lateGate) { baseline?.Dispose(); baseline = null; } }

    // ---- Late changes (lazy loading, late rendering) -------------------------------------------------------------

    private static readonly object lateGate = new();
    private static LateBaseline? baseline;

    private sealed class LateBaseline(string tool, Region region, Bitmap image, Rectangle? caret) : IDisposable
    {
        internal string Tool { get; } = tool;
        internal Region Region { get; } = region;
        internal Bitmap Image { get; set; } = image;
        internal Rectangle? Caret { get; set; } = caret;
        internal System.Diagnostics.Stopwatch Since { get; set; } = System.Diagnostics.Stopwatch.StartNew();
        public void Dispose() => Image.Dispose();
    }

    /// <summary>Keeps the settled state the model was just shown, to report later changes in the same area.</summary>
    private static void Remember(string tool, Region region, Bitmap settled)
    {
        var copy = settled.Clone(new Rectangle(Point.Empty, settled.Size), PixelFormat.Format32bppArgb);
        lock (lateGate)
        {
            baseline?.Dispose();
            baseline = new LateBaseline(tool, region, copy, WindowNative.CaretRect(Native.GetForegroundWindow()));
        }
    }

    /// <summary>
    /// Late-change section for the current tool result: compares the area of the previous action's feedback with
    /// how it looks now. When it changed (lazy loading, content rendered after a progress bar, a dialog that came
    /// later) the section has a text block and a crop of the changed part; otherwise one short text line. Read-only
    /// tools keep watching from the new state (<paramref name="rebase"/>), so the same change is reported once.
    /// Never throws.
    /// </summary>
    internal static List<ContentBlock> CollectLate(bool rebase)
    {
        lock (lateGate)
        {
            if (baseline is not { } b) return [];
            try
            {
                double seconds = Math.Round(b.Since.Elapsed.TotalSeconds, 1);
                using var now = Snapshot(b.Region.Bounds);
                var caretNow = WindowNative.CaretRect(Native.GetForegroundWindow());
                var ignore = CaretMasks(b.Region.Bounds, b.Caret, caretNow);
                var diff = ChangedBounds(b.Image, now, ignore);
                if (diff is null)
                {
                    if (!rebase) { b.Dispose(); baseline = null; }
                    return [new TextContentBlock { Text = JsonSerializer.Serialize(new { lateChange = new { since = b.Tool, secondsAgo = seconds, changed = false } }) }];
                }

                // Still changing? One more look shortly after.
                Thread.Sleep(PollMs);
                using var again = Snapshot(b.Region.Bounds);
                bool settled = ChangedBounds(now, again, ignore) is null;
                var latest = settled ? now : again;
                diff = ChangedBounds(b.Image, latest, ignore) ?? diff;

                var crop = Expand(diff.Value, Margin, latest.Size);
                var cursor = Cursor();
                using var image = Render(latest, crop, new Point(cursor.X - b.Region.Bounds.X, cursor.Y - b.Region.Bounds.Y), out double scale);
                using var png = new MemoryStream();
                image.Save(png, ImageFormat.Png);
                var bounds = new Rectangle(b.Region.Bounds.X + crop.X, b.Region.Bounds.Y + crop.Y, crop.Width, crop.Height);
                var text = JsonSerializer.Serialize(new
                {
                    lateChange = new
                    {
                        since = b.Tool, secondsAgo = seconds, changed = true, settled,
                        note = $"The area shown in the feedback of {b.Tool} changed after that result was returned (lazy loading, late rendering, a later dialog). The image shows the changed part as it is now.",
                        region = new { x = bounds.X, y = bounds.Y, width = bounds.Width, height = bounds.Height },
                        scale, mapping = "desktop = (region.x + u / scale, region.y + v / scale)",
                        window = b.Region.Title, source = b.Region.Source,
                    },
                });

                if (rebase) { b.Image.Dispose(); b.Image = latest.Clone(new Rectangle(Point.Empty, latest.Size), PixelFormat.Format32bppArgb); b.Caret = caretNow; b.Since.Restart(); }
                else { b.Dispose(); baseline = null; }
                return [new TextContentBlock { Text = text }, ImageContentBlock.FromBytes(png.ToArray(), "image/png")];
            }
            catch (Exception e)
            {
                return [new TextContentBlock { Text = JsonSerializer.Serialize(new { lateChange = new { error = "Late-change check unavailable: " + e.Message } }) }];
            }
        }
    }

    private static Rectangle[] CaretMasks(Rectangle region, params Rectangle?[] carets)
    {
        var list = new List<Rectangle>();
        foreach (var caret in carets)
            if (caret is { } c) { var r = Rectangle.Inflate(c, 3, 3); r.Offset(-region.X, -region.Y); list.Add(r); }
        return [.. list];
    }
    /// <summary>The top-level window under the point, or the anchor box when there is no usable window.</summary>
    internal static Region RegionAt(Point p) => FromWindow(TopWindowAt(p), p);

    private static Region KeyboardRegion() => KeyboardRegionAndAnchor(Cursor()).Region;

    private static Point Cursor() { Native.GetCursorPos(out var p); return new Point(p.X, p.Y); }

    private static (Region Region, Point Anchor) KeyboardRegionAndAnchor(Point cursor)
    {
        var foreground = Native.GetForegroundWindow();
        var anchor = (foreground != 0 ? WindowNative.CaretPosition(foreground) : null) ?? cursor;
        return (FromWindow(foreground, anchor), anchor);
    }

    private static Region FromWindow(nint window, Point anchor)
    {
        if (window == 0) return AnchorRegion(anchor, "no window");
        string cls = WindowNative.ClassName(window);
        if (cls is "Progman" or "WorkerW") return AnchorRegion(anchor, "desktop");
        string process = WindowNative.ProcessName(window);
        if (Viewers.Contains(process)) return AnchorRegion(anchor, $"{process}: VM/remote viewer, no window information inside");
        var screen = Screen.FromPoint(anchor).Bounds;
        var bounds = Rectangle.Intersect(Rectangle.Intersect(WindowNative.Bounds(window), screen), SystemInformation.VirtualScreen);
        if (bounds.Width < 1 || bounds.Height < 1) return AnchorRegion(anchor, "window not visible on this monitor");
        return new Region(bounds, "window", window, Title(window), process);
    }

    private static Region AnchorRegion(Point anchor, string reason) => new(Box(anchor, Screen.FromPoint(anchor).Bounds), reason, 0, null, null);

    /// <summary>100x100 box centred on the point, shifted (not cut) to stay inside the given area.</summary>
    internal static Rectangle Box(Point p, Rectangle area)
    {
        int w = Math.Min(AnchorBox, area.Width), h = Math.Min(AnchorBox, area.Height);
        int x = Math.Clamp(p.X - w / 2, area.Left, area.Right - w), y = Math.Clamp(p.Y - h / 2, area.Top, area.Bottom - h);
        return new Rectangle(x, y, w, h);
    }

    /// <summary>Topmost visible, uncloaked, non-click-through window that contains the point (Z order). The cursor marker overlay is click-through.</summary>
    private static nint TopWindowAt(Point p)
    {
        nint found = 0;
        Native.EnumWindows((hWnd, _) =>
        {
            if (!Native.IsWindowVisible(hWnd) || WindowNative.IsIconic(hWnd) || WindowNative.IsCloaked(hWnd) || WindowNative.IsClickThrough(hWnd)) return true;

            if (!WindowNative.Bounds(hWnd).Contains(p)) return true;
            found = hWnd;
            return false;
        }, 0);
        return found;
    }

    private static string Title(nint hWnd)
    {
        int length = Native.GetWindowTextLength(hWnd);
        if (length == 0) return "";
        var text = new System.Text.StringBuilder(length + 1);
        Native.GetWindowText(hWnd, text, text.Capacity);
        return text.ToString();
    }

    private static Bitmap Snapshot(Rectangle r)
    {
        var bitmap = new Bitmap(r.Width, r.Height, PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(bitmap);
        g.CopyFromScreen(r.Location, Point.Empty, r.Size, CopyPixelOperation.SourceCopy);
        return bitmap;
    }

    /// <summary>Areas that change by themselves and must not count: the blinking text caret (before and now). The cursor marker overlay is not part of screen captures (it is drawn into the feedback image afterwards), so it needs no mask.</summary>
    private static Rectangle[] Ignored(Rectangle region, Before before, Point cursor)
    {
        var list = new List<Rectangle>();
        foreach (var caret in new[] { before.Caret, WindowNative.CaretRect(Native.GetForegroundWindow()) })
            if (caret is { } c) { var r = Rectangle.Inflate(c, 3, 3); r.Offset(-region.X, -region.Y); list.Add(r); }
        return [.. list];
    }



    /// <summary>Bounding box (image coordinates) of pixels that differ by more than <see cref="Threshold"/>, ignoring the given rectangles.</summary>
    internal static Rectangle? ChangedBounds(Bitmap before, Bitmap after, IReadOnlyList<Rectangle> ignore)
    {
        if (before.Size != after.Size) return new Rectangle(Point.Empty, after.Size);
        int w = after.Width, h = after.Height;
        var a = Pixels(before); var b = Pixels(after);
        int left = w, top = h, right = -1, bottom = -1;
        for (int y = 0; y < h; y++)
        {
            int row = y * w;
            for (int x = 0; x < w; x++)
            {
                int pa = a[row + x], pb = b[row + x];
                if (pa == pb) continue;
                if (Math.Abs((pa & 0xFF) - (pb & 0xFF)) <= Threshold && Math.Abs((pa >> 8 & 0xFF) - (pb >> 8 & 0xFF)) <= Threshold && Math.Abs((pa >> 16 & 0xFF) - (pb >> 16 & 0xFF)) <= Threshold) continue;
                bool skip = false;
                foreach (var r in ignore) if (r.Contains(x, y)) { skip = true; break; }
                if (skip) continue;
                if (x < left) left = x; if (x > right) right = x;
                if (y < top) top = y; if (y > bottom) bottom = y;
            }
        }
        return right < 0 ? null : Rectangle.FromLTRB(left, top, right + 1, bottom + 1);
    }

    private static int[] Pixels(Bitmap bitmap)
    {
        var data = bitmap.LockBits(new Rectangle(Point.Empty, bitmap.Size), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try
        {
            var pixels = new int[bitmap.Width * bitmap.Height];
            for (int y = 0; y < bitmap.Height; y++) Marshal.Copy(data.Scan0 + y * data.Stride, pixels, y * bitmap.Width, bitmap.Width);
            return pixels;
        }
        finally { bitmap.UnlockBits(data); }
    }

    internal static Rectangle Expand(Rectangle r, int margin, Size limit) =>
        Rectangle.Intersect(Rectangle.FromLTRB(r.Left - margin, r.Top - margin, r.Right + margin, r.Bottom + margin), new Rectangle(Point.Empty, limit));

    /// <summary>Crop, composite the cursor marker, and scale down so the longest side is at most <see cref="MaxSide"/>.</summary>
    private static Bitmap Render(Bitmap source, Rectangle crop, Point cursor, out double scale)
    {
        scale = Math.Min(1.0, MaxSide / (double)Math.Max(crop.Width, crop.Height));
        int w = Math.Max(1, (int)Math.Round(crop.Width * scale)), h = Math.Max(1, (int)Math.Round(crop.Height * scale));
        var image = new Bitmap(w, h, PixelFormat.Format32bppArgb);
        using var g = Graphics.FromImage(image);
        g.InterpolationMode = scale < 1 ? InterpolationMode.HighQualityBicubic : InterpolationMode.NearestNeighbor;
        g.DrawImage(source, new Rectangle(0, 0, w, h), crop, GraphicsUnit.Pixel);
        if (crop.Contains(cursor))
        {
            g.ResetTransform();
            CursorOverlay.PaintMarker(g, (int)Math.Round((cursor.X - crop.X) * scale), (int)Math.Round((cursor.Y - crop.Y) * scale));
        }
        scale = Math.Round(scale, 4);
        return image;
    }
}
