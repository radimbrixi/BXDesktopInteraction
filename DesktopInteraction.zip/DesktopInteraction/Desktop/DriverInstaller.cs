using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using Microsoft.Win32;
using Microsoft.Win32.SafeHandles;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Creates/removes the root-enumerated Root\ExtedoVirtualMouse device and its driver package
/// (what devcon install/remove does), so tester machines need no WDK. Requires an elevated process.
/// </summary>
internal static class DriverInstaller
{
    internal const string HardwareId = @"Root\ExtedoVirtualMouse";

    internal static int Install(string infPath)
    {
        RequireAdministrator();
        string inf = Path.GetFullPath(infPath);
        if (!File.Exists(inf)) throw new FileNotFoundException("INF not found.", inf);

        if (FindDevices().Count == 0)
        {
            var className = new StringBuilder(256);
            if (!SetupDiGetINFClass(inf, out var classGuid, className, className.Capacity, out _)) throw Error("Cannot read the INF class.");
            nint set = SetupDiCreateDeviceInfoList(ref classGuid, 0);
            if (set == -1) throw Error("Cannot create a device information set.");
            try
            {
                var data = new SpDevInfoData { Size = (uint)Marshal.SizeOf<SpDevInfoData>() };
                if (!SetupDiCreateDeviceInfo(set, className.ToString(), ref classGuid, null, 0, 1 /* DICD_GENERATE_ID */, ref data)) throw Error("Cannot create the device node.");
                byte[] ids = Encoding.Unicode.GetBytes(HardwareId + "\0\0");
                if (!SetupDiSetDeviceRegistryProperty(set, ref data, 1 /* SPDRP_HARDWAREID */, ids, (uint)ids.Length)) throw Error("Cannot set the hardware ID.");
                if (!SetupDiCallClassInstaller(0x19 /* DIF_REGISTERDEVICE */, set, ref data)) throw Error("Cannot register the device node.");
            }
            finally { SetupDiDestroyDeviceInfoList(set); }
            Console.WriteLine($"Created device node {HardwareId}.");
        }

        if (!UpdateDriverForPlugAndPlayDevices(0, HardwareId, inf, 1 /* INSTALLFLAG_FORCE */, out bool reboot))
            throw Error("Driver installation failed. On a test VM check that test signing is on and the test certificate is trusted (DRIVER.md).");
        Console.WriteLine($"Installed {Path.GetFileName(inf)} for {HardwareId}." + (reboot ? " A reboot is required." : ""));
        return 0;
    }

    internal static int Uninstall()
    {
        RequireAdministrator();
        var removed = 0;
        var packages = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        nint set = SetupDiGetClassDevs(0, null, 0, 0x4 /* DIGCF_ALLCLASSES */);
        if (set == -1) throw Error("Cannot enumerate devices.");
        try
        {
            foreach (var data in Enumerate(set).Where(d => HasHardwareId(set, d)).ToList())
            {
                var device = data;
                if (InfPath(set, device) is { } oem) packages.Add(oem);
                if (!DiUninstallDevice(0, set, ref device, 0, out _)) throw Error("Cannot remove the device.");
                removed++;
            }
        }
        finally { SetupDiDestroyDeviceInfoList(set); }

        foreach (var oem in packages)
        {
            if (SetupUninstallOEMInf(oem, 1 /* SUOI_FORCEDELETE */, 0)) Console.WriteLine($"Removed driver package {oem}.");
            else Console.Error.WriteLine($"Could not remove driver package {oem}: {new Win32Exception(Marshal.GetLastWin32Error()).Message}");
        }
        Console.WriteLine($"Removed {removed} {HardwareId} device(s).");
        return 0;
    }

    private static List<SpDevInfoData> FindDevices()
    {
        nint set = SetupDiGetClassDevs(0, null, 0, 0x4);
        if (set == -1) throw Error("Cannot enumerate devices.");
        try { return Enumerate(set).Where(d => HasHardwareId(set, d)).ToList(); }
        finally { SetupDiDestroyDeviceInfoList(set); }
    }

    private static IEnumerable<SpDevInfoData> Enumerate(nint set)
    {
        for (uint i = 0; ; i++)
        {
            var data = new SpDevInfoData { Size = (uint)Marshal.SizeOf<SpDevInfoData>() };
            if (!SetupDiEnumDeviceInfo(set, i, ref data)) yield break;
            yield return data;
        }
    }

    private static bool HasHardwareId(nint set, SpDevInfoData data)
    {
        var buffer = new byte[2048];
        if (!SetupDiGetDeviceRegistryProperty(set, ref data, 1, out _, buffer, (uint)buffer.Length, out uint size)) return false;
        return Encoding.Unicode.GetString(buffer, 0, (int)size).Split('\0').Any(id => id.Equals(HardwareId, StringComparison.OrdinalIgnoreCase));
    }

    private static string? InfPath(nint set, SpDevInfoData data)
    {
        nint key = SetupDiOpenDevRegKey(set, ref data, 1 /* DICS_FLAG_GLOBAL */, 0, 2 /* DIREG_DRV */, 0x20019 /* KEY_READ */);
        if (key == -1) return null;
        using var handle = new SafeRegistryHandle(key, ownsHandle: true);
        using var registry = RegistryKey.FromHandle(handle);
        return registry.GetValue("InfPath") as string;
    }

    internal static void RequireAdministrator()
    {
        using var identity = WindowsIdentity.GetCurrent();
        if (!new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator))
            throw new UnauthorizedAccessException("Run from an elevated (Administrator) prompt.");
    }

    private static Win32Exception Error(string message)
    {
        int code = Marshal.GetLastWin32Error();
        return new Win32Exception(code, $"{message} ({new Win32Exception(code).Message}, 0x{code:X8})");
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SpDevInfoData { public uint Size; public Guid ClassGuid; public uint DevInst; public nint Reserved; }

    [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "SetupDiGetINFClassW")]
    private static extern bool SetupDiGetINFClass(string inf, out Guid classGuid, StringBuilder className, int size, out int required);
    [DllImport("setupapi.dll", SetLastError = true)]
    private static extern nint SetupDiCreateDeviceInfoList(ref Guid classGuid, nint parent);
    [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "SetupDiCreateDeviceInfoW")]
    private static extern bool SetupDiCreateDeviceInfo(nint set, string name, ref Guid classGuid, string? description, nint parent, uint flags, ref SpDevInfoData data);
    [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "SetupDiSetDeviceRegistryPropertyW")]
    private static extern bool SetupDiSetDeviceRegistryProperty(nint set, ref SpDevInfoData data, uint property, byte[] buffer, uint size);
    [DllImport("setupapi.dll", SetLastError = true)]
    private static extern bool SetupDiCallClassInstaller(uint function, nint set, ref SpDevInfoData data);
    [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "SetupDiGetClassDevsW")]
    private static extern nint SetupDiGetClassDevs(nint classGuid, string? enumerator, nint parent, uint flags);
    [DllImport("setupapi.dll", SetLastError = true)]
    private static extern bool SetupDiEnumDeviceInfo(nint set, uint index, ref SpDevInfoData data);
    [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "SetupDiGetDeviceRegistryPropertyW")]
    private static extern bool SetupDiGetDeviceRegistryProperty(nint set, ref SpDevInfoData data, uint property, out uint type, byte[] buffer, uint size, out uint required);
    [DllImport("setupapi.dll", SetLastError = true)]
    private static extern nint SetupDiOpenDevRegKey(nint set, ref SpDevInfoData data, uint scope, uint profile, uint keyType, int access);
    [DllImport("setupapi.dll", SetLastError = true)]
    private static extern bool SetupDiDestroyDeviceInfoList(nint set);
    [DllImport("setupapi.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "SetupUninstallOEMInfW")]
    private static extern bool SetupUninstallOEMInf(string inf, uint flags, nint reserved);
    [DllImport("newdev.dll", CharSet = CharSet.Unicode, SetLastError = true, EntryPoint = "UpdateDriverForPlugAndPlayDevicesW")]
    private static extern bool UpdateDriverForPlugAndPlayDevices(nint parent, string hardwareId, string infPath, uint flags, out bool reboot);
    [DllImport("newdev.dll", SetLastError = true)]
    private static extern bool DiUninstallDevice(nint parent, nint set, ref SpDevInfoData data, uint flags, out bool reboot);
}
