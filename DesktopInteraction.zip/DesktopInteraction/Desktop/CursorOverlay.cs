using System.Drawing.Drawing2D;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Cyan cursor marker that follows the pointer while this instance drives it (an input action is running or ended
/// less than <see cref="LingerMs"/> ago), plus a label with the driving AI client's name placed more than 100 px
/// below and right of the pointer (flipped at screen edges) so it stays clear of what the pointer points at.
/// Idle or paused instances show nothing. Also hosts the emergency hotkey and raw-input user-activity detection.
/// </summary>
internal sealed class CursorOverlay : Form
{
    internal const int LingerMs = 1500;
    internal const int LabelOffset = 112;
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 16 };
    private readonly NotifyIcon tray;
    internal SharedControl Control { get; } = new();
    internal UserActivity Activity { get; }
    private readonly CursorLabel label = new();
    /// <summary>True while this instance is driving the pointer; null = always (demo).</summary>
    internal Func<bool>? Driving;
    /// <summary>Name of the AI client driving this instance (MCP clientInfo.name).</summary>
    internal string? ClientName;
    private bool shown;
    /// <summary>Blue frame around all monitors (null = off); shown while <see cref="Framing"/> is true.</summary>
    internal ScreenFrame? Frame;
    /// <summary>True while the frame should be shown; null = always (demo).</summary>
    internal Func<bool>? Framing;
    private long lastTick = Environment.TickCount64;
    internal bool Stopped => Control.Stopped;
    private bool hotkeyRegistered;
    private long nextHotkeyAttempt;
    internal Action? EmergencyStop;
    internal bool MarkerEnabled = true;
    internal CursorOverlay()
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        BackColor = Color.Magenta;
        TransparencyKey = Color.Magenta;
        Size = new(40, 48);
        DoubleBuffered = true;
        Activity = new UserActivity(Control);
        var menu = new ContextMenuStrip();
        menu.Items.Add("Show/hide cursor marker", null, (_, _) => { MarkerEnabled = !MarkerEnabled; Invalidate(); });
        menu.Items.Add("Stop all Desktop Interaction instances and exit", null, (_, _) => { Control.Stop(); EmergencyStop?.Invoke(); Close(); });
        tray = new NotifyIcon { Icon = SystemIcons.Application, Text = "Extedo Desktop Interaction - Ctrl+Alt+F12 stops", ContextMenuStrip = menu, Visible = true };
        timer.Tick += (_, _) =>
        {
            RegisterEmergencyHotkey();
            if (!Control.Active || Control.Stopped) EmergencyStop?.Invoke();
            bool show = MarkerEnabled && !Control.Stopped && (Driving?.Invoke() ?? true);
            if (show && Native.GetCursorPos(out var p))
            {
                Location = new(p.X - 6, p.Y - 6);
                label.Place(new Point(p.X, p.Y), ClientName ?? "AI");
            }
            else if (label.Visible) label.Hide();
            if (show != shown || show) { shown = show; Invalidate(); }
            long now = Environment.TickCount64;
            Frame?.Tick(!Control.Stopped && (Framing?.Invoke() ?? true), Math.Min(100, now - lastTick), ClientName);
            lastTick = now;
        };
        Shown += (_, _) =>
        {
            RegisterEmergencyHotkey();
            timer.Start();
        };
    }
    private void RegisterEmergencyHotkey()
    {
        if (hotkeyRegistered || Environment.TickCount64 < nextHotkeyAttempt) return;
        nextHotkeyAttempt = Environment.TickCount64 + 500;
        if (Native.RegisterHotKey(Handle, 1, 0x4000 | 0x0002 | 0x0001, 0x7B))
        {
            hotkeyRegistered = true;
            Control.HotkeyRegistered();
        }
        // Another compatible instance can own the session's hotkey. No stop is latched.
    }
    protected override bool ShowWithoutActivation => true;
    protected override CreateParams CreateParams
    {
        get { var p = base.CreateParams; p.ExStyle |= 0x00080000 | 0x00000020 | 0x00000080 | 0x08000000; return p; }
    }
    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        Activity.Register(Handle);
    }
    protected override void WndProc(ref Message m)
    {
        Activity.Handle(ref m);
        if (m.Msg == 0x0312) { Control.Stop(); EmergencyStop?.Invoke(); }
        if (m.Msg == 0x0084) { m.Result = -1; return; }
        base.WndProc(ref m);
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        if (shown) PaintMarker(e.Graphics, 6, 6);
    }
    internal static void PaintMarker(Graphics g, int x, int y)
    {
        g.SmoothingMode = SmoothingMode.AntiAlias;
        Point[] points = [new(x, y), new(x + 2, y + 26), new(x + 9, y + 19), new(x + 15, y + 31), new(x + 21, y + 28), new(x + 15, y + 17), new(x + 26, y + 16)];
        using var fill = new SolidBrush(Color.FromArgb(255, 0, 210, 255));
        using var outline = new Pen(Color.FromArgb(255, 12, 35, 55), 2);
        g.FillPolygon(fill, points);
        g.DrawPolygon(outline, points);
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) { timer.Dispose(); label.Dispose(); Frame?.Dispose(); tray.Visible = false; tray.ContextMenuStrip?.Dispose(); tray.Dispose(); if (hotkeyRegistered) { Native.UnregisterHotKey(Handle, 1); Control.HotkeyReleased(); hotkeyRegistered = false; } Control.Dispose(); }
        base.Dispose(disposing);
    }
}

/// <summary>Click-through, non-activating pill with the driving client's name, offset from the pointer.</summary>
internal sealed class CursorLabel : Form
{
    private static readonly Color Fill = Color.FromArgb(0, 210, 255), Ink = Color.FromArgb(12, 35, 55);
    private string text = "";
    private readonly Font font = new("Segoe UI", 9f, FontStyle.Bold);

    internal CursorLabel()
    {
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        BackColor = Fill;
        Opacity = 0.9;
        StartPosition = FormStartPosition.Manual;
    }

    /// <summary>Shows the label more than 100 px below and right of the pointer; flips left/up at the monitor edge.</summary>
    internal void Place(Point pointer, string name)
    {
        if (name != text)
        {
            text = name;
            var size = TextRenderer.MeasureText(text, font);
            Size = new(size.Width + 16, size.Height + 8);
            using var path = Rounded(new Rectangle(Point.Empty, Size), Height / 2);
            Region = new Region(path);
            Invalidate();
        }
        var area = Screen.FromPoint(pointer).Bounds;
        int x = pointer.X + CursorOverlay.LabelOffset, y = pointer.Y + CursorOverlay.LabelOffset;
        if (x + Width > area.Right) x = pointer.X - CursorOverlay.LabelOffset - Width;
        if (y + Height > area.Bottom) y = pointer.Y - CursorOverlay.LabelOffset - Height;
        Location = new(x, y);
        if (!Visible) Show();
    }

    private static System.Drawing.Drawing2D.GraphicsPath Rounded(Rectangle r, int radius)
    {
        var path = new System.Drawing.Drawing2D.GraphicsPath();
        int d = radius * 2;
        path.AddArc(r.X, r.Y, d, d, 180, 90);
        path.AddArc(r.Right - d, r.Y, d, d, 270, 90);
        path.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
        path.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }

    protected override bool ShowWithoutActivation => true;
    protected override CreateParams CreateParams
    {
        get { var p = base.CreateParams; p.ExStyle |= 0x00080000 | 0x00000020 | 0x00000080 | 0x08000000; return p; }
    }
    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0084) { m.Result = -1; return; }
        base.WndProc(ref m);
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        TextRenderer.DrawText(e.Graphics, text, font, ClientRectangle, Ink, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) font.Dispose();
        base.Dispose(disposing);
    }
}
