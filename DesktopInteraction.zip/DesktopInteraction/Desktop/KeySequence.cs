using System.Runtime.InteropServices;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>A named key: HID usage (device keyboard), virtual key and extended flag (SendInput).</summary>
internal sealed record SpecialKey(string Name, int Usage, ushort VirtualKey, bool Extended, int ExtraModifiers = 0);

/// <summary>One key press: modifiers (<see cref="KeySequence.Ctrl"/> ...) and either a named key or a character.</summary>
internal sealed record KeyStroke(int Modifiers, SpecialKey? Key, char Character)
{
    public override string ToString()
    {
        var parts = new List<string>();
        if ((Modifiers & KeySequence.Ctrl) != 0) parts.Add("Ctrl");
        if ((Modifiers & KeySequence.Alt) != 0) parts.Add("Alt");
        if ((Modifiers & KeySequence.Shift) != 0) parts.Add("Shift");
        if ((Modifiers & KeySequence.Win) != 0) parts.Add("Win");
        parts.Add(Key?.Name ?? (Character == ' ' ? "Space" : Character.ToString()));
        return string.Join('+', parts);
    }
}

/// <summary>
/// Parses key sequences in the syntax of Windows Forms <c>SendKeys</c>
/// (https://learn.microsoft.com/dotnet/api/system.windows.forms.sendkeys):
/// characters press their key; <c>+</c> Shift, <c>^</c> Ctrl, <c>%</c> Alt apply to the next key or to a group
/// <c>(...)</c>; <c>~</c> is Enter; <c>{NAME}</c> names a key (<c>{ENTER}</c>, <c>{ESC}</c>, <c>{F5}</c>, ...),
/// <c>{NAME n}</c> repeats it, <c>{+}</c> <c>{^}</c> <c>{%}</c> <c>{~}</c> <c>{(}</c> <c>{)}</c> <c>{{}</c>
/// <c>{}}</c> <c>{[}</c> <c>{]}</c> are literal characters. Extensions: <c>#</c> = Windows key modifier (like
/// AutoHotkey, literal <c>{#}</c>), <c>{WIN}</c>/<c>{LWIN}</c>/<c>{RWIN}</c>, <c>{APPS}</c> (context menu key),
/// <c>{SPACE}</c>, <c>{F17}</c>-<c>{F24}</c>.
/// </summary>
internal static class KeySequence
{
    internal const int Ctrl = 1, Shift = 2, Alt = 4, Win = 8; // same bits as the HID left modifiers
    internal const int MaxStrokes = 500, MaxRepeat = 100;

    private static readonly Dictionary<string, SpecialKey> Keys = BuildKeys();

    internal static IReadOnlyCollection<string> KeyNames => Keys.Keys;

    private static Dictionary<string, SpecialKey> BuildKeys()
    {
        var keys = new Dictionary<string, SpecialKey>(StringComparer.OrdinalIgnoreCase);
        void Add(SpecialKey key, params string[] names) { foreach (var name in names) keys[name] = key; }
        Add(new("Enter", 0x28, 0x0D, false), "ENTER");
        Add(new("Escape", 0x29, 0x1B, false), "ESC", "ESCAPE");
        Add(new("Backspace", 0x2A, 0x08, false), "BACKSPACE", "BS", "BKSP");
        Add(new("Tab", 0x2B, 0x09, false), "TAB");
        Add(new("Space", 0x2C, 0x20, false), "SPACE");
        Add(new("CapsLock", 0x39, 0x14, false), "CAPSLOCK");
        Add(new("PrintScreen", 0x46, 0x2C, true), "PRTSC");
        Add(new("ScrollLock", 0x47, 0x91, false), "SCROLLLOCK");
        Add(new("Break", 0x48, 0x03, true, Ctrl), "BREAK"); // Ctrl+Pause on a keyboard
        Add(new("Insert", 0x49, 0x2D, true), "INSERT", "INS");
        Add(new("Home", 0x4A, 0x24, true), "HOME");
        Add(new("PageUp", 0x4B, 0x21, true), "PGUP");
        Add(new("Delete", 0x4C, 0x2E, true), "DELETE", "DEL");
        Add(new("End", 0x4D, 0x23, true), "END");
        Add(new("PageDown", 0x4E, 0x22, true), "PGDN");
        Add(new("Right", 0x4F, 0x27, true), "RIGHT");
        Add(new("Left", 0x50, 0x25, true), "LEFT");
        Add(new("Down", 0x51, 0x28, true), "DOWN");
        Add(new("Up", 0x52, 0x26, true), "UP");
        Add(new("NumLock", 0x53, 0x90, true), "NUMLOCK");
        Add(new("NumpadDivide", 0x54, 0x6F, true), "DIVIDE");
        Add(new("NumpadMultiply", 0x55, 0x6A, false), "MULTIPLY");
        Add(new("NumpadSubtract", 0x56, 0x6D, false), "SUBTRACT");
        Add(new("NumpadAdd", 0x57, 0x6B, false), "ADD");
        Add(new("Apps", 0x65, 0x5D, true), "APPS");
        Add(new("Help", 0, 0x2F, false), "HELP"); // no PC scan code: Windows ignores the HID Help usage, so always SendInput
        Add(new("Win", 0xE3, 0x5B, true), "WIN", "LWIN");
        Add(new("RightWin", 0xE7, 0x5C, true), "RWIN");
        for (int i = 1; i <= 24; i++)
            Add(new($"F{i}", i <= 12 ? 0x39 + i : 0x68 + i - 13, (ushort)(0x6F + i), false), $"F{i}");
        return keys;
    }

    /// <summary>Parses <paramref name="text"/>; throws <see cref="ArgumentException"/> with the position on errors.</summary>
    internal static List<KeyStroke> Parse(string text)
    {
        if (string.IsNullOrEmpty(text)) throw new ArgumentException("keys must not be empty.");
        var strokes = new List<KeyStroke>();
        int i = 0;
        ParseUntil(text, ref i, strokes, 0, group: false);
        if (strokes.Count == 0) throw new ArgumentException("keys contains no key.");
        foreach (var stroke in strokes) Refuse(stroke);
        return strokes;
    }

    private static void ParseUntil(string text, ref int i, List<KeyStroke> strokes, int outer, bool group)
    {
        int pending = 0;
        while (i < text.Length)
        {
            char c = text[i];
            switch (c)
            {
                case '+': pending |= Shift; i++; continue;
                case '^': pending |= Ctrl; i++; continue;
                case '%': pending |= Alt; i++; continue;
                case '#': pending |= Win; i++; continue;
                case '(':
                    i++;
                    ParseUntil(text, ref i, strokes, outer | pending, group: true);
                    pending = 0;
                    continue;
                case ')':
                    if (!group) throw new ArgumentException($"Unmatched ')' at position {i + 1}; use {{)}} for a literal parenthesis.");
                    if (pending != 0) throw new ArgumentException($"Modifier without a key before ')' at position {i + 1}.");
                    i++;
                    return;
                case '~': Add(strokes, new(outer | pending, Keys["ENTER"], '\0'), 1); pending = 0; i++; continue;
                case '{':
                {
                    int close = text.IndexOf('}', i + 2); // "{}}" : the first '}' is the content
                    if (close < 0) throw new ArgumentException($"Unclosed '{{' at position {i + 1}.");
                    string content = text[(i + 1)..close];
                    i = close + 1;
                    var (name, repeat) = SplitRepeat(content);
                    KeyStroke stroke = name.Length == 1
                        ? new(outer | pending, null, name[0])
                        : Keys.TryGetValue(name, out var key)
                            ? new(outer | pending, key, '\0')
                            : throw new ArgumentException($"Unknown key {{{name}}}. Known: {string.Join(", ", Keys.Keys.Select(k => k.ToUpperInvariant()).Distinct())}.");
                    Add(strokes, stroke, repeat);
                    pending = 0;
                    continue;
                }
                case '}': throw new ArgumentException($"Unmatched '}}' at position {i + 1}; use {{}}}} for a literal brace.");
                default:
                    if (char.IsControl(c)) throw new ArgumentException($"Control character at position {i + 1}; use {{ENTER}}, {{TAB}} ... instead.");
                    if (char.IsSurrogate(c)) throw new ArgumentException($"Character at position {i + 1} is not on a keyboard; use desktop_type_text_injected for it.");
                    Add(strokes, new(outer | pending, null, c), 1);
                    pending = 0;
                    i++;
                    continue;
            }
        }
        if (group) throw new ArgumentException("Unclosed '(' group.");
        if (pending != 0) throw new ArgumentException("Modifier (+ ^ % #) at the end without a key.");
    }

    private static (string Name, int Repeat) SplitRepeat(string content)
    {
        int space = content.LastIndexOf(' ');
        if (space > 0 && int.TryParse(content[(space + 1)..], out int repeat))
        {
            if (repeat is < 1 or > MaxRepeat) throw new ArgumentException($"Repeat count in {{{content}}} must be 1-{MaxRepeat}.");
            return (content[..space], repeat);
        }
        return (content, 1);
    }

    private static void Add(List<KeyStroke> strokes, KeyStroke stroke, int repeat)
    {
        for (int r = 0; r < repeat; r++) strokes.Add(stroke);
        if (strokes.Count > MaxStrokes) throw new ArgumentException($"At most {MaxStrokes} key presses per call.");
    }

    /// <summary>Combinations the server never sends: they would leave the AI unable to continue or stop all instances.</summary>
    private static void Refuse(KeyStroke stroke)
    {
        int m = stroke.Modifiers | (stroke.Key?.ExtraModifiers ?? 0);
        string? name = stroke.Key?.Name;
        if ((m & (Ctrl | Alt)) == (Ctrl | Alt) && name is "Delete" or "NumpadDecimal")
            throw new ArgumentException("Ctrl+Alt+Del is refused: it opens the secure desktop, which the server cannot see or use.");
        if ((m & Win) != 0 && stroke.Key is null && char.ToLowerInvariant(stroke.Character) == 'l')
            throw new ArgumentException("Win+L is refused: it locks the PC, and only the user can unlock it.");
        if ((m & (Ctrl | Alt)) == (Ctrl | Alt) && name == "F12")
            throw new ArgumentException("Ctrl+Alt+F12 is the user's emergency stop and is never sent by the server.");
    }

    // ---- SendInput transport ----

    /// <summary>One key press with SendInput: modifiers down, key down/up, modifiers up (virtual keys with scan codes).</summary>
    internal static void SendInjected(KeyStroke stroke, nint layout, Action pause)
    {
        ushort vk; bool extended; int modifiers = stroke.Modifiers;
        if (stroke.Key is { } key)
        {
            vk = key.VirtualKey; extended = key.Extended; modifiers |= key.ExtraModifiers;
        }
        else
        {
            short scan = VkKeyScanExW(stroke.Character, layout);
            if (scan == -1)
            {
                if (modifiers != 0) throw new ArgumentException($"'{stroke.Character}' is not on the keyboard layout, so it cannot be combined with modifiers.");
                Native.SendUnicode(stroke.Character);
                return;
            }
            vk = (ushort)(scan & 0xFF); extended = false;
            int state = scan >> 8;
            if ((state & 1) != 0) modifiers |= Shift;
            if ((state & 2) != 0) modifiers |= Ctrl;
            if ((state & 4) != 0) modifiers |= Alt;
        }
        var held = new List<(ushort Vk, bool Extended)>();
        if ((modifiers & Ctrl) != 0) held.Add((0xA2, false));
        if ((modifiers & Alt) != 0) held.Add((0xA4, false));
        if ((modifiers & Shift) != 0) held.Add((0xA0, false));
        if ((modifiers & Win) != 0) held.Add((0x5B, true));
        try
        {
            foreach (var (mvk, mext) in held) { Key(mvk, mext, down: true, layout); pause(); }
            Key(vk, extended, down: true, layout);
            pause();
            Key(vk, extended, down: false, layout);
        }
        finally
        {
            for (int h = held.Count - 1; h >= 0; h--) Key(held[h].Vk, held[h].Extended, down: false, layout);
        }
    }

    private static void Key(ushort vk, bool extended, bool down, nint layout)
    {
        uint flags = (extended ? 0x0001u : 0) | (down ? 0 : 0x0002u); // KEYEVENTF_EXTENDEDKEY, KEYEVENTF_KEYUP
        ushort scan = (ushort)(MapVirtualKeyExW(vk, 0 /* MAPVK_VK_TO_VSC */, layout) & 0xFF);
        Native.Input[] input = [new() { Type = 1, Union = new() { Keyboard = new() { Key = vk, Scan = scan, Flags = flags } } }];
        if (Native.SendInput(1, input, Marshal.SizeOf<Native.Input>()) != 1)
            throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error(), "Key input was not accepted. Windows integrity/desktop restrictions may apply.");
    }

    // ---- device keyboard transport ----

    /// <summary>HID modifier bits and usage of <paramref name="stroke"/> for the device keyboard; false when a character is not on the layout.</summary>
    internal static bool TryDevice(KeyStroke stroke, nint layout, out int modifiers, out int usage)
    {
        modifiers = stroke.Modifiers;
        if (stroke.Key is { } key)
        {
            usage = key.Usage;
            if (usage == 0) return false; // no device key (Help)
            modifiers |= key.ExtraModifiers;
            // The Windows keys are modifier usages: send them as modifier bits (LGui 0x08, RGui 0x80) with no key.
            if (usage == 0xE3) { modifiers |= 0x08; usage = 0; }
            else if (usage == 0xE7) { modifiers |= 0x80; usage = 0; }
            return true;
        }
        if (!DeviceKeyboard.TryMap(stroke.Character, layout, out int own, out usage)) return false;
        modifiers |= own;
        if ((modifiers & DeviceKeyboard.RightAlt) != 0 && (modifiers & Alt) != 0) modifiers &= ~Alt; // AltGr already sends Alt
        return true;
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern short VkKeyScanExW(char character, nint layout);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern uint MapVirtualKeyExW(uint code, uint mapType, nint layout);
}
