namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>Default backend: Windows SendInput (input is flagged as injected; subject to UIPI).</summary>
internal sealed class SendInputBackend : IPointerBackend
{
    public string Name => "SendInput";

    public bool IsDevice => false;

    public bool Available => true;

    public void MoveTo(int x, int y)
    {
        var b = SystemInformation.VirtualScreen;
        Native.Send(0x0001 | 0x8000 | 0x4000, // MOVE | ABSOLUTE | VIRTUALDESK
            (int)Math.Round((x - b.X) * 65535.0 / Math.Max(1, b.Width - 1)),
            (int)Math.Round((y - b.Y) * 65535.0 / Math.Max(1, b.Height - 1)));
    }

    public void Button(int mask, bool down)
    {
        var (downFlag, upFlag, data) = Flags(mask);
        Native.Send(down ? downFlag : upFlag, data: data);
    }

    internal static (uint down, uint up, uint data) Flags(int mask) => mask switch
    {
        1 => (0x0002, 0x0004, 0), 2 => (0x0008, 0x0010, 0), 4 => (0x0020, 0x0040, 0),
        8 => (0x0080, 0x0100, 1), 16 => (0x0080, 0x0100, 2),
        _ => throw new ArgumentOutOfRangeException(nameof(mask))
    };

    public void Scroll(int delta, bool horizontal) => Native.Send(horizontal ? 0x1000u : 0x0800u, data: unchecked((uint)delta));

    public void ForgetButtons() { }

    public bool Recalibrate(int requestedX, int requestedY, int actualX, int actualY) => false;

    public object Diagnostics() => new { available = true };

    public void Dispose() { }
}
