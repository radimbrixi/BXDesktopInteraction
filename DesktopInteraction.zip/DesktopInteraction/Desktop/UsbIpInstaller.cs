using System.Diagnostics;
using System.Security.Cryptography;
using Microsoft.Win32;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Unattended install/uninstall of the usbip-win2 client (Inno Setup installer) for <c>--device usbip</c>.
/// Runs only installers whose SHA-256 is pinned here (or given explicitly with --usbip-sha256), because the
/// installer runs elevated and installs a kernel driver. Run by the user from an elevated prompt.
/// </summary>
internal static class UsbIpInstaller
{
    /// <summary>Tested installers: SHA-256 → version. Add a line when moving testers to a new release.</summary>
    private static readonly Dictionary<string, string> KnownInstallers = new(StringComparer.OrdinalIgnoreCase)
    {
        ["38cad6d4432b52d5bb9409d9ad03b72fdffc4ada4cd3a48fbeca1a2752a8518a"] = "0.9.8.1 x64",
    };

    private const string InnoSilent = "/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-";
    private static readonly TimeSpan Timeout = TimeSpan.FromMinutes(10);

    internal static string DefaultUsbIpExe => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "USBip", "usbip.exe");

    internal static int Install(string installerPath, string? expectedSha256)
    {
        DriverInstaller.RequireAdministrator();
        var path = Path.GetFullPath(installerPath);
        if (!File.Exists(path)) throw new FileNotFoundException($"Installer not found: {path}");

        // Keep the file open (no writers) from hashing until the installer has finished.
        using var pin = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        string hash = Convert.ToHexStringLower(SHA256.HashData(pin));
        string version;
        if (expectedSha256 is not null)
        {
            if (!hash.Equals(expectedSha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException($"SHA-256 mismatch: file {hash}, expected {expectedSha256}. Not installed.");
            version = "explicitly pinned";
        }
        else if (!KnownInstallers.TryGetValue(hash, out version!))
        {
            throw new InvalidOperationException($"Unknown installer (SHA-256 {hash}). Not installed. Use a tested release (USBIP.md) " +
                                                "or confirm this one with --usbip-sha256 <hash>.");
        }

        string log = Path.Combine(Path.GetTempPath(), "Extedo.AutoTest.Ai.Mcp.DesktopInteraction.usbip-install.log");
        Console.WriteLine($"Installing usbip-win2 {version} silently (log: {log}). USB devices reconnect briefly...");
        int exit = Run(path, $"{InnoSilent} /LOG=\"{log}\"");
        if (exit != 0) throw new InvalidOperationException($"usbip-win2 installer failed with exit code {exit}. See {log}.");

        bool present = File.Exists(DefaultUsbIpExe);
        Console.WriteLine(present
            ? $"Installed: {DefaultUsbIpExe}. Reboot before using the device tools (--device usbip, the default)."
            : $"Installer finished, but {DefaultUsbIpExe} was not found; pass --usbip-exe <path> to the server. Reboot first.");
        return 0;
    }

    internal static int Uninstall()
    {
        DriverInstaller.RequireAdministrator();
        var entry = FindUninstallEntry() ?? throw new InvalidOperationException("usbip-win2 is not installed (no uninstall entry found).");
        string uninstaller = ExecutablePath(entry.Command);
        if (!File.Exists(uninstaller)) throw new FileNotFoundException($"Uninstaller not found: {uninstaller}");

        Console.WriteLine($"Uninstalling {entry.Name} silently...");
        int exit = Run(uninstaller, InnoSilent);
        if (exit != 0) throw new InvalidOperationException($"usbip-win2 uninstaller failed with exit code {exit}.");

        // The Inno uninstaller hands over to a temporary copy; wait until its entry disappears.
        var deadline = DateTime.UtcNow + Timeout;
        while (FindUninstallEntry() is not null && DateTime.UtcNow < deadline) Thread.Sleep(1000);
        if (FindUninstallEntry() is not null) throw new TimeoutException("usbip-win2 uninstall did not finish in time.");
        Console.WriteLine("Uninstalled usbip-win2. Reboot to finish removing the driver.");
        return 0;
    }

    private static int Run(string file, string arguments)
    {
        using var process = Process.Start(new ProcessStartInfo(file, arguments) { UseShellExecute = false, CreateNoWindow = true })
                            ?? throw new InvalidOperationException($"Could not start {file}.");
        if (!process.WaitForExit(Timeout)) { process.Kill(entireProcessTree: true); throw new TimeoutException($"{Path.GetFileName(file)} did not finish in {Timeout.TotalMinutes} minutes."); }
        return process.ExitCode;
    }

    private static (string Name, string Command)? FindUninstallEntry()
    {
        using var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64)
            .OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
        if (root is null) return null;
        foreach (var name in root.GetSubKeyNames())
        {
            using var key = root.OpenSubKey(name);
            if (key?.GetValue("DisplayName") is not string display || !display.Contains("usbip", StringComparison.OrdinalIgnoreCase)) continue;
            if (key.GetValue("UninstallString") is string command && command.Contains("unins", StringComparison.OrdinalIgnoreCase))
                return (display, command);
        }
        return null;
    }

    /// <summary>UninstallString is <c>"C:\...\unins000.exe"</c> (quoted) possibly followed by arguments.</summary>
    private static string ExecutablePath(string command)
    {
        command = command.Trim();
        if (command.StartsWith('"')) return command[1..command.IndexOf('"', 1)];
        int exe = command.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
        return exe < 0 ? command : command[..(exe + 4)];
    }
}
