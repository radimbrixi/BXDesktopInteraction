namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Generates human-like pointer paths: curved (cubic Bezier) trajectories with minimum-jerk speed profile,
/// small decaying tremor, optional overshoot-and-correct on long moves, ~125 Hz sampling, and
/// Fitts'-law-like default durations. The final point is always exactly the target.
/// </summary>
internal static class HumanMotion
{
    internal readonly record struct Step(int X, int Y, int DelayMs);

    internal const int IntervalMs = 8;

    /// <summary>Default duration for a distance: grows logarithmically, with ±15 % variation.</summary>
    internal static int DefaultDuration(double distance, Random random)
    {
        if (distance < 1) return 0;
        double ms = (90 + 140 * Math.Log2(distance / 16 + 1)) * (0.85 + 0.3 * random.NextDouble());
        return (int)Math.Clamp(ms, 80, 2500);
    }

    internal static List<Step> Linear(Point start, Point end, int durationMs)
    {
        var steps = new List<Step>();
        int count = Math.Max(1, durationMs / 10);
        for (int i = 1; i <= count; i++)
        {
            double t = (double)i / count; t = t * t * (3 - 2 * t);
            steps.Add(new((int)Math.Round(start.X + (end.X - start.X) * t), (int)Math.Round(start.Y + (end.Y - start.Y) * t),
                durationMs > 0 ? Math.Max(1, durationMs / count) : 0));
        }
        return steps;
    }

    internal static List<Step> Human(Point start, Point end, int durationMs, Rectangle bounds, Random random, Rectangle? endArea = null)
    {
        var steps = new List<Step>();
        double dx = end.X - start.X, dy = end.Y - start.Y, distance = Math.Sqrt(dx * dx + dy * dy);
        if (durationMs <= 0 || distance < 1)
        {
            steps.Add(new(end.X, end.Y, 0));
            return steps;
        }

        bool overshoot = distance > 250 && random.NextDouble() < 0.6;
        if (overshoot)
        {
            double extra = distance * (0.02 + 0.04 * random.NextDouble());
            double side = (random.NextDouble() - 0.5) * extra * 0.6;
            var over = Clamp(new Point(
                (int)Math.Round(end.X + dx / distance * extra - dy / distance * side),
                (int)Math.Round(end.Y + dy / distance * extra + dx / distance * side)), Inside(endArea, bounds));
            int main = (int)(durationMs * (0.8 + 0.08 * random.NextDouble()));
            AddCurve(steps, start, over, main, bounds, random, curvature: 1.0);
            AddCurve(steps, over, end, Math.Max(IntervalMs * 3, durationMs - main), Inside(endArea, bounds), random, curvature: 0.3);
        }
        else
        {
            AddCurve(steps, start, end, durationMs, bounds, random, curvature: 1.0);
        }

        steps[^1] = steps[^1] with { X = end.X, Y = end.Y };
        return steps;
    }

    private static void AddCurve(List<Step> steps, Point start, Point end, int durationMs, Rectangle bounds, Random random, double curvature)
    {
        double dx = end.X - start.X, dy = end.Y - start.Y, distance = Math.Sqrt(dx * dx + dy * dy);
        int count = Math.Max(2, durationMs / IntervalMs);
        if (distance < 1)
        {
            steps.Add(new(end.X, end.Y, Math.Max(1, durationMs)));
            return;
        }

        // Perpendicular unit vector and a random bend (sign and size), capped for long moves.
        double px = -dy / distance, py = dx / distance;
        double bend = Math.Min(200, distance * (0.05 + 0.13 * random.NextDouble())) * curvature * (random.Next(2) == 0 ? -1 : 1);
        double c1x = start.X + dx * 0.3 + px * bend * (0.6 + 0.6 * random.NextDouble());
        double c1y = start.Y + dy * 0.3 + py * bend * (0.6 + 0.6 * random.NextDouble());
        double c2x = start.X + dx * 0.7 + px * bend * (0.6 + 0.6 * random.NextDouble());
        double c2y = start.Y + dy * 0.7 + py * bend * (0.6 + 0.6 * random.NextDouble());
        double tremor = Math.Min(1.5, distance / 200);

        int elapsed = 0;
        for (int i = 1; i <= count; i++)
        {
            double t = (double)i / count;
            double s = t * t * t * (10 - 15 * t + 6 * t * t); // minimum-jerk position profile
            double u = 1 - s;
            double x = u * u * u * start.X + 3 * u * u * s * c1x + 3 * u * s * s * c2x + s * s * s * end.X;
            double y = u * u * u * start.Y + 3 * u * u * s * c1y + 3 * u * s * s * c2y + s * s * s * end.Y;
            double amplitude = tremor * (1 - s);
            if (i < count)
            {
                x += (random.NextDouble() - 0.5) * 2 * amplitude;
                y += (random.NextDouble() - 0.5) * 2 * amplitude;
            }
            int target = (int)Math.Round(durationMs * t);
            int delay = Math.Max(1, target - elapsed + random.Next(-1, 2));
            elapsed += delay;
            var p = i == count ? end : Clamp(new Point((int)Math.Round(x), (int)Math.Round(y)), bounds);
            steps.Add(new(p.X, p.Y, delay));
        }
    }

    /// <summary>
    /// Human-like motion along a planned multi-monitor route: one continuous minimum-jerk sweep over the whole
    /// route (no stop at monitor crossings), each leg a gentle curve held inside its monitor, decaying tremor,
    /// and the optional overshoot-and-correct only at the end, on the target monitor.
    /// </summary>
    internal static List<Step> HumanRoute(IReadOnlyList<RouteLeg> legs, int durationMs, Random random)
    {
        var end = legs[^1].To;
        var last = legs[^1];
        if (durationMs <= 0) return [new(end.X, end.Y, 0)];

        double lastLength = Math.Sqrt(Math.Pow(last.To.X - last.From.X, 2) + Math.Pow(last.To.Y - last.From.Y, 2));
        bool overshoot = lastLength > 250 && random.NextDouble() < 0.6;
        var finalPoint = end;
        if (overshoot)
        {
            double dx = (last.To.X - last.From.X) / lastLength, dy = (last.To.Y - last.From.Y) / lastLength;
            double extra = lastLength * (0.02 + 0.04 * random.NextDouble()), side = (random.NextDouble() - 0.5) * extra * 0.6;
            finalPoint = Clamp(new Point((int)Math.Round(end.X + dx * extra - dy * side), (int)Math.Round(end.Y + dy * extra + dx * side)), last.Area);
        }

        // Geometry: densely sampled curve per leg, clamped to that leg's monitor.
        var points = new List<(double X, double Y, int Leg)>();
        for (int l = 0; l < legs.Count; l++)
        {
            var from = legs[l].From;
            var to = l == legs.Count - 1 ? finalPoint : legs[l].To;
            double dx = to.X - from.X, dy = to.Y - from.Y, distance = Math.Sqrt(dx * dx + dy * dy);
            int samples = Math.Max(2, (int)(distance / 4));
            double bend = distance < 1 ? 0 : Math.Min(120, distance * (0.04 + 0.08 * random.NextDouble())) * (random.Next(2) == 0 ? -1 : 1);
            double px = distance < 1 ? 0 : -dy / distance, py = distance < 1 ? 0 : dx / distance;
            for (int i = 0; i <= samples; i++)
            {
                double t = (double)i / samples, u = 1 - t;
                double arc = 4 * t * u; // 0 at both ends: legs meet exactly at the crossing points
                double x = from.X + dx * t + px * bend * arc, y = from.Y + dy * t + py * bend * arc;
                var c = Clamp(new Point((int)Math.Round(x), (int)Math.Round(y)), legs[l].Area);
                points.Add((c.X, c.Y, l));
            }
        }
        var cumulative = new double[points.Count];
        for (int i = 1; i < points.Count; i++)
            cumulative[i] = cumulative[i - 1] + Math.Sqrt(Math.Pow(points[i].X - points[i - 1].X, 2) + Math.Pow(points[i].Y - points[i - 1].Y, 2));
        double total = cumulative[^1];

        var steps = new List<Step>();
        int main = overshoot ? (int)(durationMs * (0.8 + 0.08 * random.NextDouble())) : durationMs;
        int count = Math.Max(2, main / IntervalMs);
        double tremor = Math.Min(1.5, total / 200);
        int elapsed = 0, index = 0;
        for (int i = 1; i <= count; i++)
        {
            double t = (double)i / count;
            double s = t * t * t * (10 - 15 * t + 6 * t * t);
            double target = s * total;
            while (index < points.Count - 2 && cumulative[index + 1] < target) index++;
            double span = cumulative[index + 1] - cumulative[index], f = span < 1e-9 ? 0 : (target - cumulative[index]) / span;
            double x = points[index].X + (points[index + 1].X - points[index].X) * f;
            double y = points[index].Y + (points[index + 1].Y - points[index].Y) * f;
            double amplitude = tremor * (1 - s);
            if (i < count) { x += (random.NextDouble() - 0.5) * 2 * amplitude; y += (random.NextDouble() - 0.5) * 2 * amplitude; }
            var area = legs[points[f < 0.5 ? index : index + 1].Leg].Area;
            var p = i == count ? finalPoint : Clamp(new Point((int)Math.Round(x), (int)Math.Round(y)), area);
            int due = (int)Math.Round(main * t);
            int delay = Math.Max(1, due - elapsed + random.Next(-1, 2));
            elapsed += delay;
            steps.Add(new(p.X, p.Y, delay));
        }
        if (overshoot) AddCurve(steps, finalPoint, end, Math.Max(IntervalMs * 3, durationMs - main), last.Area, random, curvature: 0.3);
        steps[^1] = steps[^1] with { X = end.X, Y = end.Y };
        return steps;
    }

    /// <summary>Linear motion along a planned route: straight legs, one smooth speed profile, ~100 Hz.</summary>
    internal static List<Step> LinearRoute(IReadOnlyList<RouteLeg> legs, int durationMs)
    {
        var points = new List<(Point P, int Leg)>();
        for (int l = 0; l < legs.Count; l++) { points.Add((legs[l].From, l)); points.Add((legs[l].To, l)); }
        var cumulative = new double[points.Count];
        for (int i = 1; i < points.Count; i++)
            cumulative[i] = cumulative[i - 1] + Math.Sqrt(Math.Pow(points[i].P.X - points[i - 1].P.X, 2) + Math.Pow(points[i].P.Y - points[i - 1].P.Y, 2));
        double total = cumulative[^1];
        var steps = new List<Step>();
        int count = Math.Max(1, durationMs / 10), index = 0;
        for (int i = 1; i <= count; i++)
        {
            double t = (double)i / count; t = t * t * (3 - 2 * t);
            double target = t * total;
            while (index < points.Count - 2 && cumulative[index + 1] < target) index++;
            double span = cumulative[index + 1] - cumulative[index], f = span < 1e-9 ? 0 : (target - cumulative[index]) / span;
            var a = points[index].P; var b = points[index + 1].P;
            var p = Clamp(new Point((int)Math.Round(a.X + (b.X - a.X) * f), (int)Math.Round(a.Y + (b.Y - a.Y) * f)), legs[points[f < 0.5 ? index : index + 1].Leg].Area);
            steps.Add(new(p.X, p.Y, durationMs > 0 ? Math.Max(1, durationMs / count) : 0));
        }
        steps[^1] = steps[^1] with { X = legs[^1].To.X, Y = legs[^1].To.Y };
        return steps;
    }

    /// <summary>
    /// The overshoot and its correction stay on the target's monitor: overshooting past a monitor edge would cross
    /// into a neighbouring monitor (and can get stuck in Windows' sticky corners with relative device input).
    /// </summary>
    private static Rectangle Inside(Rectangle? endArea, Rectangle bounds)
    {
        if (endArea is not { } area) return bounds;
        var both = Rectangle.Intersect(area, bounds);
        return both.Width > 0 && both.Height > 0 ? both : bounds;
    }

    private static Point Clamp(Point p, Rectangle b) => new(Math.Clamp(p.X, b.Left, b.Right - 1), Math.Clamp(p.Y, b.Top, b.Bottom - 1));

    /// <summary>Random pause in [min, max] milliseconds.</summary>
    internal static int Pause(Random random, int min, int max) => random.Next(min, max + 1);
}
