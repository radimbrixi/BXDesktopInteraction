using System.Runtime.InteropServices;
using System.Text;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Maps a character to a key press on the virtual keyboard for the keyboard layout of the target window: the layout
/// gives the virtual key and the shift state (VkKeyScanEx), the scan code (MapVirtualKeyEx) and the result is checked
/// with ToUnicodeEx (also against the current Caps Lock state). The scan code becomes a HID usage, so the key arrives
/// exactly like a key of a real USB keyboard and Windows translates it with the same layout.
/// Characters the layout cannot type in one key press (dead-key accents, emoji, other scripts) are not mapped.
/// </summary>
internal static class DeviceKeyboard
{
    internal const int LeftCtrl = 0x01, LeftShift = 0x02, LeftAlt = 0x04, RightAlt = 0x40;

    /// <summary>Keyboard layout of the window's thread (the layout the user sees in that window).</summary>
    internal static nint LayoutOf(nint window) => GetKeyboardLayout(GetWindowThreadProcessId(window, out _));

    /// <summary>HID modifier bits and key usage that type <paramref name="character"/> with <paramref name="layout"/>.</summary>
    internal static bool TryMap(char character, nint layout, out int modifiers, out int usage)
    {
        modifiers = 0; usage = 0;
        short scan = VkKeyScanExW(character, layout);
        if (scan == -1) return false;
        uint vk = (uint)(scan & 0xFF);
        int shiftState = (scan >> 8) & 0xFF;
        if ((shiftState & ~7) != 0) return false; // Hankaku / Kana / other modifiers
        uint scanCode = MapVirtualKeyExW(vk, 4 /* MAPVK_VK_TO_VSC_EX */, layout);
        if (scanCode == 0 || !ScanToUsage.TryGetValue((int)scanCode, out usage)) return false;
        bool shift = (shiftState & 1) != 0, ctrl = (shiftState & 2) != 0, alt = (shiftState & 4) != 0;
        bool capsLock = (GetKeyState(0x14) & 1) != 0;
        // Caps Lock inverts Shift for some keys (letters, and on many layouts more): pick the shift that really types it.
        if (!Produces(character, vk, scanCode, shift, ctrl, alt, capsLock, layout))
        {
            if (!Produces(character, vk, scanCode, !shift, ctrl, alt, capsLock, layout)) return false;
            shift = !shift;
        }
        if (ctrl && alt) modifiers |= RightAlt; // AltGr
        else { if (ctrl) modifiers |= LeftCtrl; if (alt) modifiers |= LeftAlt; }
        if (shift) modifiers |= LeftShift;
        return true;
    }

    private static bool Produces(char character, uint vk, uint scanCode, bool shift, bool ctrl, bool alt, bool capsLock, nint layout)
    {
        var state = new byte[256];
        if (shift) state[0x10] = state[0xA0] = 0x80;
        if (ctrl) state[0x11] = state[ctrl && alt ? 0xA3 : 0xA2] = 0x80;
        if (alt) state[0x12] = state[ctrl && alt ? 0xA5 : 0xA4] = 0x80;
        if (capsLock) state[0x14] = 0x01;
        var buffer = new StringBuilder(8);
        // Flag 4: do not change the keyboard state (no dead-key side effects), Windows 10 1607+.
        int count = ToUnicodeEx(vk, scanCode & 0xFF, state, buffer, buffer.Capacity, 4, layout);
        return count == 1 && buffer[0] == character;
    }

    /// <summary>Set-1 scan code (0xE0xx = extended) to HID keyboard usage, typing keys only.</summary>
    internal static readonly Dictionary<int, int> ScanToUsage = Build();

    private static Dictionary<int, int> Build()
    {
        var map = new Dictionary<int, int>
        {
            [0x0C] = 0x2D, [0x0D] = 0x2E, [0x0F] = 0x2B, [0x1A] = 0x2F, [0x1B] = 0x30, [0x1C] = 0x28,
            [0x27] = 0x33, [0x28] = 0x34, [0x29] = 0x35, [0x2B] = 0x31, [0x33] = 0x36, [0x34] = 0x37, [0x35] = 0x38,
            [0x37] = 0x55, [0x39] = 0x2C, [0x56] = 0x64, [0x73] = 0x87, [0x7D] = 0x89, [0x7E] = 0x85,
            [0x47] = 0x5F, [0x48] = 0x60, [0x49] = 0x61, [0x4A] = 0x56, [0x4B] = 0x5C, [0x4C] = 0x5D, [0x4D] = 0x5E,
            [0x4E] = 0x57, [0x4F] = 0x59, [0x50] = 0x5A, [0x51] = 0x5B, [0x52] = 0x62, [0x53] = 0x63, [0xE035] = 0x54,
        };
        for (int i = 0; i < 10; i++) map[0x02 + i] = 0x1E + i; // 1..9, 0
        int[] qwerty = [0x14, 0x1A, 0x08, 0x15, 0x17, 0x1C, 0x18, 0x0C, 0x12, 0x13]; // Q W E R T Y U I O P
        for (int i = 0; i < qwerty.Length; i++) map[0x10 + i] = qwerty[i];
        int[] home = [0x04, 0x16, 0x07, 0x09, 0x0A, 0x0B, 0x0D, 0x0E, 0x0F]; // A S D F G H J K L
        for (int i = 0; i < home.Length; i++) map[0x1E + i] = home[i];
        int[] bottom = [0x1D, 0x1B, 0x06, 0x19, 0x05, 0x11, 0x10]; // Z X C V B N M
        for (int i = 0; i < bottom.Length; i++) map[0x2C + i] = bottom[i];
        return map;
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern short VkKeyScanExW(char character, nint layout);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern uint MapVirtualKeyExW(uint code, uint mapType, nint layout);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int ToUnicodeEx(uint vk, uint scan, byte[] state, StringBuilder buffer, int size, uint flags, nint layout);
    [DllImport("user32.dll")] private static extern short GetKeyState(int vk);
    [DllImport("user32.dll")] private static extern nint GetKeyboardLayout(uint thread);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(nint window, out uint process);
}
