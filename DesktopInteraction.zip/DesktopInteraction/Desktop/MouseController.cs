using System.Diagnostics;
using System.Drawing.Imaging;
using System.Text.Json;
using ModelContextProtocol.Protocol;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>Which input path a mouse tool uses: the virtual device (real device input) or SendInput (injected).</summary>
internal enum InputKind { Device, Injected }

/// <summary>
/// Mouse, text and screenshot operations. Every pointer operation names its <see cref="InputKind"/>: device input
/// goes through the device backend (virtual USB mouse or ExtedoVirtualMouse driver), injected input through SendInput.
/// All input goes through <see cref="SharedControl"/>, so only the instance holding the baton sends input. With human
/// motion enabled, moves follow curved, variably paced paths and clicks/drags use natural pauses.
/// </summary>
/// <para>
/// The user has priority: an input request first waits until the user's own mouse and keyboard have been idle for
/// <c>userIdleMs</c> (default 7 s; at most <c>userWaitMs</c>), and a running action stops as soon as the user touches
/// the mouse or keyboard.
/// </para>
internal sealed class MouseController(CursorOverlay overlay, IPointerBackend? device, IPointerBackend injected, bool humanMotion, int userIdleMs = 7000, int userWaitMs = 30000, bool secureDesktopDeviceInput = false)
{
    private readonly Dictionary<InputKind, int> held = new() { [InputKind.Device] = 0, [InputKind.Injected] = 0 };
    private readonly object gate = new();
    private readonly Random random = new();
    private long actionStart = Environment.TickCount64;
    private long lastDrive = long.MinValue / 2;

    /// <summary>This instance holds the baton and sent input in the last <see cref="CursorOverlay.LingerMs"/> (shows the marker).</summary>
    internal bool Driving => Environment.TickCount64 - Interlocked.Read(ref lastDrive) < CursorOverlay.LingerMs && overlay.Control.Active;

    /// <summary>Frame around the monitors: this instance holds the baton and sent input in the last <see cref="FrameLingerMs"/>.</summary>
    internal bool Framing => Environment.TickCount64 - Interlocked.Read(ref lastDrive) < FrameLingerMs && overlay.Control.Active;

    /// <summary>The frame stays between the steps of a task (an AI thinks a few seconds between tool calls).</summary>
    internal const int FrameLingerMs = 6000;

    /// <summary>
    /// Starts an input request: waits until the user has been idle for the configured time, then takes the baton.
    /// Returns how long it waited for the user (ms).
    /// </summary>
    internal async Task<long> BeginInput(CancellationToken cancellationToken = default)
    {
        long start = Environment.TickCount64;
        while (userIdleMs > 0)
        {
            long now = Environment.TickCount64, quiet = now - overlay.Activity.LastUserInput;
            if (quiet >= userIdleMs) break;
            if (now - start >= userWaitMs)
                throw new InvalidOperationException($"The user is using the mouse or keyboard (last input {quiet} ms ago); waited {(now - start) / 1000} s for {userIdleMs / 1000.0:0.#} s of user inactivity. Try again later or ask the user.");
            await Task.Delay((int)Math.Min(userIdleMs - quiet, 250), cancellationToken);
        }
        Interlocked.Exchange(ref actionStart, Environment.TickCount64);
        TakeControl();
        return Environment.TickCount64 - start;
    }

    internal bool UsesHumanMotion => humanMotion;

    internal CursorOverlay Overlay => overlay;

    internal object Status()
    {
        bool remote = WindowNative.IsRemoteSession;
        bool deviceReady = device is not null && device.Available;
        return new
        {
            inputs = new
            {
                device = device is null
                    ? (object)new { enabled = false, reason = "started with --device none" }
                    : new { enabled = true, name = device.Name, available = deviceReady, keyboard = deviceReady && device.HasKeyboard, details = device.Diagnostics() },
                injected = new { enabled = true, name = injected.Name },
            },
            remoteDesktopSession = remote,
            recommendedMouseTools = remote || !deviceReady
                ? "desktop_mouse_*_injected (" + (remote ? "Remote Desktop session: device input reaches the console session" : "device input not available") + ")"
                : "desktop_mouse_* (device input)",
            typing = !remote && deviceReady && device!.HasKeyboard
                ? "desktop_type_text uses the device keyboard (reaches elevated windows and VM windows)"
                : "desktop_type_text uses SendInput (" + (remote ? "Remote Desktop session" : "no device keyboard") + "; blocked by elevated windows)",
            motion = humanMotion ? "human" : "linear",
            stopped = overlay.Stopped,
            user = new
            {
                requiredIdleMs = userIdleMs,
                maxWaitMs = userWaitMs,
                lastInputAgoMs = overlay.Activity.LastUserInput < 0 ? (long?)null : Environment.TickCount64 - overlay.Activity.LastUserInput,
                detection = overlay.Activity.Registered ? "raw input (virtual mouse and own injected input ignored)" : "unavailable",
            },
            inputDesktop = Native.IsNormalInputDesktop() ? "default"
                : secureDesktopDeviceInput ? "secure (device input allowed: blind click at a known position, no capture)"
                : "secure (input refused)",
            secureDesktopDeviceInput,
            control = overlay.Control.Status(),
            bounds = Bounds(),
            layout = MonitorLayout.Current().Describe(),
            cursor = Position(),
            emergencyStop = "Ctrl+Alt+F12",
            coordinates = "physical desktop pixels; origin can be negative",
        };
    }

    internal void TakeControl()
    {
        // When the baton came from another instance, that instance's buttons were released through SendInput.
        if (!overlay.Control.Claim()) return;
        lock (gate)
        {
            device?.ForgetButtons();
            injected.ForgetButtons();
            held[InputKind.Device] = held[InputKind.Injected] = 0;
        }
    }

    /// <summary>Runs one input action under the baton, emergency-stop, Escape and secure-desktop checks.</summary>
    /// <param name="deviceInput">This action uses the virtual device (HID). Only a real device can reach the secure
    /// desktop, so with <c>--secure-desktop-input device</c> such actions are allowed there; injected input never is.</param>
    internal void Execute(Action action, bool deviceInput = false) => overlay.Control.Execute(() =>
    {
        Check(deviceInput);
        Interlocked.Exchange(ref lastDrive, Environment.TickCount64);
        action();
    });

    internal static object Bounds()
    {
        var b = SystemInformation.VirtualScreen;
        return new { x = b.X, y = b.Y, width = b.Width, height = b.Height };
    }

    internal static object Position()
    {
        if (!Native.GetCursorPos(out var p)) throw new InvalidOperationException("Cannot read cursor position.");
        return new { x = p.X, y = p.Y };
    }

    private void Check(bool deviceInput)
    {
        if (userIdleMs > 0 && overlay.Activity.LastUserInput > Interlocked.Read(ref actionStart))
            throw new OperationCanceledException($"The user moved the mouse or used the keyboard: input stopped to let the user work. The next input request waits until the user has been idle for {userIdleMs / 1000.0:0.#} s.");
        if ((Native.GetAsyncKeyState(0x1B) & 0x8000) != 0) throw new OperationCanceledException("Escape is held; mouse operation cancelled.");
        if (!Native.IsNormalInputDesktop() && !(deviceInput && secureDesktopDeviceInput))
            throw new InvalidOperationException(secureDesktopDeviceInput
                ? "The secure desktop is active (UAC prompt, lock screen or Ctrl+Alt+Del screen). Device input is allowed here, but this action uses injected input, which Windows never delivers to the secure desktop. Use the device mouse/keyboard tools."
                : "The secure desktop is active (UAC prompt, lock screen or Ctrl+Alt+Del screen): it cannot be seen or captured from this session, so input is refused. Ask the user to answer it. On test machines the user can make UAC prompts appear on the normal desktop (MANUAL.md, \"UAC prompts\"), or start the server with --secure-desktop-input device to let the device mouse click them blind at a known position.");
    }

    /// <summary>Device input may operate the secure desktop (UAC) at a blind, pre-measured position (--secure-desktop-input device).</summary>
    internal bool SecureDesktopDeviceInput => secureDesktopDeviceInput;

    /// <summary>The backend for new input of this kind; device input is refused where it cannot reach this session.</summary>
    private IPointerBackend Backend(InputKind kind)
    {
        if (kind == InputKind.Injected) return injected;
        if (device is null) throw new InvalidOperationException("Device input is disabled (started with --device none). Use the desktop_mouse_*_injected tools.");
        if (WindowNative.IsRemoteSession)
            throw new InvalidOperationException("This is a Remote Desktop session: device input would reach the console session, not this one. Use the desktop_mouse_*_injected tools.");
        return device;
    }

    /// <param name="duration">Milliseconds 0-10000; null = human-like duration from distance (250 ms in linear mode).</param>
    internal async Task Move(InputKind kind, int x, int y, int? duration = null, CancellationToken cancellationToken = default)
    {
        var b = SystemInformation.VirtualScreen;
        var layout = MonitorLayout.Current();
        RequireOnMonitor(layout, x, y);
        if (duration is < 0 or > 10000) throw new ArgumentOutOfRangeException(nameof(duration), "durationMs must be 0-10000.");
        var backend = Backend(kind);
        Native.GetCursorPos(out var s);
        var start = new Point(s.X, s.Y);
        var end = new Point(x, y);

        // Between monitors: a planned route across shared edges (no gaps, no corners); within one monitor: direct.
        var legs = layout.Route(start, end);
        double distance = MonitorLayout.Length(legs);
        int ms = duration ?? (humanMotion ? HumanMotion.DefaultDuration(distance, random) : 250);
        var path = legs.Count > 1
            ? (humanMotion ? HumanMotion.HumanRoute(legs, ms, random) : HumanMotion.LinearRoute(legs, ms))
            : (humanMotion ? HumanMotion.Human(start, end, ms, legs[0].Area, random, Screen.FromPoint(end).Bounds) : HumanMotion.Linear(start, end, ms));

        var clock = Stopwatch.StartNew();
        long due = 0;
        foreach (var step in path)
        {
            cancellationToken.ThrowIfCancellationRequested();
            Execute(() => backend.MoveTo(step.X, step.Y), kind == InputKind.Device);
            due += step.DelayMs;
            long wait = due - clock.ElapsedMilliseconds;
            if (wait > 0) await Task.Delay((int)wait, cancellationToken);
        }

        // Settle reads the cursor to correct the final pixel. On the secure desktop (UAC) the cursor cannot be read from
        // this session, so a device move there is blind: the absolute position must have been calibrated beforehand on
        // the normal desktop (the UAC dialog is centred at the same screen coordinates).
        if (backend.IsDevice && Native.IsNormalInputDesktop()) await Settle(backend, x, y, cancellationToken);
    }

    /// <summary>Device input is asynchronous and its coordinate mapping is learned: verify and correct the final pixel.</summary>
    private async Task Settle(IPointerBackend backend, int x, int y, CancellationToken cancellationToken)
    {
        // Absolute corrections converge in 1-2 attempts; relative ones (pointer ballistics) may need more.
        for (int attempt = 0; attempt < 24; attempt++)
        {
            var actual = await WaitForPointer(x, y, cancellationToken);
            if (actual.X == x && actual.Y == y) return;
            if (!backend.Recalibrate(x, y, actual.X, actual.Y) && attempt > 0) break;
            Execute(() => backend.MoveTo(x, y), deviceInput: true); // Settle runs only for the device backend
        }
        var final = await WaitForPointer(x, y, cancellationToken);
        if (final.X != x || final.Y != y)
            throw new InvalidOperationException($"Device input moved the pointer to ({final.X},{final.Y}) instead of ({x},{y}). The monitor layout may block this path; try desktop_mouse_move_injected.");
    }

    private static async Task<Point> WaitForPointer(int x, int y, CancellationToken cancellationToken)
    {
        Native.GetCursorPos(out var p);
        for (int i = 0; i < 25 && (p.X != x || p.Y != y); i++)
        {
            await Task.Delay(2, cancellationToken);
            Native.GetCursorPos(out p);
        }
        return new Point(p.X, p.Y);
    }

    private static void RequireOnMonitor(MonitorLayout layout, int x, int y)
    {
        if (!SystemInformation.VirtualScreen.Contains(x, y)) throw new ArgumentException($"Point ({x},{y}) is outside the virtual desktop.");
        if (layout.MonitorAt(new Point(x, y)) < 0)
            throw new ArgumentException($"Point ({x},{y}) lies in a gap between monitors (no screen there). Use a point inside a monitor from desktop_status layout.");
    }

    private static int Mask(string button) => button switch
    {
        "left" => 1, "right" => 2, "middle" => 4, "x1" => 8, "x2" => 16,
        _ => throw new ArgumentException("Unknown mouse button. Use left, right, middle, x1 or x2.")
    };

    internal void Button(InputKind kind, string button, bool down)
    {
        int mask = Mask(button);
        lock (gate)
        {
            if (down)
            {
                var backend = Backend(kind);
                Execute(() => { backend.Button(mask, true); overlay.Control.SetButton(mask, true); }, kind == InputKind.Device);
                held[kind] |= mask;
            }
            else
            {
                // Releases always go to the path that pressed (even if it became unavailable for new input).
                var backend = kind == InputKind.Device && device is not null ? device : injected;
                overlay.Control.ReleaseButton(mask, () => backend.Button(mask, false));
                held[kind] &= ~mask;
            }
        }
    }

    /// <summary>
    /// Types text into the foreground window. <paramref name="kind"/> null = the device keyboard when the device has one
    /// and can reach this session (real keyboard input: elevated windows, VM windows), otherwise SendInput.
    /// On the device keyboard, characters the window's keyboard layout cannot type in one key press go through
    /// SendInput (reported in the result, they do not reach elevated windows).
    /// </summary>
    internal object TypeText(string text, InputKind? kind = null)
    {
        if (text.Length is < 1 or > 1000 || text.Any(char.IsControl))
            throw new ArgumentException("Text must contain 1–1000 printable characters; no control keys.");
        var keyboard = KeyboardBackend(kind);
        var target = Native.GetForegroundWindow();
        nint layout = DeviceKeyboard.LayoutOf(target);
        int viaDevice = 0;
        var injectedCharacters = new List<char>();
        foreach (char character in text)
        {
            if (keyboard is not null && DeviceKeyboard.TryMap(character, layout, out int modifiers, out int usage))
            {
                Execute(() =>
                {
                    RequireForeground(target);
                    PressKey(keyboard, modifiers, usage);
                }, deviceInput: true);
                viaDevice++;
            }
            else
            {
                Execute(() =>
                {
                    RequireForeground(target);
                    Native.SendUnicode(character);
                });
                if (keyboard is not null) injectedCharacters.Add(character);
            }
        }
        return keyboard is null
            ? new { typedCharacters = text.Length, input = "injected" }
            : injectedCharacters.Count == 0
                ? new { typedCharacters = text.Length, input = "device" }
                : (object)new
                {
                    typedCharacters = text.Length, input = "device", viaDevice,
                    viaInjected = injectedCharacters.Count,
                    injectedCharacters = new string(injectedCharacters.Distinct().ToArray()),
                    note = "These characters are not on the window's keyboard layout (or need a dead key); they were sent with SendInput and do not reach elevated windows.",
                };
    }

    /// <summary>
    /// Presses keys given in SendKeys syntax (<see cref="KeySequence"/>): Enter, Escape, Tab, arrows, F-keys, shortcuts.
    /// <paramref name="kind"/> null = the device keyboard when available, otherwise SendInput. Unlike text entry the
    /// foreground window may change (Alt+Tab, Enter opening a window): that is the purpose of many shortcuts.
    /// </summary>
    internal object PressKeys(string keys, InputKind? kind = null)
    {
        var strokes = KeySequence.Parse(keys);
        var keyboard = KeyboardBackend(kind);
        if (kind == InputKind.Device && keyboard is null)
            throw new InvalidOperationException("The device keyboard is not available (usbip-win2 missing, Remote Desktop session or --device driver/none). Use desktop_press_keys_injected.");
        nint layout = DeviceKeyboard.LayoutOf(Native.GetForegroundWindow());
        if (keyboard is not null)
        {
            // Validate everything before the first key press: never stop halfway because of a character.
            foreach (var stroke in strokes)
                if (stroke.Key is null && !KeySequence.TryDevice(stroke, layout, out _, out _))
                    throw new ArgumentException($"'{stroke.Character}' is not on the keyboard layout of the foreground window. Use desktop_type_text for text, or desktop_press_keys_injected.");
        }
        var injectedKeys = new List<string>();
        foreach (var stroke in strokes)
        {
            bool onDevice = keyboard is not null && KeySequence.TryDevice(stroke, layout, out _, out _);
            if (keyboard is not null && !onDevice) injectedKeys.Add(stroke.ToString());
            Execute(() =>
            {
                if (onDevice)
                {
                    KeySequence.TryDevice(stroke, layout, out int modifiers, out int usage);
                    PressKey(keyboard!, modifiers, usage);
                }
                else
                {
                    KeySequence.SendInjected(stroke, layout, () => Thread.Sleep(humanMotion ? HumanMotion.Pause(random, 15, 40) : 8));
                    Thread.Sleep(humanMotion ? HumanMotion.Pause(random, 20, 70) : 10);
                }
            }, onDevice);
            // A shortcut can switch the window (Alt+Tab, Win+R): later characters use the new window's layout.
            layout = DeviceKeyboard.LayoutOf(Native.GetForegroundWindow());
        }
        var pressed = strokes.Select(s => s.ToString()).Distinct().Take(40).ToArray();
        return injectedKeys.Count == 0
            ? new { pressed = strokes.Count, keys = pressed, input = keyboard is null ? "injected" : "device" }
            : (object)new { pressed = strokes.Count, keys = pressed, input = "device", injectedKeys = injectedKeys.Distinct().ToArray(), note = "These keys have no PC keyboard scan code and were sent with SendInput." };
    }

    private static void RequireForeground(nint target)
    {
        if (Native.GetForegroundWindow() != target)
            throw new OperationCanceledException("Foreground window changed while typing.");
    }

    /// <summary>The keyboard for new text: the device keyboard, null for SendInput.</summary>
    private IPointerBackend? KeyboardBackend(InputKind? kind)
    {
        if (kind == InputKind.Injected || device is null) return null;
        if (WindowNative.IsRemoteSession) return null; // device keys would reach the console session
        try
        {
            if (!device.HasKeyboard) return null;
            // Like the device mouse, wait for the first attach (Windows enumerates the device in a few seconds). When the
            // device stays unavailable (usbip-win2 missing), type with SendInput and do not wait again for a while.
            if (Environment.TickCount64 < Interlocked.Read(ref keyboardFallbackUntil)) return device.Available ? device : null;
            var deadline = Environment.TickCount64 + 20000;
            while (!device.Available)
            {
                if (Environment.TickCount64 > deadline) { Interlocked.Exchange(ref keyboardFallbackUntil, Environment.TickCount64 + 300000); return null; }
                Thread.Sleep(250);
            }
            return device;
        }
        catch { return null; }
    }

    private long keyboardFallbackUntil;

    /// <summary>One key press like a person: modifiers first, key down, key up, modifiers up; always released.</summary>
    private void PressKey(IPointerBackend keyboard, int modifiers, int usage)
    {
        try
        {
            if (modifiers != 0) { keyboard.Key(modifiers, 0); Thread.Sleep(humanMotion ? HumanMotion.Pause(random, 15, 35) : 8); }
            keyboard.Key(modifiers, usage);
            Thread.Sleep(humanMotion ? HumanMotion.Pause(random, 25, 60) : 10);
            if (modifiers != 0) { keyboard.Key(modifiers, 0); Thread.Sleep(humanMotion ? HumanMotion.Pause(random, 10, 25) : 5); }
        }
        finally { keyboard.Key(0, 0); }
        Thread.Sleep(humanMotion ? HumanMotion.Pause(random, 20, 70) : 10);
    }

    internal async Task Click(InputKind kind, string button, int count, CancellationToken cancellationToken = default)
    {
        if (count is < 1 or > 2) throw new ArgumentOutOfRangeException(nameof(count), "count must be 1 or 2.");
        Mask(button);
        Backend(kind);
        if (humanMotion) await Task.Delay(HumanMotion.Pause(random, 20, 70), cancellationToken);
        int gap = (int)Math.Min(humanMotion ? HumanMotion.Pause(random, 70, 120) : 100, Native.GetDoubleClickTime() / 3);
        for (int i = 0; i < count; i++)
        {
            Button(kind, button, true);
            try { await Task.Delay(humanMotion ? HumanMotion.Pause(random, 55, 110) : 45, CancellationToken.None); }
            finally { Button(kind, button, false); }
            if (i + 1 < count) await Task.Delay(gap, cancellationToken);
        }
    }

    internal async Task Drag(InputKind kind, int x1, int y1, int x2, int y2, int? duration, string button, CancellationToken cancellationToken = default)
    {
        // Validate both points before pressing the button.
        var layout = MonitorLayout.Current();
        RequireOnMonitor(layout, x1, y1);
        RequireOnMonitor(layout, x2, y2);
        if (duration is < 0 or > 10000) throw new ArgumentOutOfRangeException(nameof(duration), "durationMs must be 0-10000.");
        Mask(button);
        await Move(kind, x1, y1, cancellationToken: cancellationToken);
        Button(kind, button, true);
        try
        {
            // Humans pause after pressing (drag threshold) and before releasing (drop target highlight).
            if (humanMotion) await Task.Delay(HumanMotion.Pause(random, 80, 160), cancellationToken);
            await Move(kind, x2, y2, duration ?? (humanMotion ? null : 600), cancellationToken);
            if (humanMotion) await Task.Delay(HumanMotion.Pause(random, 60, 130), cancellationToken);
        }
        finally { Button(kind, button, false); }
    }

    internal void Scroll(InputKind kind, int delta, bool horizontal)
    {
        if (delta is < -12000 or > 12000) throw new ArgumentOutOfRangeException(nameof(delta));
        var backend = Backend(kind);
        Execute(() => backend.Scroll(delta, horizontal), kind == InputKind.Device);
    }

    /// <summary>Releases every button this server holds, on the path that pressed it.</summary>
    internal void ReleaseAll()
    {
        lock (gate)
        {
            if (device is not null)
                foreach (int mask in new[] { 1, 2, 4, 8, 16 })
                    if ((held[InputKind.Device] & mask) != 0)
                        try { overlay.Control.ReleaseButton(mask, () => device.Button(mask, false)); } catch { /* SendInput fallback below */ }
            overlay.Control.ReleaseOwnedButtons();
            device?.ForgetButtons();
            injected.ForgetButtons();
            held[InputKind.Device] = held[InputKind.Injected] = 0;
        }
    }

    internal IList<ContentBlock> Capture(string scope, int monitorIndex = 0)
    {
        var screens = Screen.AllScreens;
        if (scope == "monitor" && (monitorIndex < 0 || monitorIndex >= screens.Length)) throw new ArgumentException("Invalid monitorIndex.");
        var b = scope switch
        {
            "primary" => Screen.PrimaryScreen!.Bounds,
            "desktop" => SystemInformation.VirtualScreen,
            "monitor" => screens[monitorIndex].Bounds,
            _ => throw new ArgumentException("scope must be primary, monitor or desktop.")
        };
        if ((long)b.Width * b.Height > 40_000_000) throw new InvalidOperationException("Desktop exceeds capture limit of 40 million pixels.");
        using var bitmap = new Bitmap(b.Width, b.Height);
        using (var g = Graphics.FromImage(bitmap))
        {
            g.CopyFromScreen(b.Location, Point.Empty, b.Size, CopyPixelOperation.SourceCopy);
            if (Native.GetCursorPos(out var p)) CursorOverlay.PaintMarker(g, p.X - b.X, p.Y - b.Y);
        }
        using var stream = new MemoryStream();
        bitmap.Save(stream, ImageFormat.Png);
        var metadata = JsonSerializer.Serialize(new { bounds = new { x = b.X, y = b.Y, width = b.Width, height = b.Height }, cursor = Position(), cursorComposited = true });
        return [new TextContentBlock { Text = metadata }, ImageContentBlock.FromBytes(stream.ToArray(), "image/png")];
    }
}
