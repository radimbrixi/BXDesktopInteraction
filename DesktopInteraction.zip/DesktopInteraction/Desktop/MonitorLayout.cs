namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>One stretch of a planned pointer route, entirely inside one monitor.</summary>
internal readonly record struct RouteLeg(Point From, Point To, Rectangle Area);

/// <summary>
/// Monitor topology: which monitors share an edge and over which range. The pointer can only pass between
/// monitors across such a shared edge (Windows blocks it in gaps and makes corners sticky), so moves between
/// monitors are routed through crossing points on shared edges, kept away from the corners.
/// </summary>
internal sealed class MonitorLayout
{
    internal sealed record Monitor(int Index, string Name, Rectangle Bounds, bool Primary);

    /// <summary>
    /// Shared edge between two monitors. Vertical edges: <see cref="Line"/> is the x of the first column of the
    /// right monitor and the range is y [Start, End). Horizontal edges: <see cref="Line"/> is the y of the first row
    /// of the lower monitor and the range is x [Start, End).
    /// </summary>
    internal sealed record Edge(int A, int B, bool Vertical, int Line, int Start, int End)
    {
        internal int Length => End - Start;
        /// <summary>Distance kept from the ends of the edge (corners).</summary>
        internal int Inset => Math.Min(50, Length / 4);
    }

    internal IReadOnlyList<Monitor> Monitors { get; }
    internal IReadOnlyList<Edge> Edges { get; }

    internal MonitorLayout(IEnumerable<(string Name, Rectangle Bounds, bool Primary)> monitors)
    {
        Monitors = monitors.Select((m, i) => new Monitor(i, m.Name, m.Bounds, m.Primary)).ToList();
        var edges = new List<Edge>();
        foreach (var a in Monitors)
            foreach (var b in Monitors)
            {
                if (a.Index == b.Index) continue;
                // a left of b, sharing a vertical line
                if (a.Bounds.Right == b.Bounds.Left)
                {
                    int lo = Math.Max(a.Bounds.Top, b.Bounds.Top), hi = Math.Min(a.Bounds.Bottom, b.Bounds.Bottom);
                    if (hi > lo) edges.Add(new Edge(a.Index, b.Index, true, b.Bounds.Left, lo, hi));
                }
                // a above b, sharing a horizontal line
                if (a.Bounds.Bottom == b.Bounds.Top)
                {
                    int lo = Math.Max(a.Bounds.Left, b.Bounds.Left), hi = Math.Min(a.Bounds.Right, b.Bounds.Right);
                    if (hi > lo) edges.Add(new Edge(a.Index, b.Index, false, b.Bounds.Top, lo, hi));
                }
            }
        Edges = edges;
    }

    internal static MonitorLayout Current() => new(Screen.AllScreens.Select(s => (s.DeviceName.TrimStart('\\', '.'), s.Bounds, s.Primary)));

    internal int MonitorAt(Point p) => Monitors.FirstOrDefault(m => m.Bounds.Contains(p))?.Index ?? -1;

    /// <summary>
    /// Plans the route from start to end: one leg per monitor, joined across shared edges. Same monitor (or no
    /// connection through shared edges, e.g. monitors touching only at a corner): a single direct leg.
    /// </summary>
    internal List<RouteLeg> Route(Point start, Point end)
    {
        int from = MonitorAt(start), to = MonitorAt(end);
        var direct = new List<RouteLeg> { new(start, end, from >= 0 && from == to ? Monitors[from].Bounds : Union()) };
        if (from < 0 || to < 0 || from == to) return direct;
        var edges = ShortestEdgePath(start, end, from, to);
        if (edges is null) return direct;

        // Monitor sequence and crossing positions along each shared edge, then "string pulling" toward straight lines.
        var monitors = new List<int> { from };
        foreach (var e in edges) monitors.Add(e.A == monitors[^1] ? e.B : e.A);
        var cross = edges.Select(e => (double)(e.Start + e.End) / 2).ToArray();
        for (int iteration = 0; iteration < 8; iteration++)
            for (int i = 0; i < edges.Count; i++)
            {
                var prev = i == 0 ? start : CrossPoint(edges[i - 1], cross[i - 1]);
                var next = i == edges.Count - 1 ? end : CrossPoint(edges[i + 1], cross[i + 1]);
                cross[i] = BestCrossing(edges[i], prev, next);
            }

        var legs = new List<RouteLeg>();
        var current = start;
        for (int i = 0; i < edges.Count; i++)
        {
            var (exit, entry) = Sides(edges[i], cross[i], monitors[i]);
            legs.Add(new RouteLeg(current, exit, Monitors[monitors[i]].Bounds));
            current = entry;
        }
        legs.Add(new RouteLeg(current, end, Monitors[to].Bounds));
        return legs;
    }

    /// <summary>
    /// Dijkstra over crossings. A state is (edge crossed, monitor entered); its cost is the length of the polyline
    /// start → crossing midpoints. Returns the edges of the shortest route, or null when the monitors are not
    /// connected through shared edges.
    /// </summary>
    private List<Edge>? ShortestEdgePath(Point start, Point end, int from, int to)
    {
        int n = Edges.Count;
        int State(int edge, int entered) => edge * 2 + (entered == Edges[edge].B ? 1 : 0);
        int Entered(int state) => state % 2 == 1 ? Edges[state / 2].B : Edges[state / 2].A;
        var dist = Enumerable.Repeat(double.PositiveInfinity, 2 * n).ToArray();
        var previous = Enumerable.Repeat(-1, 2 * n).ToArray();
        var done = new bool[2 * n];
        var middle = Edges.Select(e => CrossPoint(e, (e.Start + e.End) / 2.0)).ToArray();
        for (int i = 0; i < n; i++)
        {
            if (Edges[i].A == from) dist[State(i, Edges[i].B)] = Distance(start, middle[i]);
            if (Edges[i].B == from) dist[State(i, Edges[i].A)] = Distance(start, middle[i]);
        }

        double best = double.PositiveInfinity; int last = -1;
        while (true)
        {
            int u = -1;
            for (int s = 0; s < 2 * n; s++) if (!done[s] && (u < 0 || dist[s] < dist[u])) u = s;
            if (u < 0 || double.IsPositiveInfinity(dist[u]) || dist[u] >= best) break;
            done[u] = true;
            int monitor = Entered(u), edge = u / 2;
            if (monitor == to)
            {
                double total = dist[u] + Distance(middle[edge], end);
                if (total < best) { best = total; last = u; }
                continue;
            }
            for (int v = 0; v < n; v++)
            {
                if (v == edge || (Edges[v].A != monitor && Edges[v].B != monitor)) continue;
                int next = State(v, Edges[v].A == monitor ? Edges[v].B : Edges[v].A);
                if (done[next] || Entered(next) == from) continue;
                double d = dist[u] + Distance(middle[edge], middle[v]);
                if (d < dist[next]) { dist[next] = d; previous[next] = u; }
            }
        }
        if (last < 0) return null;
        var path = new List<Edge>();
        for (int s = last; s >= 0; s = previous[s]) path.Insert(0, Edges[s / 2]);
        return path;
    }

    /// <summary>Position on the edge closest to the straight line prev→next, kept away from the corners.</summary>
    private static double BestCrossing(Edge e, Point prev, Point next)
    {
        double lo = e.Start + e.Inset, hi = e.End - 1 - e.Inset;
        if (hi < lo) return (e.Start + e.End - 1) / 2.0;
        // Intersection of the line prev→next with the edge line (x = Line for vertical, y = Line for horizontal).
        double a1 = e.Vertical ? prev.X : prev.Y, a2 = e.Vertical ? next.X : next.Y;
        double b1 = e.Vertical ? prev.Y : prev.X, b2 = e.Vertical ? next.Y : next.X;
        double t = Math.Abs(a2 - a1) < 1e-9 ? 0.5 : (e.Line - a1) / (a2 - a1);
        double position = b1 + Math.Clamp(t, 0, 1) * (b2 - b1);
        return Math.Clamp(position, lo, hi);
    }

    private static Point CrossPoint(Edge e, double position)
    {
        int p = (int)Math.Round(position);
        return e.Vertical ? new Point(e.Line, p) : new Point(p, e.Line);
    }

    /// <summary>Last pixel on the monitor being left and first pixel on the monitor being entered.</summary>
    private static (Point Exit, Point Entry) Sides(Edge e, double position, int leaving)
    {
        int p = (int)Math.Round(position);
        // A is left of / above B: A's last column/row is Line - 1, B's first is Line.
        int leavingSide = leaving == e.A ? e.Line - 1 : e.Line, enteringSide = leaving == e.A ? e.Line : e.Line - 1;
        return e.Vertical
            ? (new Point(leavingSide, p), new Point(enteringSide, p))
            : (new Point(p, leavingSide), new Point(p, enteringSide));
    }

    private Rectangle Union() => Monitors.Select(m => m.Bounds).Aggregate(Rectangle.Union);

    private static double Distance(Point a, Point b) => Math.Sqrt(Math.Pow(a.X - b.X, 2) + Math.Pow(a.Y - b.Y, 2));

    internal static double Length(IReadOnlyList<RouteLeg> legs) => legs.Sum(l => Distance(l.From, l.To)) + (legs.Count - 1);

    /// <summary>For desktop_status: monitors and which edges they share (where the pointer can pass).</summary>
    internal object Describe() => new
    {
        monitors = Monitors.Select(m => new
        {
            index = m.Index, name = m.Name, primary = m.Primary,
            x = m.Bounds.X, y = m.Bounds.Y, width = m.Bounds.Width, height = m.Bounds.Height,
            right = m.Bounds.Right - 1, bottom = m.Bounds.Bottom - 1,
            orientation = m.Bounds.Height > m.Bounds.Width ? "portrait" : "landscape",
        }),
        sharedEdges = Edges.Where(e => e.A < e.B || !Edges.Any(o => o.A == e.B && o.B == e.A)).Select(e => new
        {
            between = $"{Monitors[e.A].Name} {(e.Vertical ? "right" : "bottom")} | {Monitors[e.B].Name} {(e.Vertical ? "left" : "top")}",
            at = e.Vertical ? $"x={e.Line - 1}|{e.Line}" : $"y={e.Line - 1}|{e.Line}",
            range = e.Vertical ? $"y {e.Start}..{e.End - 1}" : $"x {e.Start}..{e.End - 1}",
        }),
        routing = "Pointer moves between monitors are routed across shared edges, away from corners. Points in gaps between monitors are rejected.",
    };
}
