using System.ComponentModel;
using System.Runtime.InteropServices;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

internal static class Native
{
    [StructLayout(LayoutKind.Sequential)] internal struct Point { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] internal struct MouseInput
    {
        public int X, Y;
        public uint Data, Flags, Time;
        public nuint Extra;
    }
    // INPUT's union must be large enough for KEYBDINPUT and HARDWAREINPUT too.
    [StructLayout(LayoutKind.Explicit)] internal struct InputUnion
    {
        [FieldOffset(0)] public MouseInput Mouse;
        [FieldOffset(0)] public KeyboardInput Keyboard;
    }
    [StructLayout(LayoutKind.Sequential)] internal struct KeyboardInput
    {
        public ushort Key, Scan;
        public uint Flags, Time;
        public nuint Extra;
    }
    [StructLayout(LayoutKind.Sequential)] internal struct Input { public uint Type; public InputUnion Union; }
    [DllImport("user32.dll", SetLastError = true)] internal static extern uint SendInput(uint count, Input[] inputs, int size);
    [DllImport("user32.dll")] internal static extern bool GetCursorPos(out Point point);
    [DllImport("user32.dll")] internal static extern short GetAsyncKeyState(int key);
    [DllImport("user32.dll")] internal static extern uint GetDoubleClickTime();
    [DllImport("user32.dll")] internal static extern nint GetForegroundWindow();
    [DllImport("user32.dll")] internal static extern bool RegisterHotKey(nint hwnd, int id, uint modifiers, uint key);
    [DllImport("user32.dll")] internal static extern bool UnregisterHotKey(nint hwnd, int id);

    internal delegate bool EnumWindowsProc(nint hWnd, nint lParam);
    [DllImport("user32.dll")] internal static extern bool EnumWindows(EnumWindowsProc callback, nint lParam);
    [DllImport("user32.dll")] internal static extern bool IsWindowVisible(nint hWnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] internal static extern int GetWindowText(nint hWnd, System.Text.StringBuilder text, int maxCount);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] internal static extern int GetWindowTextLength(nint hWnd);
    [DllImport("user32.dll")] internal static extern bool SetForegroundWindow(nint hWnd);
    [DllImport("user32.dll")] internal static extern bool ShowWindow(nint hWnd, int command);

    [DllImport("user32.dll", SetLastError = true)] private static extern nint OpenInputDesktop(uint flags, bool inherit, uint access);
    [DllImport("user32.dll")] private static extern bool CloseDesktop(nint desktop);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool GetUserObjectInformation(nint handle, int index, System.Text.StringBuilder? info, int length, out int needed);
    [DllImport("winmm.dll")] internal static extern uint timeBeginPeriod(uint milliseconds);

    /// <summary>
    /// True when the input desktop is the normal user desktop ("Default"). False on the secure desktop
    /// (UAC prompt, lock screen, Ctrl+Alt+Del), where device input would otherwise also land.
    /// </summary>
    internal static bool IsNormalInputDesktop()
    {
        nint desktop = OpenInputDesktop(0, false, 0x0001 /* DESKTOP_READOBJECTS */);
        if (desktop == 0) return false;
        try
        {
            var name = new System.Text.StringBuilder(256);
            return GetUserObjectInformation(desktop, 2 /* UOI_NAME */, name, name.Capacity * 2, out _)
                && string.Equals(name.ToString(), "Default", StringComparison.OrdinalIgnoreCase);
        }
        finally { CloseDesktop(desktop); }
    }

    internal static void Send(uint flags, int x = 0, int y = 0, uint data = 0)
    {
        Input[] input = [new() { Type = 0, Union = new() { Mouse = new() { X = x, Y = y, Data = data, Flags = flags } } }];
        if (SendInput(1, input, Marshal.SizeOf<Input>()) != 1)
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Mouse input was not accepted. Windows integrity/desktop restrictions may apply.");
    }
    internal static void SendUnicode(char character)
    {
        Input[] inputs = [
            new() { Type = 1, Union = new() { Keyboard = new() { Scan = character, Flags = 4 } } },
            new() { Type = 1, Union = new() { Keyboard = new() { Scan = character, Flags = 6 } } }
        ];
        if (SendInput(2, inputs, Marshal.SizeOf<Input>()) != 2)
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Text input was not accepted.");
    }
}
