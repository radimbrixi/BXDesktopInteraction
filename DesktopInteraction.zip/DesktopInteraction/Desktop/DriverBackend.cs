using System.ComponentModel;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace Extedo.AutoTest.Ai.Mcp.DesktopInteraction.Desktop;

/// <summary>
/// Backend for the ExtedoVirtualMouse VHF driver (Driver\ExtedoVirtualMouse). Sends complete absolute
/// HID reports; Windows receives them as input from a mouse device. Contract: Driver\ExtedoVirtualMouse\Public.h.
/// </summary>
internal sealed class DriverBackend() : AbsoluteHidBackend(relativeCollection: false)
{
    internal const string DevicePath = @"\\.\ExtedoVirtualMouse";
    internal const uint IoctlReport = 0x0022A000;

    private SafeFileHandle? handle;

    public override string Name => "ExtedoVirtualMouse";

    protected override void Transmit(byte[] report)
    {
        Open();
        if (!DeviceIoControl(handle!, IoctlReport, report, (uint)report.Length, 0, 0, out _, 0))
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Extedo virtual mouse driver rejected the report.");
    }

    protected override object TransportDiagnostics() { Open(); return new { device = DevicePath }; }

    protected override void DisposeTransport() { handle?.Dispose(); handle = null; }

    private void Open()
    {
        if (handle is { IsInvalid: false, IsClosed: false }) return;
        handle = CreateFile(DevicePath, 0x40000000 /* GENERIC_WRITE */, 3 /* share read|write */, 0, 3 /* OPEN_EXISTING */, 0, 0);
        if (handle.IsInvalid)
        {
            int error = Marshal.GetLastWin32Error();
            handle.Dispose(); handle = null;
            throw new Win32Exception(error, $"Extedo virtual mouse driver is not available at {DevicePath} (not installed, disabled or access denied). See DRIVER.md, or start with --device usbip or --device none.");
        }
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern SafeFileHandle CreateFile(string name, uint access, uint share, nint security, uint creation, uint flags, nint template);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool DeviceIoControl(SafeFileHandle device, uint code, byte[] input, uint inputSize, nint output, uint outputSize, out uint returned, nint overlapped);
}
